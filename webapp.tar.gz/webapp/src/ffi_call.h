/*
 * Copyright 2026 nyan<(nyan4)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef MYON_FFI_CALL_H
#define MYON_FFI_CALL_H

/*
 * Dynamic C call dispatch (Phase 3, Step 3).
 *
 * Calls an arbitrary already-resolved C function pointer from a signature
 * description + argument array, without libffi.  Instead of libffi we
 * enumerate a table of tiny "trampoline" wrappers, one per (argument type
 * pattern) x (return type), and cast the raw pointer to the matching C
 * function type before calling.
 *
 * The four supported kinds collapse to two x86-64 System V register classes:
 *   - integer class : i64 / ptr / str  (all passed as a 64-bit integer reg)
 *   - float class   : f64              (passed in an xmm register)
 * so a wrapper only needs to distinguish 'd' from the rest, but the *positional
 * order* of every argument is preserved so the compiler lays out the call
 * exactly as the target C function expects.  Interleaved int/double orders are
 * fully supported (e.g. "did", "idi", ...), up to 6 arguments.
 */

typedef enum {
    FFI_ARG_I64,
    FFI_ARG_F64,
    FFI_ARG_PTR,
    FFI_ARG_STR
} FFIArgKind;

typedef union {
    long long   i;
    double      d;
    void       *p;
    const char *s;
} FFIArgValue;

typedef enum {
    FFI_RET_I64,
    FFI_RET_F64,
    FFI_RET_PTR,
    FFI_RET_VOID
} FFIRetKind;

typedef union {
    long long i;
    double    d;
    void     *p;
} FFIRetValue;

/*
 * Call `fn` with the given arguments.
 *
 *   fn        : raw function pointer (e.g. from dlsym).
 *   args      : argument values (max 6).
 *   arg_kinds : kind of each argument, parallel to `args`.
 *   arg_count : number of arguments (0..6).
 *   ret_kind  : expected return type.
 *   out       : receives the return value (untouched for FFI_RET_VOID).
 *
 * Returns 1 on success, 0 for an unsupported request (more than 6 arguments,
 * or an argument pattern that is not covered by the trampoline table).
 */
int ffi_call_dispatch(void *fn,
                      const FFIArgValue *args,
                      const FFIArgKind *arg_kinds,
                      int arg_count,
                      FFIRetKind ret_kind,
                      FFIRetValue *out);

#endif /* MYON_FFI_CALL_H */
