/*
 * Copyright 2026 nyan<(nyan4)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include "ffi.h"
#include "ffi_platform.h"
#include "common.h"

#include <stdlib.h>

/*
 * One loaded library.  `id` is the handle exposed to Myon; `lib` is NULL once
 * the entry has been closed (the slot is retired, never reused).  Modelled on
 * the interpreter's ModuleEntry singly-linked list.
 */
typedef struct FFIEntry {
    long long        id;
    FFILib          *lib;   /* NULL after close */
    struct FFIEntry *next;
} FFIEntry;

struct FFIState {
    FFIEntry *entries;   /* head of list (newest first) */
    long long next_id;   /* monotonically increasing; IDs are never reused */
};

FFIState *ffi_state_create(void) {
    FFIState *st = (FFIState *)myon_xmalloc(sizeof(FFIState));
    st->entries = NULL;
    st->next_id = 0;
    return st;
}

void ffi_state_free(FFIState *st) {
    if (!st) return;
    FFIEntry *e = st->entries;
    while (e) {
        FFIEntry *n = e->next;
        if (e->lib) ffi_platform_close(e->lib);
        free(e);
        e = n;
    }
    free(st);
}

static FFIEntry *find_entry(FFIState *st, long long handle) {
    for (FFIEntry *e = st->entries; e; e = e->next)
        if (e->id == handle) return e;
    return NULL;
}

long long ffi_load(FFIState *st, const char *path, char **err_msg) {
    if (!st || !path) {
        if (err_msg) *err_msg = myon_strdup("invalid FFI load request");
        return -1;
    }
    FFILib *lib = ffi_platform_load(path, err_msg);
    if (!lib) return -1; /* err_msg already populated by the platform layer */

    FFIEntry *e = (FFIEntry *)myon_xmalloc(sizeof(FFIEntry));
    e->id = st->next_id++;
    e->lib = lib;
    e->next = st->entries;
    st->entries = e;
    return e->id;
}

void *ffi_lookup_symbol(FFIState *st, long long handle, const char *symbol_name) {
    if (!st || !symbol_name) return NULL;
    FFIEntry *e = find_entry(st, handle);
    if (!e || !e->lib) return NULL;
    return ffi_platform_sym(e->lib, symbol_name);
}

int ffi_close(FFIState *st, long long handle) {
    if (!st) return 0;
    FFIEntry *e = find_entry(st, handle);
    if (!e || !e->lib) return 0; /* invalid or already closed */
    ffi_platform_close(e->lib);
    e->lib = NULL; /* retire the slot; the ID is not reused */
    return 1;
}
