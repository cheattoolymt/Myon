/*
 * Copyright 2026 nyan<(nyan4)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef MYON_FFI_H
#define MYON_FFI_H

/*
 * FFI handle-management layer (Phase 3, Step 2).
 *
 * Bridges the platform loader (ffi_platform.*) with the interpreter.  It owns
 * the set of loaded shared libraries and hands out non-negative integer handle
 * IDs (0, 1, 2, ...) that Myon scripts pass around as plain `int` values.
 *
 * Handle IDs are never reused: closing a handle marks its slot dead so a stale
 * handle can be detected rather than silently aliasing a later library.
 */

/* Whole-subsystem state (one per interpreter instance). */
typedef struct FFIState FFIState;

FFIState *ffi_state_create(void);
void      ffi_state_free(FFIState *st);

/*
 * Load a shared library from `path`.
 *
 * On success returns a non-negative handle ID.  On failure returns -1 and
 * stores a heap-allocated error message in *err_msg (caller frees it).
 */
long long ffi_load(FFIState *st, const char *path, char **err_msg);

/*
 * Resolve a symbol on a loaded library by handle ID.
 * Returns NULL if the handle is invalid/closed or the symbol is absent.
 */
void *ffi_lookup_symbol(FFIState *st, long long handle, const char *symbol_name);

/*
 * Close a loaded library.  Returns 1 on success, 0 if the handle is invalid or
 * already closed.
 */
int ffi_close(FFIState *st, long long handle);

#endif /* MYON_FFI_H */
