/*
 * Copyright 2026 nyan<(nyan4)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef MYON_FFI_PLATFORM_H
#define MYON_FFI_PLATFORM_H

/*
 * Platform abstraction layer for the C FFI (Phase 3, Step 1).
 *
 * A thin wrapper over the OS dynamic-loader primitives:
 *   - POSIX:   dlopen / dlsym / dlclose
 *   - Windows: LoadLibrary / GetProcAddress / FreeLibrary (stub for now)
 *
 * Only Linux is fully implemented in Phase 3.  macOS / Windows / unknown
 * platforms compile but fail at runtime with a "not supported yet" message,
 * so the interpreter builds identically on all three OSes.
 */

typedef struct FFILib FFILib; /* opaque library handle */

/*
 * Load a shared library from `path`.
 *
 * On success returns a non-NULL FFILib*.  On failure returns NULL and stores a
 * heap-allocated error message in *err_msg (the caller must free() it).  On
 * success *err_msg is left untouched.
 */
FFILib *ffi_platform_load(const char *path, char **err_msg);

/* Resolve a symbol by name.  Returns NULL if not found. */
void *ffi_platform_sym(FFILib *lib, const char *name);

/* Close a previously-loaded library. */
void ffi_platform_close(FFILib *lib);

/*
 * Whether FFI is usable on the current OS.
 * Returns 1 on Linux, 0 on macOS / Windows / unknown (Phase 3 stubs).
 */
int ffi_platform_supported(void);

#endif /* MYON_FFI_PLATFORM_H */
