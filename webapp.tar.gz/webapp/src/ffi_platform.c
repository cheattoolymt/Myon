/*
 * Copyright 2026 nyan<(nyan4)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include "ffi_platform.h"
#include "common.h"

#include <stdlib.h>
#include <string.h>

/*
 * FFILib wraps the raw OS library handle behind an opaque struct so callers
 * never touch platform-specific types directly.
 */
struct FFILib {
    void *handle; /* dlopen handle (POSIX) / HMODULE (Windows) */
};

/* ------------------------------------------------------------------ */
/* Linux: dlopen / dlsym / dlclose                                     */
/* ------------------------------------------------------------------ */
#if defined(__linux__)

#include <dlfcn.h>

FFILib *ffi_platform_load(const char *path, char **err_msg) {
    void *h = dlopen(path, RTLD_NOW | RTLD_GLOBAL);
    if (!h) {
        const char *e = dlerror();
        if (err_msg) *err_msg = myon_strdup(e ? e : "dlopen failed");
        return NULL;
    }
    FFILib *lib = (FFILib *)myon_xmalloc(sizeof(FFILib));
    lib->handle = h;
    return lib;
}

void *ffi_platform_sym(FFILib *lib, const char *name) {
    if (!lib || !lib->handle) return NULL;
    /* Clear any stale error, then resolve.  A valid symbol may legitimately
     * hold the value NULL, but for FFI use we treat NULL as "not found". */
    dlerror();
    return dlsym(lib->handle, name);
}

void ffi_platform_close(FFILib *lib) {
    if (!lib) return;
    if (lib->handle) dlclose(lib->handle);
    free(lib);
}

int ffi_platform_supported(void) { return 1; }

/* ------------------------------------------------------------------ */
/* macOS: stub (dlopen exists here too, but left for a later phase)    */
/* ------------------------------------------------------------------ */
#elif defined(__APPLE__)

FFILib *ffi_platform_load(const char *path, char **err_msg) {
    (void)path;
    if (err_msg)
        *err_msg = myon_strdup("FFI is not supported on macOS yet (Phase3 stub)");
    return NULL;
}

void *ffi_platform_sym(FFILib *lib, const char *name) {
    (void)lib; (void)name;
    return NULL;
}

void ffi_platform_close(FFILib *lib) { (void)lib; }

int ffi_platform_supported(void) { return 0; }

/* ------------------------------------------------------------------ */
/* Windows: stub (LoadLibraryA/GetProcAddress/FreeLibrary later)       */
/* ------------------------------------------------------------------ */
#elif defined(_WIN32)

FFILib *ffi_platform_load(const char *path, char **err_msg) {
    (void)path;
    if (err_msg)
        *err_msg = myon_strdup("FFI is not supported on Windows yet (Phase3 stub)");
    return NULL;
}

void *ffi_platform_sym(FFILib *lib, const char *name) {
    (void)lib; (void)name;
    return NULL;
}

void ffi_platform_close(FFILib *lib) { (void)lib; }

int ffi_platform_supported(void) { return 0; }

/* ------------------------------------------------------------------ */
/* Unknown platform: stub                                              */
/* ------------------------------------------------------------------ */
#else

FFILib *ffi_platform_load(const char *path, char **err_msg) {
    (void)path;
    if (err_msg)
        *err_msg = myon_strdup("FFI is not supported on this platform");
    return NULL;
}

void *ffi_platform_sym(FFILib *lib, const char *name) {
    (void)lib; (void)name;
    return NULL;
}

void ffi_platform_close(FFILib *lib) { (void)lib; }

int ffi_platform_supported(void) { return 0; }

#endif
