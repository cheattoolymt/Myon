/*
 * Copyright 2026 nyan<(nyan4)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/*
 * ffi_call.c -- dynamic C call dispatch without libffi (Phase 3, Step 3).
 *
 * !!! GENERATED-STYLE FILE !!!
 * The large block of call_* trampolines and the ffi_call_dispatch switch below
 * were produced mechanically (one wrapper per argument-type pattern x return
 * type, arguments 0..6).  Each argument is either integer-class ('I' -> passed
 * as long long; covers Myon i64/ptr/str) or float-class ('D' -> passed as
 * double; covers Myon f64).  The positional order of arguments is preserved so
 * that the x86-64 System V ABI lays the call out exactly like the target C
 * function's declaration, including interleaved int/double orders.
 */

#include "ffi_call.h"

#include <stddef.h>
#include <string.h>


/* ---- return type: long long ---- */
static long long call_0_to_i(void *fn) {
    long long (*f)(void);
    memcpy(&f, &fn, sizeof f);
    return f();
}
static long long call_I_to_i(void *fn, long long a0) {
    long long (*f)(long long);
    memcpy(&f, &fn, sizeof f);
    return f(a0);
}
static long long call_D_to_i(void *fn, double a0) {
    long long (*f)(double);
    memcpy(&f, &fn, sizeof f);
    return f(a0);
}
static long long call_II_to_i(void *fn, long long a0, long long a1) {
    long long (*f)(long long, long long);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1);
}
static long long call_ID_to_i(void *fn, long long a0, double a1) {
    long long (*f)(long long, double);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1);
}
static long long call_DI_to_i(void *fn, double a0, long long a1) {
    long long (*f)(double, long long);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1);
}
static long long call_DD_to_i(void *fn, double a0, double a1) {
    long long (*f)(double, double);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1);
}
static long long call_III_to_i(void *fn, long long a0, long long a1, long long a2) {
    long long (*f)(long long, long long, long long);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2);
}
static long long call_IID_to_i(void *fn, long long a0, long long a1, double a2) {
    long long (*f)(long long, long long, double);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2);
}
static long long call_IDI_to_i(void *fn, long long a0, double a1, long long a2) {
    long long (*f)(long long, double, long long);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2);
}
static long long call_IDD_to_i(void *fn, long long a0, double a1, double a2) {
    long long (*f)(long long, double, double);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2);
}
static long long call_DII_to_i(void *fn, double a0, long long a1, long long a2) {
    long long (*f)(double, long long, long long);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2);
}
static long long call_DID_to_i(void *fn, double a0, long long a1, double a2) {
    long long (*f)(double, long long, double);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2);
}
static long long call_DDI_to_i(void *fn, double a0, double a1, long long a2) {
    long long (*f)(double, double, long long);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2);
}
static long long call_DDD_to_i(void *fn, double a0, double a1, double a2) {
    long long (*f)(double, double, double);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2);
}
static long long call_IIII_to_i(void *fn, long long a0, long long a1, long long a2, long long a3) {
    long long (*f)(long long, long long, long long, long long);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3);
}
static long long call_IIID_to_i(void *fn, long long a0, long long a1, long long a2, double a3) {
    long long (*f)(long long, long long, long long, double);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3);
}
static long long call_IIDI_to_i(void *fn, long long a0, long long a1, double a2, long long a3) {
    long long (*f)(long long, long long, double, long long);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3);
}
static long long call_IIDD_to_i(void *fn, long long a0, long long a1, double a2, double a3) {
    long long (*f)(long long, long long, double, double);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3);
}
static long long call_IDII_to_i(void *fn, long long a0, double a1, long long a2, long long a3) {
    long long (*f)(long long, double, long long, long long);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3);
}
static long long call_IDID_to_i(void *fn, long long a0, double a1, long long a2, double a3) {
    long long (*f)(long long, double, long long, double);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3);
}
static long long call_IDDI_to_i(void *fn, long long a0, double a1, double a2, long long a3) {
    long long (*f)(long long, double, double, long long);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3);
}
static long long call_IDDD_to_i(void *fn, long long a0, double a1, double a2, double a3) {
    long long (*f)(long long, double, double, double);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3);
}
static long long call_DIII_to_i(void *fn, double a0, long long a1, long long a2, long long a3) {
    long long (*f)(double, long long, long long, long long);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3);
}
static long long call_DIID_to_i(void *fn, double a0, long long a1, long long a2, double a3) {
    long long (*f)(double, long long, long long, double);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3);
}
static long long call_DIDI_to_i(void *fn, double a0, long long a1, double a2, long long a3) {
    long long (*f)(double, long long, double, long long);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3);
}
static long long call_DIDD_to_i(void *fn, double a0, long long a1, double a2, double a3) {
    long long (*f)(double, long long, double, double);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3);
}
static long long call_DDII_to_i(void *fn, double a0, double a1, long long a2, long long a3) {
    long long (*f)(double, double, long long, long long);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3);
}
static long long call_DDID_to_i(void *fn, double a0, double a1, long long a2, double a3) {
    long long (*f)(double, double, long long, double);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3);
}
static long long call_DDDI_to_i(void *fn, double a0, double a1, double a2, long long a3) {
    long long (*f)(double, double, double, long long);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3);
}
static long long call_DDDD_to_i(void *fn, double a0, double a1, double a2, double a3) {
    long long (*f)(double, double, double, double);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3);
}
static long long call_IIIII_to_i(void *fn, long long a0, long long a1, long long a2, long long a3, long long a4) {
    long long (*f)(long long, long long, long long, long long, long long);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4);
}
static long long call_IIIID_to_i(void *fn, long long a0, long long a1, long long a2, long long a3, double a4) {
    long long (*f)(long long, long long, long long, long long, double);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4);
}
static long long call_IIIDI_to_i(void *fn, long long a0, long long a1, long long a2, double a3, long long a4) {
    long long (*f)(long long, long long, long long, double, long long);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4);
}
static long long call_IIIDD_to_i(void *fn, long long a0, long long a1, long long a2, double a3, double a4) {
    long long (*f)(long long, long long, long long, double, double);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4);
}
static long long call_IIDII_to_i(void *fn, long long a0, long long a1, double a2, long long a3, long long a4) {
    long long (*f)(long long, long long, double, long long, long long);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4);
}
static long long call_IIDID_to_i(void *fn, long long a0, long long a1, double a2, long long a3, double a4) {
    long long (*f)(long long, long long, double, long long, double);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4);
}
static long long call_IIDDI_to_i(void *fn, long long a0, long long a1, double a2, double a3, long long a4) {
    long long (*f)(long long, long long, double, double, long long);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4);
}
static long long call_IIDDD_to_i(void *fn, long long a0, long long a1, double a2, double a3, double a4) {
    long long (*f)(long long, long long, double, double, double);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4);
}
static long long call_IDIII_to_i(void *fn, long long a0, double a1, long long a2, long long a3, long long a4) {
    long long (*f)(long long, double, long long, long long, long long);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4);
}
static long long call_IDIID_to_i(void *fn, long long a0, double a1, long long a2, long long a3, double a4) {
    long long (*f)(long long, double, long long, long long, double);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4);
}
static long long call_IDIDI_to_i(void *fn, long long a0, double a1, long long a2, double a3, long long a4) {
    long long (*f)(long long, double, long long, double, long long);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4);
}
static long long call_IDIDD_to_i(void *fn, long long a0, double a1, long long a2, double a3, double a4) {
    long long (*f)(long long, double, long long, double, double);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4);
}
static long long call_IDDII_to_i(void *fn, long long a0, double a1, double a2, long long a3, long long a4) {
    long long (*f)(long long, double, double, long long, long long);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4);
}
static long long call_IDDID_to_i(void *fn, long long a0, double a1, double a2, long long a3, double a4) {
    long long (*f)(long long, double, double, long long, double);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4);
}
static long long call_IDDDI_to_i(void *fn, long long a0, double a1, double a2, double a3, long long a4) {
    long long (*f)(long long, double, double, double, long long);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4);
}
static long long call_IDDDD_to_i(void *fn, long long a0, double a1, double a2, double a3, double a4) {
    long long (*f)(long long, double, double, double, double);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4);
}
static long long call_DIIII_to_i(void *fn, double a0, long long a1, long long a2, long long a3, long long a4) {
    long long (*f)(double, long long, long long, long long, long long);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4);
}
static long long call_DIIID_to_i(void *fn, double a0, long long a1, long long a2, long long a3, double a4) {
    long long (*f)(double, long long, long long, long long, double);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4);
}
static long long call_DIIDI_to_i(void *fn, double a0, long long a1, long long a2, double a3, long long a4) {
    long long (*f)(double, long long, long long, double, long long);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4);
}
static long long call_DIIDD_to_i(void *fn, double a0, long long a1, long long a2, double a3, double a4) {
    long long (*f)(double, long long, long long, double, double);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4);
}
static long long call_DIDII_to_i(void *fn, double a0, long long a1, double a2, long long a3, long long a4) {
    long long (*f)(double, long long, double, long long, long long);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4);
}
static long long call_DIDID_to_i(void *fn, double a0, long long a1, double a2, long long a3, double a4) {
    long long (*f)(double, long long, double, long long, double);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4);
}
static long long call_DIDDI_to_i(void *fn, double a0, long long a1, double a2, double a3, long long a4) {
    long long (*f)(double, long long, double, double, long long);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4);
}
static long long call_DIDDD_to_i(void *fn, double a0, long long a1, double a2, double a3, double a4) {
    long long (*f)(double, long long, double, double, double);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4);
}
static long long call_DDIII_to_i(void *fn, double a0, double a1, long long a2, long long a3, long long a4) {
    long long (*f)(double, double, long long, long long, long long);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4);
}
static long long call_DDIID_to_i(void *fn, double a0, double a1, long long a2, long long a3, double a4) {
    long long (*f)(double, double, long long, long long, double);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4);
}
static long long call_DDIDI_to_i(void *fn, double a0, double a1, long long a2, double a3, long long a4) {
    long long (*f)(double, double, long long, double, long long);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4);
}
static long long call_DDIDD_to_i(void *fn, double a0, double a1, long long a2, double a3, double a4) {
    long long (*f)(double, double, long long, double, double);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4);
}
static long long call_DDDII_to_i(void *fn, double a0, double a1, double a2, long long a3, long long a4) {
    long long (*f)(double, double, double, long long, long long);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4);
}
static long long call_DDDID_to_i(void *fn, double a0, double a1, double a2, long long a3, double a4) {
    long long (*f)(double, double, double, long long, double);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4);
}
static long long call_DDDDI_to_i(void *fn, double a0, double a1, double a2, double a3, long long a4) {
    long long (*f)(double, double, double, double, long long);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4);
}
static long long call_DDDDD_to_i(void *fn, double a0, double a1, double a2, double a3, double a4) {
    long long (*f)(double, double, double, double, double);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4);
}
static long long call_IIIIII_to_i(void *fn, long long a0, long long a1, long long a2, long long a3, long long a4, long long a5) {
    long long (*f)(long long, long long, long long, long long, long long, long long);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4, a5);
}
static long long call_IIIIID_to_i(void *fn, long long a0, long long a1, long long a2, long long a3, long long a4, double a5) {
    long long (*f)(long long, long long, long long, long long, long long, double);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4, a5);
}
static long long call_IIIIDI_to_i(void *fn, long long a0, long long a1, long long a2, long long a3, double a4, long long a5) {
    long long (*f)(long long, long long, long long, long long, double, long long);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4, a5);
}
static long long call_IIIIDD_to_i(void *fn, long long a0, long long a1, long long a2, long long a3, double a4, double a5) {
    long long (*f)(long long, long long, long long, long long, double, double);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4, a5);
}
static long long call_IIIDII_to_i(void *fn, long long a0, long long a1, long long a2, double a3, long long a4, long long a5) {
    long long (*f)(long long, long long, long long, double, long long, long long);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4, a5);
}
static long long call_IIIDID_to_i(void *fn, long long a0, long long a1, long long a2, double a3, long long a4, double a5) {
    long long (*f)(long long, long long, long long, double, long long, double);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4, a5);
}
static long long call_IIIDDI_to_i(void *fn, long long a0, long long a1, long long a2, double a3, double a4, long long a5) {
    long long (*f)(long long, long long, long long, double, double, long long);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4, a5);
}
static long long call_IIIDDD_to_i(void *fn, long long a0, long long a1, long long a2, double a3, double a4, double a5) {
    long long (*f)(long long, long long, long long, double, double, double);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4, a5);
}
static long long call_IIDIII_to_i(void *fn, long long a0, long long a1, double a2, long long a3, long long a4, long long a5) {
    long long (*f)(long long, long long, double, long long, long long, long long);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4, a5);
}
static long long call_IIDIID_to_i(void *fn, long long a0, long long a1, double a2, long long a3, long long a4, double a5) {
    long long (*f)(long long, long long, double, long long, long long, double);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4, a5);
}
static long long call_IIDIDI_to_i(void *fn, long long a0, long long a1, double a2, long long a3, double a4, long long a5) {
    long long (*f)(long long, long long, double, long long, double, long long);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4, a5);
}
static long long call_IIDIDD_to_i(void *fn, long long a0, long long a1, double a2, long long a3, double a4, double a5) {
    long long (*f)(long long, long long, double, long long, double, double);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4, a5);
}
static long long call_IIDDII_to_i(void *fn, long long a0, long long a1, double a2, double a3, long long a4, long long a5) {
    long long (*f)(long long, long long, double, double, long long, long long);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4, a5);
}
static long long call_IIDDID_to_i(void *fn, long long a0, long long a1, double a2, double a3, long long a4, double a5) {
    long long (*f)(long long, long long, double, double, long long, double);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4, a5);
}
static long long call_IIDDDI_to_i(void *fn, long long a0, long long a1, double a2, double a3, double a4, long long a5) {
    long long (*f)(long long, long long, double, double, double, long long);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4, a5);
}
static long long call_IIDDDD_to_i(void *fn, long long a0, long long a1, double a2, double a3, double a4, double a5) {
    long long (*f)(long long, long long, double, double, double, double);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4, a5);
}
static long long call_IDIIII_to_i(void *fn, long long a0, double a1, long long a2, long long a3, long long a4, long long a5) {
    long long (*f)(long long, double, long long, long long, long long, long long);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4, a5);
}
static long long call_IDIIID_to_i(void *fn, long long a0, double a1, long long a2, long long a3, long long a4, double a5) {
    long long (*f)(long long, double, long long, long long, long long, double);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4, a5);
}
static long long call_IDIIDI_to_i(void *fn, long long a0, double a1, long long a2, long long a3, double a4, long long a5) {
    long long (*f)(long long, double, long long, long long, double, long long);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4, a5);
}
static long long call_IDIIDD_to_i(void *fn, long long a0, double a1, long long a2, long long a3, double a4, double a5) {
    long long (*f)(long long, double, long long, long long, double, double);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4, a5);
}
static long long call_IDIDII_to_i(void *fn, long long a0, double a1, long long a2, double a3, long long a4, long long a5) {
    long long (*f)(long long, double, long long, double, long long, long long);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4, a5);
}
static long long call_IDIDID_to_i(void *fn, long long a0, double a1, long long a2, double a3, long long a4, double a5) {
    long long (*f)(long long, double, long long, double, long long, double);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4, a5);
}
static long long call_IDIDDI_to_i(void *fn, long long a0, double a1, long long a2, double a3, double a4, long long a5) {
    long long (*f)(long long, double, long long, double, double, long long);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4, a5);
}
static long long call_IDIDDD_to_i(void *fn, long long a0, double a1, long long a2, double a3, double a4, double a5) {
    long long (*f)(long long, double, long long, double, double, double);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4, a5);
}
static long long call_IDDIII_to_i(void *fn, long long a0, double a1, double a2, long long a3, long long a4, long long a5) {
    long long (*f)(long long, double, double, long long, long long, long long);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4, a5);
}
static long long call_IDDIID_to_i(void *fn, long long a0, double a1, double a2, long long a3, long long a4, double a5) {
    long long (*f)(long long, double, double, long long, long long, double);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4, a5);
}
static long long call_IDDIDI_to_i(void *fn, long long a0, double a1, double a2, long long a3, double a4, long long a5) {
    long long (*f)(long long, double, double, long long, double, long long);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4, a5);
}
static long long call_IDDIDD_to_i(void *fn, long long a0, double a1, double a2, long long a3, double a4, double a5) {
    long long (*f)(long long, double, double, long long, double, double);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4, a5);
}
static long long call_IDDDII_to_i(void *fn, long long a0, double a1, double a2, double a3, long long a4, long long a5) {
    long long (*f)(long long, double, double, double, long long, long long);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4, a5);
}
static long long call_IDDDID_to_i(void *fn, long long a0, double a1, double a2, double a3, long long a4, double a5) {
    long long (*f)(long long, double, double, double, long long, double);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4, a5);
}
static long long call_IDDDDI_to_i(void *fn, long long a0, double a1, double a2, double a3, double a4, long long a5) {
    long long (*f)(long long, double, double, double, double, long long);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4, a5);
}
static long long call_IDDDDD_to_i(void *fn, long long a0, double a1, double a2, double a3, double a4, double a5) {
    long long (*f)(long long, double, double, double, double, double);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4, a5);
}
static long long call_DIIIII_to_i(void *fn, double a0, long long a1, long long a2, long long a3, long long a4, long long a5) {
    long long (*f)(double, long long, long long, long long, long long, long long);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4, a5);
}
static long long call_DIIIID_to_i(void *fn, double a0, long long a1, long long a2, long long a3, long long a4, double a5) {
    long long (*f)(double, long long, long long, long long, long long, double);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4, a5);
}
static long long call_DIIIDI_to_i(void *fn, double a0, long long a1, long long a2, long long a3, double a4, long long a5) {
    long long (*f)(double, long long, long long, long long, double, long long);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4, a5);
}
static long long call_DIIIDD_to_i(void *fn, double a0, long long a1, long long a2, long long a3, double a4, double a5) {
    long long (*f)(double, long long, long long, long long, double, double);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4, a5);
}
static long long call_DIIDII_to_i(void *fn, double a0, long long a1, long long a2, double a3, long long a4, long long a5) {
    long long (*f)(double, long long, long long, double, long long, long long);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4, a5);
}
static long long call_DIIDID_to_i(void *fn, double a0, long long a1, long long a2, double a3, long long a4, double a5) {
    long long (*f)(double, long long, long long, double, long long, double);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4, a5);
}
static long long call_DIIDDI_to_i(void *fn, double a0, long long a1, long long a2, double a3, double a4, long long a5) {
    long long (*f)(double, long long, long long, double, double, long long);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4, a5);
}
static long long call_DIIDDD_to_i(void *fn, double a0, long long a1, long long a2, double a3, double a4, double a5) {
    long long (*f)(double, long long, long long, double, double, double);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4, a5);
}
static long long call_DIDIII_to_i(void *fn, double a0, long long a1, double a2, long long a3, long long a4, long long a5) {
    long long (*f)(double, long long, double, long long, long long, long long);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4, a5);
}
static long long call_DIDIID_to_i(void *fn, double a0, long long a1, double a2, long long a3, long long a4, double a5) {
    long long (*f)(double, long long, double, long long, long long, double);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4, a5);
}
static long long call_DIDIDI_to_i(void *fn, double a0, long long a1, double a2, long long a3, double a4, long long a5) {
    long long (*f)(double, long long, double, long long, double, long long);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4, a5);
}
static long long call_DIDIDD_to_i(void *fn, double a0, long long a1, double a2, long long a3, double a4, double a5) {
    long long (*f)(double, long long, double, long long, double, double);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4, a5);
}
static long long call_DIDDII_to_i(void *fn, double a0, long long a1, double a2, double a3, long long a4, long long a5) {
    long long (*f)(double, long long, double, double, long long, long long);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4, a5);
}
static long long call_DIDDID_to_i(void *fn, double a0, long long a1, double a2, double a3, long long a4, double a5) {
    long long (*f)(double, long long, double, double, long long, double);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4, a5);
}
static long long call_DIDDDI_to_i(void *fn, double a0, long long a1, double a2, double a3, double a4, long long a5) {
    long long (*f)(double, long long, double, double, double, long long);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4, a5);
}
static long long call_DIDDDD_to_i(void *fn, double a0, long long a1, double a2, double a3, double a4, double a5) {
    long long (*f)(double, long long, double, double, double, double);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4, a5);
}
static long long call_DDIIII_to_i(void *fn, double a0, double a1, long long a2, long long a3, long long a4, long long a5) {
    long long (*f)(double, double, long long, long long, long long, long long);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4, a5);
}
static long long call_DDIIID_to_i(void *fn, double a0, double a1, long long a2, long long a3, long long a4, double a5) {
    long long (*f)(double, double, long long, long long, long long, double);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4, a5);
}
static long long call_DDIIDI_to_i(void *fn, double a0, double a1, long long a2, long long a3, double a4, long long a5) {
    long long (*f)(double, double, long long, long long, double, long long);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4, a5);
}
static long long call_DDIIDD_to_i(void *fn, double a0, double a1, long long a2, long long a3, double a4, double a5) {
    long long (*f)(double, double, long long, long long, double, double);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4, a5);
}
static long long call_DDIDII_to_i(void *fn, double a0, double a1, long long a2, double a3, long long a4, long long a5) {
    long long (*f)(double, double, long long, double, long long, long long);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4, a5);
}
static long long call_DDIDID_to_i(void *fn, double a0, double a1, long long a2, double a3, long long a4, double a5) {
    long long (*f)(double, double, long long, double, long long, double);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4, a5);
}
static long long call_DDIDDI_to_i(void *fn, double a0, double a1, long long a2, double a3, double a4, long long a5) {
    long long (*f)(double, double, long long, double, double, long long);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4, a5);
}
static long long call_DDIDDD_to_i(void *fn, double a0, double a1, long long a2, double a3, double a4, double a5) {
    long long (*f)(double, double, long long, double, double, double);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4, a5);
}
static long long call_DDDIII_to_i(void *fn, double a0, double a1, double a2, long long a3, long long a4, long long a5) {
    long long (*f)(double, double, double, long long, long long, long long);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4, a5);
}
static long long call_DDDIID_to_i(void *fn, double a0, double a1, double a2, long long a3, long long a4, double a5) {
    long long (*f)(double, double, double, long long, long long, double);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4, a5);
}
static long long call_DDDIDI_to_i(void *fn, double a0, double a1, double a2, long long a3, double a4, long long a5) {
    long long (*f)(double, double, double, long long, double, long long);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4, a5);
}
static long long call_DDDIDD_to_i(void *fn, double a0, double a1, double a2, long long a3, double a4, double a5) {
    long long (*f)(double, double, double, long long, double, double);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4, a5);
}
static long long call_DDDDII_to_i(void *fn, double a0, double a1, double a2, double a3, long long a4, long long a5) {
    long long (*f)(double, double, double, double, long long, long long);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4, a5);
}
static long long call_DDDDID_to_i(void *fn, double a0, double a1, double a2, double a3, long long a4, double a5) {
    long long (*f)(double, double, double, double, long long, double);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4, a5);
}
static long long call_DDDDDI_to_i(void *fn, double a0, double a1, double a2, double a3, double a4, long long a5) {
    long long (*f)(double, double, double, double, double, long long);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4, a5);
}
static long long call_DDDDDD_to_i(void *fn, double a0, double a1, double a2, double a3, double a4, double a5) {
    long long (*f)(double, double, double, double, double, double);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4, a5);
}

/* ---- return type: double ---- */
static double call_0_to_d(void *fn) {
    double (*f)(void);
    memcpy(&f, &fn, sizeof f);
    return f();
}
static double call_I_to_d(void *fn, long long a0) {
    double (*f)(long long);
    memcpy(&f, &fn, sizeof f);
    return f(a0);
}
static double call_D_to_d(void *fn, double a0) {
    double (*f)(double);
    memcpy(&f, &fn, sizeof f);
    return f(a0);
}
static double call_II_to_d(void *fn, long long a0, long long a1) {
    double (*f)(long long, long long);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1);
}
static double call_ID_to_d(void *fn, long long a0, double a1) {
    double (*f)(long long, double);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1);
}
static double call_DI_to_d(void *fn, double a0, long long a1) {
    double (*f)(double, long long);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1);
}
static double call_DD_to_d(void *fn, double a0, double a1) {
    double (*f)(double, double);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1);
}
static double call_III_to_d(void *fn, long long a0, long long a1, long long a2) {
    double (*f)(long long, long long, long long);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2);
}
static double call_IID_to_d(void *fn, long long a0, long long a1, double a2) {
    double (*f)(long long, long long, double);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2);
}
static double call_IDI_to_d(void *fn, long long a0, double a1, long long a2) {
    double (*f)(long long, double, long long);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2);
}
static double call_IDD_to_d(void *fn, long long a0, double a1, double a2) {
    double (*f)(long long, double, double);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2);
}
static double call_DII_to_d(void *fn, double a0, long long a1, long long a2) {
    double (*f)(double, long long, long long);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2);
}
static double call_DID_to_d(void *fn, double a0, long long a1, double a2) {
    double (*f)(double, long long, double);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2);
}
static double call_DDI_to_d(void *fn, double a0, double a1, long long a2) {
    double (*f)(double, double, long long);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2);
}
static double call_DDD_to_d(void *fn, double a0, double a1, double a2) {
    double (*f)(double, double, double);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2);
}
static double call_IIII_to_d(void *fn, long long a0, long long a1, long long a2, long long a3) {
    double (*f)(long long, long long, long long, long long);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3);
}
static double call_IIID_to_d(void *fn, long long a0, long long a1, long long a2, double a3) {
    double (*f)(long long, long long, long long, double);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3);
}
static double call_IIDI_to_d(void *fn, long long a0, long long a1, double a2, long long a3) {
    double (*f)(long long, long long, double, long long);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3);
}
static double call_IIDD_to_d(void *fn, long long a0, long long a1, double a2, double a3) {
    double (*f)(long long, long long, double, double);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3);
}
static double call_IDII_to_d(void *fn, long long a0, double a1, long long a2, long long a3) {
    double (*f)(long long, double, long long, long long);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3);
}
static double call_IDID_to_d(void *fn, long long a0, double a1, long long a2, double a3) {
    double (*f)(long long, double, long long, double);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3);
}
static double call_IDDI_to_d(void *fn, long long a0, double a1, double a2, long long a3) {
    double (*f)(long long, double, double, long long);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3);
}
static double call_IDDD_to_d(void *fn, long long a0, double a1, double a2, double a3) {
    double (*f)(long long, double, double, double);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3);
}
static double call_DIII_to_d(void *fn, double a0, long long a1, long long a2, long long a3) {
    double (*f)(double, long long, long long, long long);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3);
}
static double call_DIID_to_d(void *fn, double a0, long long a1, long long a2, double a3) {
    double (*f)(double, long long, long long, double);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3);
}
static double call_DIDI_to_d(void *fn, double a0, long long a1, double a2, long long a3) {
    double (*f)(double, long long, double, long long);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3);
}
static double call_DIDD_to_d(void *fn, double a0, long long a1, double a2, double a3) {
    double (*f)(double, long long, double, double);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3);
}
static double call_DDII_to_d(void *fn, double a0, double a1, long long a2, long long a3) {
    double (*f)(double, double, long long, long long);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3);
}
static double call_DDID_to_d(void *fn, double a0, double a1, long long a2, double a3) {
    double (*f)(double, double, long long, double);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3);
}
static double call_DDDI_to_d(void *fn, double a0, double a1, double a2, long long a3) {
    double (*f)(double, double, double, long long);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3);
}
static double call_DDDD_to_d(void *fn, double a0, double a1, double a2, double a3) {
    double (*f)(double, double, double, double);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3);
}
static double call_IIIII_to_d(void *fn, long long a0, long long a1, long long a2, long long a3, long long a4) {
    double (*f)(long long, long long, long long, long long, long long);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4);
}
static double call_IIIID_to_d(void *fn, long long a0, long long a1, long long a2, long long a3, double a4) {
    double (*f)(long long, long long, long long, long long, double);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4);
}
static double call_IIIDI_to_d(void *fn, long long a0, long long a1, long long a2, double a3, long long a4) {
    double (*f)(long long, long long, long long, double, long long);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4);
}
static double call_IIIDD_to_d(void *fn, long long a0, long long a1, long long a2, double a3, double a4) {
    double (*f)(long long, long long, long long, double, double);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4);
}
static double call_IIDII_to_d(void *fn, long long a0, long long a1, double a2, long long a3, long long a4) {
    double (*f)(long long, long long, double, long long, long long);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4);
}
static double call_IIDID_to_d(void *fn, long long a0, long long a1, double a2, long long a3, double a4) {
    double (*f)(long long, long long, double, long long, double);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4);
}
static double call_IIDDI_to_d(void *fn, long long a0, long long a1, double a2, double a3, long long a4) {
    double (*f)(long long, long long, double, double, long long);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4);
}
static double call_IIDDD_to_d(void *fn, long long a0, long long a1, double a2, double a3, double a4) {
    double (*f)(long long, long long, double, double, double);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4);
}
static double call_IDIII_to_d(void *fn, long long a0, double a1, long long a2, long long a3, long long a4) {
    double (*f)(long long, double, long long, long long, long long);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4);
}
static double call_IDIID_to_d(void *fn, long long a0, double a1, long long a2, long long a3, double a4) {
    double (*f)(long long, double, long long, long long, double);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4);
}
static double call_IDIDI_to_d(void *fn, long long a0, double a1, long long a2, double a3, long long a4) {
    double (*f)(long long, double, long long, double, long long);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4);
}
static double call_IDIDD_to_d(void *fn, long long a0, double a1, long long a2, double a3, double a4) {
    double (*f)(long long, double, long long, double, double);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4);
}
static double call_IDDII_to_d(void *fn, long long a0, double a1, double a2, long long a3, long long a4) {
    double (*f)(long long, double, double, long long, long long);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4);
}
static double call_IDDID_to_d(void *fn, long long a0, double a1, double a2, long long a3, double a4) {
    double (*f)(long long, double, double, long long, double);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4);
}
static double call_IDDDI_to_d(void *fn, long long a0, double a1, double a2, double a3, long long a4) {
    double (*f)(long long, double, double, double, long long);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4);
}
static double call_IDDDD_to_d(void *fn, long long a0, double a1, double a2, double a3, double a4) {
    double (*f)(long long, double, double, double, double);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4);
}
static double call_DIIII_to_d(void *fn, double a0, long long a1, long long a2, long long a3, long long a4) {
    double (*f)(double, long long, long long, long long, long long);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4);
}
static double call_DIIID_to_d(void *fn, double a0, long long a1, long long a2, long long a3, double a4) {
    double (*f)(double, long long, long long, long long, double);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4);
}
static double call_DIIDI_to_d(void *fn, double a0, long long a1, long long a2, double a3, long long a4) {
    double (*f)(double, long long, long long, double, long long);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4);
}
static double call_DIIDD_to_d(void *fn, double a0, long long a1, long long a2, double a3, double a4) {
    double (*f)(double, long long, long long, double, double);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4);
}
static double call_DIDII_to_d(void *fn, double a0, long long a1, double a2, long long a3, long long a4) {
    double (*f)(double, long long, double, long long, long long);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4);
}
static double call_DIDID_to_d(void *fn, double a0, long long a1, double a2, long long a3, double a4) {
    double (*f)(double, long long, double, long long, double);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4);
}
static double call_DIDDI_to_d(void *fn, double a0, long long a1, double a2, double a3, long long a4) {
    double (*f)(double, long long, double, double, long long);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4);
}
static double call_DIDDD_to_d(void *fn, double a0, long long a1, double a2, double a3, double a4) {
    double (*f)(double, long long, double, double, double);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4);
}
static double call_DDIII_to_d(void *fn, double a0, double a1, long long a2, long long a3, long long a4) {
    double (*f)(double, double, long long, long long, long long);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4);
}
static double call_DDIID_to_d(void *fn, double a0, double a1, long long a2, long long a3, double a4) {
    double (*f)(double, double, long long, long long, double);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4);
}
static double call_DDIDI_to_d(void *fn, double a0, double a1, long long a2, double a3, long long a4) {
    double (*f)(double, double, long long, double, long long);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4);
}
static double call_DDIDD_to_d(void *fn, double a0, double a1, long long a2, double a3, double a4) {
    double (*f)(double, double, long long, double, double);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4);
}
static double call_DDDII_to_d(void *fn, double a0, double a1, double a2, long long a3, long long a4) {
    double (*f)(double, double, double, long long, long long);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4);
}
static double call_DDDID_to_d(void *fn, double a0, double a1, double a2, long long a3, double a4) {
    double (*f)(double, double, double, long long, double);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4);
}
static double call_DDDDI_to_d(void *fn, double a0, double a1, double a2, double a3, long long a4) {
    double (*f)(double, double, double, double, long long);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4);
}
static double call_DDDDD_to_d(void *fn, double a0, double a1, double a2, double a3, double a4) {
    double (*f)(double, double, double, double, double);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4);
}
static double call_IIIIII_to_d(void *fn, long long a0, long long a1, long long a2, long long a3, long long a4, long long a5) {
    double (*f)(long long, long long, long long, long long, long long, long long);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4, a5);
}
static double call_IIIIID_to_d(void *fn, long long a0, long long a1, long long a2, long long a3, long long a4, double a5) {
    double (*f)(long long, long long, long long, long long, long long, double);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4, a5);
}
static double call_IIIIDI_to_d(void *fn, long long a0, long long a1, long long a2, long long a3, double a4, long long a5) {
    double (*f)(long long, long long, long long, long long, double, long long);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4, a5);
}
static double call_IIIIDD_to_d(void *fn, long long a0, long long a1, long long a2, long long a3, double a4, double a5) {
    double (*f)(long long, long long, long long, long long, double, double);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4, a5);
}
static double call_IIIDII_to_d(void *fn, long long a0, long long a1, long long a2, double a3, long long a4, long long a5) {
    double (*f)(long long, long long, long long, double, long long, long long);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4, a5);
}
static double call_IIIDID_to_d(void *fn, long long a0, long long a1, long long a2, double a3, long long a4, double a5) {
    double (*f)(long long, long long, long long, double, long long, double);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4, a5);
}
static double call_IIIDDI_to_d(void *fn, long long a0, long long a1, long long a2, double a3, double a4, long long a5) {
    double (*f)(long long, long long, long long, double, double, long long);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4, a5);
}
static double call_IIIDDD_to_d(void *fn, long long a0, long long a1, long long a2, double a3, double a4, double a5) {
    double (*f)(long long, long long, long long, double, double, double);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4, a5);
}
static double call_IIDIII_to_d(void *fn, long long a0, long long a1, double a2, long long a3, long long a4, long long a5) {
    double (*f)(long long, long long, double, long long, long long, long long);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4, a5);
}
static double call_IIDIID_to_d(void *fn, long long a0, long long a1, double a2, long long a3, long long a4, double a5) {
    double (*f)(long long, long long, double, long long, long long, double);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4, a5);
}
static double call_IIDIDI_to_d(void *fn, long long a0, long long a1, double a2, long long a3, double a4, long long a5) {
    double (*f)(long long, long long, double, long long, double, long long);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4, a5);
}
static double call_IIDIDD_to_d(void *fn, long long a0, long long a1, double a2, long long a3, double a4, double a5) {
    double (*f)(long long, long long, double, long long, double, double);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4, a5);
}
static double call_IIDDII_to_d(void *fn, long long a0, long long a1, double a2, double a3, long long a4, long long a5) {
    double (*f)(long long, long long, double, double, long long, long long);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4, a5);
}
static double call_IIDDID_to_d(void *fn, long long a0, long long a1, double a2, double a3, long long a4, double a5) {
    double (*f)(long long, long long, double, double, long long, double);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4, a5);
}
static double call_IIDDDI_to_d(void *fn, long long a0, long long a1, double a2, double a3, double a4, long long a5) {
    double (*f)(long long, long long, double, double, double, long long);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4, a5);
}
static double call_IIDDDD_to_d(void *fn, long long a0, long long a1, double a2, double a3, double a4, double a5) {
    double (*f)(long long, long long, double, double, double, double);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4, a5);
}
static double call_IDIIII_to_d(void *fn, long long a0, double a1, long long a2, long long a3, long long a4, long long a5) {
    double (*f)(long long, double, long long, long long, long long, long long);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4, a5);
}
static double call_IDIIID_to_d(void *fn, long long a0, double a1, long long a2, long long a3, long long a4, double a5) {
    double (*f)(long long, double, long long, long long, long long, double);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4, a5);
}
static double call_IDIIDI_to_d(void *fn, long long a0, double a1, long long a2, long long a3, double a4, long long a5) {
    double (*f)(long long, double, long long, long long, double, long long);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4, a5);
}
static double call_IDIIDD_to_d(void *fn, long long a0, double a1, long long a2, long long a3, double a4, double a5) {
    double (*f)(long long, double, long long, long long, double, double);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4, a5);
}
static double call_IDIDII_to_d(void *fn, long long a0, double a1, long long a2, double a3, long long a4, long long a5) {
    double (*f)(long long, double, long long, double, long long, long long);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4, a5);
}
static double call_IDIDID_to_d(void *fn, long long a0, double a1, long long a2, double a3, long long a4, double a5) {
    double (*f)(long long, double, long long, double, long long, double);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4, a5);
}
static double call_IDIDDI_to_d(void *fn, long long a0, double a1, long long a2, double a3, double a4, long long a5) {
    double (*f)(long long, double, long long, double, double, long long);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4, a5);
}
static double call_IDIDDD_to_d(void *fn, long long a0, double a1, long long a2, double a3, double a4, double a5) {
    double (*f)(long long, double, long long, double, double, double);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4, a5);
}
static double call_IDDIII_to_d(void *fn, long long a0, double a1, double a2, long long a3, long long a4, long long a5) {
    double (*f)(long long, double, double, long long, long long, long long);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4, a5);
}
static double call_IDDIID_to_d(void *fn, long long a0, double a1, double a2, long long a3, long long a4, double a5) {
    double (*f)(long long, double, double, long long, long long, double);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4, a5);
}
static double call_IDDIDI_to_d(void *fn, long long a0, double a1, double a2, long long a3, double a4, long long a5) {
    double (*f)(long long, double, double, long long, double, long long);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4, a5);
}
static double call_IDDIDD_to_d(void *fn, long long a0, double a1, double a2, long long a3, double a4, double a5) {
    double (*f)(long long, double, double, long long, double, double);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4, a5);
}
static double call_IDDDII_to_d(void *fn, long long a0, double a1, double a2, double a3, long long a4, long long a5) {
    double (*f)(long long, double, double, double, long long, long long);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4, a5);
}
static double call_IDDDID_to_d(void *fn, long long a0, double a1, double a2, double a3, long long a4, double a5) {
    double (*f)(long long, double, double, double, long long, double);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4, a5);
}
static double call_IDDDDI_to_d(void *fn, long long a0, double a1, double a2, double a3, double a4, long long a5) {
    double (*f)(long long, double, double, double, double, long long);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4, a5);
}
static double call_IDDDDD_to_d(void *fn, long long a0, double a1, double a2, double a3, double a4, double a5) {
    double (*f)(long long, double, double, double, double, double);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4, a5);
}
static double call_DIIIII_to_d(void *fn, double a0, long long a1, long long a2, long long a3, long long a4, long long a5) {
    double (*f)(double, long long, long long, long long, long long, long long);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4, a5);
}
static double call_DIIIID_to_d(void *fn, double a0, long long a1, long long a2, long long a3, long long a4, double a5) {
    double (*f)(double, long long, long long, long long, long long, double);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4, a5);
}
static double call_DIIIDI_to_d(void *fn, double a0, long long a1, long long a2, long long a3, double a4, long long a5) {
    double (*f)(double, long long, long long, long long, double, long long);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4, a5);
}
static double call_DIIIDD_to_d(void *fn, double a0, long long a1, long long a2, long long a3, double a4, double a5) {
    double (*f)(double, long long, long long, long long, double, double);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4, a5);
}
static double call_DIIDII_to_d(void *fn, double a0, long long a1, long long a2, double a3, long long a4, long long a5) {
    double (*f)(double, long long, long long, double, long long, long long);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4, a5);
}
static double call_DIIDID_to_d(void *fn, double a0, long long a1, long long a2, double a3, long long a4, double a5) {
    double (*f)(double, long long, long long, double, long long, double);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4, a5);
}
static double call_DIIDDI_to_d(void *fn, double a0, long long a1, long long a2, double a3, double a4, long long a5) {
    double (*f)(double, long long, long long, double, double, long long);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4, a5);
}
static double call_DIIDDD_to_d(void *fn, double a0, long long a1, long long a2, double a3, double a4, double a5) {
    double (*f)(double, long long, long long, double, double, double);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4, a5);
}
static double call_DIDIII_to_d(void *fn, double a0, long long a1, double a2, long long a3, long long a4, long long a5) {
    double (*f)(double, long long, double, long long, long long, long long);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4, a5);
}
static double call_DIDIID_to_d(void *fn, double a0, long long a1, double a2, long long a3, long long a4, double a5) {
    double (*f)(double, long long, double, long long, long long, double);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4, a5);
}
static double call_DIDIDI_to_d(void *fn, double a0, long long a1, double a2, long long a3, double a4, long long a5) {
    double (*f)(double, long long, double, long long, double, long long);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4, a5);
}
static double call_DIDIDD_to_d(void *fn, double a0, long long a1, double a2, long long a3, double a4, double a5) {
    double (*f)(double, long long, double, long long, double, double);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4, a5);
}
static double call_DIDDII_to_d(void *fn, double a0, long long a1, double a2, double a3, long long a4, long long a5) {
    double (*f)(double, long long, double, double, long long, long long);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4, a5);
}
static double call_DIDDID_to_d(void *fn, double a0, long long a1, double a2, double a3, long long a4, double a5) {
    double (*f)(double, long long, double, double, long long, double);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4, a5);
}
static double call_DIDDDI_to_d(void *fn, double a0, long long a1, double a2, double a3, double a4, long long a5) {
    double (*f)(double, long long, double, double, double, long long);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4, a5);
}
static double call_DIDDDD_to_d(void *fn, double a0, long long a1, double a2, double a3, double a4, double a5) {
    double (*f)(double, long long, double, double, double, double);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4, a5);
}
static double call_DDIIII_to_d(void *fn, double a0, double a1, long long a2, long long a3, long long a4, long long a5) {
    double (*f)(double, double, long long, long long, long long, long long);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4, a5);
}
static double call_DDIIID_to_d(void *fn, double a0, double a1, long long a2, long long a3, long long a4, double a5) {
    double (*f)(double, double, long long, long long, long long, double);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4, a5);
}
static double call_DDIIDI_to_d(void *fn, double a0, double a1, long long a2, long long a3, double a4, long long a5) {
    double (*f)(double, double, long long, long long, double, long long);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4, a5);
}
static double call_DDIIDD_to_d(void *fn, double a0, double a1, long long a2, long long a3, double a4, double a5) {
    double (*f)(double, double, long long, long long, double, double);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4, a5);
}
static double call_DDIDII_to_d(void *fn, double a0, double a1, long long a2, double a3, long long a4, long long a5) {
    double (*f)(double, double, long long, double, long long, long long);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4, a5);
}
static double call_DDIDID_to_d(void *fn, double a0, double a1, long long a2, double a3, long long a4, double a5) {
    double (*f)(double, double, long long, double, long long, double);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4, a5);
}
static double call_DDIDDI_to_d(void *fn, double a0, double a1, long long a2, double a3, double a4, long long a5) {
    double (*f)(double, double, long long, double, double, long long);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4, a5);
}
static double call_DDIDDD_to_d(void *fn, double a0, double a1, long long a2, double a3, double a4, double a5) {
    double (*f)(double, double, long long, double, double, double);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4, a5);
}
static double call_DDDIII_to_d(void *fn, double a0, double a1, double a2, long long a3, long long a4, long long a5) {
    double (*f)(double, double, double, long long, long long, long long);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4, a5);
}
static double call_DDDIID_to_d(void *fn, double a0, double a1, double a2, long long a3, long long a4, double a5) {
    double (*f)(double, double, double, long long, long long, double);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4, a5);
}
static double call_DDDIDI_to_d(void *fn, double a0, double a1, double a2, long long a3, double a4, long long a5) {
    double (*f)(double, double, double, long long, double, long long);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4, a5);
}
static double call_DDDIDD_to_d(void *fn, double a0, double a1, double a2, long long a3, double a4, double a5) {
    double (*f)(double, double, double, long long, double, double);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4, a5);
}
static double call_DDDDII_to_d(void *fn, double a0, double a1, double a2, double a3, long long a4, long long a5) {
    double (*f)(double, double, double, double, long long, long long);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4, a5);
}
static double call_DDDDID_to_d(void *fn, double a0, double a1, double a2, double a3, long long a4, double a5) {
    double (*f)(double, double, double, double, long long, double);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4, a5);
}
static double call_DDDDDI_to_d(void *fn, double a0, double a1, double a2, double a3, double a4, long long a5) {
    double (*f)(double, double, double, double, double, long long);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4, a5);
}
static double call_DDDDDD_to_d(void *fn, double a0, double a1, double a2, double a3, double a4, double a5) {
    double (*f)(double, double, double, double, double, double);
    memcpy(&f, &fn, sizeof f);
    return f(a0, a1, a2, a3, a4, a5);
}

/* ---- return type: void * ---- */
static long long call_0_to_p(void *fn) {
    void * (*f)(void);
    memcpy(&f, &fn, sizeof f);
    return (long long)(size_t)f();
}
static long long call_I_to_p(void *fn, long long a0) {
    void * (*f)(long long);
    memcpy(&f, &fn, sizeof f);
    return (long long)(size_t)f(a0);
}
static long long call_D_to_p(void *fn, double a0) {
    void * (*f)(double);
    memcpy(&f, &fn, sizeof f);
    return (long long)(size_t)f(a0);
}
static long long call_II_to_p(void *fn, long long a0, long long a1) {
    void * (*f)(long long, long long);
    memcpy(&f, &fn, sizeof f);
    return (long long)(size_t)f(a0, a1);
}
static long long call_ID_to_p(void *fn, long long a0, double a1) {
    void * (*f)(long long, double);
    memcpy(&f, &fn, sizeof f);
    return (long long)(size_t)f(a0, a1);
}
static long long call_DI_to_p(void *fn, double a0, long long a1) {
    void * (*f)(double, long long);
    memcpy(&f, &fn, sizeof f);
    return (long long)(size_t)f(a0, a1);
}
static long long call_DD_to_p(void *fn, double a0, double a1) {
    void * (*f)(double, double);
    memcpy(&f, &fn, sizeof f);
    return (long long)(size_t)f(a0, a1);
}
static long long call_III_to_p(void *fn, long long a0, long long a1, long long a2) {
    void * (*f)(long long, long long, long long);
    memcpy(&f, &fn, sizeof f);
    return (long long)(size_t)f(a0, a1, a2);
}
static long long call_IID_to_p(void *fn, long long a0, long long a1, double a2) {
    void * (*f)(long long, long long, double);
    memcpy(&f, &fn, sizeof f);
    return (long long)(size_t)f(a0, a1, a2);
}
static long long call_IDI_to_p(void *fn, long long a0, double a1, long long a2) {
    void * (*f)(long long, double, long long);
    memcpy(&f, &fn, sizeof f);
    return (long long)(size_t)f(a0, a1, a2);
}
static long long call_IDD_to_p(void *fn, long long a0, double a1, double a2) {
    void * (*f)(long long, double, double);
    memcpy(&f, &fn, sizeof f);
    return (long long)(size_t)f(a0, a1, a2);
}
static long long call_DII_to_p(void *fn, double a0, long long a1, long long a2) {
    void * (*f)(double, long long, long long);
    memcpy(&f, &fn, sizeof f);
    return (long long)(size_t)f(a0, a1, a2);
}
static long long call_DID_to_p(void *fn, double a0, long long a1, double a2) {
    void * (*f)(double, long long, double);
    memcpy(&f, &fn, sizeof f);
    return (long long)(size_t)f(a0, a1, a2);
}
static long long call_DDI_to_p(void *fn, double a0, double a1, long long a2) {
    void * (*f)(double, double, long long);
    memcpy(&f, &fn, sizeof f);
    return (long long)(size_t)f(a0, a1, a2);
}
static long long call_DDD_to_p(void *fn, double a0, double a1, double a2) {
    void * (*f)(double, double, double);
    memcpy(&f, &fn, sizeof f);
    return (long long)(size_t)f(a0, a1, a2);
}
static long long call_IIII_to_p(void *fn, long long a0, long long a1, long long a2, long long a3) {
    void * (*f)(long long, long long, long long, long long);
    memcpy(&f, &fn, sizeof f);
    return (long long)(size_t)f(a0, a1, a2, a3);
}
static long long call_IIID_to_p(void *fn, long long a0, long long a1, long long a2, double a3) {
    void * (*f)(long long, long long, long long, double);
    memcpy(&f, &fn, sizeof f);
    return (long long)(size_t)f(a0, a1, a2, a3);
}
static long long call_IIDI_to_p(void *fn, long long a0, long long a1, double a2, long long a3) {
    void * (*f)(long long, long long, double, long long);
    memcpy(&f, &fn, sizeof f);
    return (long long)(size_t)f(a0, a1, a2, a3);
}
static long long call_IIDD_to_p(void *fn, long long a0, long long a1, double a2, double a3) {
    void * (*f)(long long, long long, double, double);
    memcpy(&f, &fn, sizeof f);
    return (long long)(size_t)f(a0, a1, a2, a3);
}
static long long call_IDII_to_p(void *fn, long long a0, double a1, long long a2, long long a3) {
    void * (*f)(long long, double, long long, long long);
    memcpy(&f, &fn, sizeof f);
    return (long long)(size_t)f(a0, a1, a2, a3);
}
static long long call_IDID_to_p(void *fn, long long a0, double a1, long long a2, double a3) {
    void * (*f)(long long, double, long long, double);
    memcpy(&f, &fn, sizeof f);
    return (long long)(size_t)f(a0, a1, a2, a3);
}
static long long call_IDDI_to_p(void *fn, long long a0, double a1, double a2, long long a3) {
    void * (*f)(long long, double, double, long long);
    memcpy(&f, &fn, sizeof f);
    return (long long)(size_t)f(a0, a1, a2, a3);
}
static long long call_IDDD_to_p(void *fn, long long a0, double a1, double a2, double a3) {
    void * (*f)(long long, double, double, double);
    memcpy(&f, &fn, sizeof f);
    return (long long)(size_t)f(a0, a1, a2, a3);
}
static long long call_DIII_to_p(void *fn, double a0, long long a1, long long a2, long long a3) {
    void * (*f)(double, long long, long long, long long);
    memcpy(&f, &fn, sizeof f);
    return (long long)(size_t)f(a0, a1, a2, a3);
}
static long long call_DIID_to_p(void *fn, double a0, long long a1, long long a2, double a3) {
    void * (*f)(double, long long, long long, double);
    memcpy(&f, &fn, sizeof f);
    return (long long)(size_t)f(a0, a1, a2, a3);
}
static long long call_DIDI_to_p(void *fn, double a0, long long a1, double a2, long long a3) {
    void * (*f)(double, long long, double, long long);
    memcpy(&f, &fn, sizeof f);
    return (long long)(size_t)f(a0, a1, a2, a3);
}
static long long call_DIDD_to_p(void *fn, double a0, long long a1, double a2, double a3) {
    void * (*f)(double, long long, double, double);
    memcpy(&f, &fn, sizeof f);
    return (long long)(size_t)f(a0, a1, a2, a3);
}
static long long call_DDII_to_p(void *fn, double a0, double a1, long long a2, long long a3) {
    void * (*f)(double, double, long long, long long);
    memcpy(&f, &fn, sizeof f);
    return (long long)(size_t)f(a0, a1, a2, a3);
}
static long long call_DDID_to_p(void *fn, double a0, double a1, long long a2, double a3) {
    void * (*f)(double, double, long long, double);
    memcpy(&f, &fn, sizeof f);
    return (long long)(size_t)f(a0, a1, a2, a3);
}
static long long call_DDDI_to_p(void *fn, double a0, double a1, double a2, long long a3) {
    void * (*f)(double, double, double, long long);
    memcpy(&f, &fn, sizeof f);
    return (long long)(size_t)f(a0, a1, a2, a3);
}
static long long call_DDDD_to_p(void *fn, double a0, double a1, double a2, double a3) {
    void * (*f)(double, double, double, double);
    memcpy(&f, &fn, sizeof f);
    return (long long)(size_t)f(a0, a1, a2, a3);
}
static long long call_IIIII_to_p(void *fn, long long a0, long long a1, long long a2, long long a3, long long a4) {
    void * (*f)(long long, long long, long long, long long, long long);
    memcpy(&f, &fn, sizeof f);
    return (long long)(size_t)f(a0, a1, a2, a3, a4);
}
static long long call_IIIID_to_p(void *fn, long long a0, long long a1, long long a2, long long a3, double a4) {
    void * (*f)(long long, long long, long long, long long, double);
    memcpy(&f, &fn, sizeof f);
    return (long long)(size_t)f(a0, a1, a2, a3, a4);
}
static long long call_IIIDI_to_p(void *fn, long long a0, long long a1, long long a2, double a3, long long a4) {
    void * (*f)(long long, long long, long long, double, long long);
    memcpy(&f, &fn, sizeof f);
    return (long long)(size_t)f(a0, a1, a2, a3, a4);
}
static long long call_IIIDD_to_p(void *fn, long long a0, long long a1, long long a2, double a3, double a4) {
    void * (*f)(long long, long long, long long, double, double);
    memcpy(&f, &fn, sizeof f);
    return (long long)(size_t)f(a0, a1, a2, a3, a4);
}
static long long call_IIDII_to_p(void *fn, long long a0, long long a1, double a2, long long a3, long long a4) {
    void * (*f)(long long, long long, double, long long, long long);
    memcpy(&f, &fn, sizeof f);
    return (long long)(size_t)f(a0, a1, a2, a3, a4);
}
static long long call_IIDID_to_p(void *fn, long long a0, long long a1, double a2, long long a3, double a4) {
    void * (*f)(long long, long long, double, long long, double);
    memcpy(&f, &fn, sizeof f);
    return (long long)(size_t)f(a0, a1, a2, a3, a4);
}
static long long call_IIDDI_to_p(void *fn, long long a0, long long a1, double a2, double a3, long long a4) {
    void * (*f)(long long, long long, double, double, long long);
    memcpy(&f, &fn, sizeof f);
    return (long long)(size_t)f(a0, a1, a2, a3, a4);
}
static long long call_IIDDD_to_p(void *fn, long long a0, long long a1, double a2, double a3, double a4) {
    void * (*f)(long long, long long, double, double, double);
    memcpy(&f, &fn, sizeof f);
    return (long long)(size_t)f(a0, a1, a2, a3, a4);
}
static long long call_IDIII_to_p(void *fn, long long a0, double a1, long long a2, long long a3, long long a4) {
    void * (*f)(long long, double, long long, long long, long long);
    memcpy(&f, &fn, sizeof f);
    return (long long)(size_t)f(a0, a1, a2, a3, a4);
}
static long long call_IDIID_to_p(void *fn, long long a0, double a1, long long a2, long long a3, double a4) {
    void * (*f)(long long, double, long long, long long, double);
    memcpy(&f, &fn, sizeof f);
    return (long long)(size_t)f(a0, a1, a2, a3, a4);
}
static long long call_IDIDI_to_p(void *fn, long long a0, double a1, long long a2, double a3, long long a4) {
    void * (*f)(long long, double, long long, double, long long);
    memcpy(&f, &fn, sizeof f);
    return (long long)(size_t)f(a0, a1, a2, a3, a4);
}
static long long call_IDIDD_to_p(void *fn, long long a0, double a1, long long a2, double a3, double a4) {
    void * (*f)(long long, double, long long, double, double);
    memcpy(&f, &fn, sizeof f);
    return (long long)(size_t)f(a0, a1, a2, a3, a4);
}
static long long call_IDDII_to_p(void *fn, long long a0, double a1, double a2, long long a3, long long a4) {
    void * (*f)(long long, double, double, long long, long long);
    memcpy(&f, &fn, sizeof f);
    return (long long)(size_t)f(a0, a1, a2, a3, a4);
}
static long long call_IDDID_to_p(void *fn, long long a0, double a1, double a2, long long a3, double a4) {
    void * (*f)(long long, double, double, long long, double);
    memcpy(&f, &fn, sizeof f);
    return (long long)(size_t)f(a0, a1, a2, a3, a4);
}
static long long call_IDDDI_to_p(void *fn, long long a0, double a1, double a2, double a3, long long a4) {
    void * (*f)(long long, double, double, double, long long);
    memcpy(&f, &fn, sizeof f);
    return (long long)(size_t)f(a0, a1, a2, a3, a4);
}
static long long call_IDDDD_to_p(void *fn, long long a0, double a1, double a2, double a3, double a4) {
    void * (*f)(long long, double, double, double, double);
    memcpy(&f, &fn, sizeof f);
    return (long long)(size_t)f(a0, a1, a2, a3, a4);
}
static long long call_DIIII_to_p(void *fn, double a0, long long a1, long long a2, long long a3, long long a4) {
    void * (*f)(double, long long, long long, long long, long long);
    memcpy(&f, &fn, sizeof f);
    return (long long)(size_t)f(a0, a1, a2, a3, a4);
}
static long long call_DIIID_to_p(void *fn, double a0, long long a1, long long a2, long long a3, double a4) {
    void * (*f)(double, long long, long long, long long, double);
    memcpy(&f, &fn, sizeof f);
    return (long long)(size_t)f(a0, a1, a2, a3, a4);
}
static long long call_DIIDI_to_p(void *fn, double a0, long long a1, long long a2, double a3, long long a4) {
    void * (*f)(double, long long, long long, double, long long);
    memcpy(&f, &fn, sizeof f);
    return (long long)(size_t)f(a0, a1, a2, a3, a4);
}
static long long call_DIIDD_to_p(void *fn, double a0, long long a1, long long a2, double a3, double a4) {
    void * (*f)(double, long long, long long, double, double);
    memcpy(&f, &fn, sizeof f);
    return (long long)(size_t)f(a0, a1, a2, a3, a4);
}
static long long call_DIDII_to_p(void *fn, double a0, long long a1, double a2, long long a3, long long a4) {
    void * (*f)(double, long long, double, long long, long long);
    memcpy(&f, &fn, sizeof f);
    return (long long)(size_t)f(a0, a1, a2, a3, a4);
}
static long long call_DIDID_to_p(void *fn, double a0, long long a1, double a2, long long a3, double a4) {
    void * (*f)(double, long long, double, long long, double);
    memcpy(&f, &fn, sizeof f);
    return (long long)(size_t)f(a0, a1, a2, a3, a4);
}
static long long call_DIDDI_to_p(void *fn, double a0, long long a1, double a2, double a3, long long a4) {
    void * (*f)(double, long long, double, double, long long);
    memcpy(&f, &fn, sizeof f);
    return (long long)(size_t)f(a0, a1, a2, a3, a4);
}
static long long call_DIDDD_to_p(void *fn, double a0, long long a1, double a2, double a3, double a4) {
    void * (*f)(double, long long, double, double, double);
    memcpy(&f, &fn, sizeof f);
    return (long long)(size_t)f(a0, a1, a2, a3, a4);
}
static long long call_DDIII_to_p(void *fn, double a0, double a1, long long a2, long long a3, long long a4) {
    void * (*f)(double, double, long long, long long, long long);
    memcpy(&f, &fn, sizeof f);
    return (long long)(size_t)f(a0, a1, a2, a3, a4);
}
static long long call_DDIID_to_p(void *fn, double a0, double a1, long long a2, long long a3, double a4) {
    void * (*f)(double, double, long long, long long, double);
    memcpy(&f, &fn, sizeof f);
    return (long long)(size_t)f(a0, a1, a2, a3, a4);
}
static long long call_DDIDI_to_p(void *fn, double a0, double a1, long long a2, double a3, long long a4) {
    void * (*f)(double, double, long long, double, long long);
    memcpy(&f, &fn, sizeof f);
    return (long long)(size_t)f(a0, a1, a2, a3, a4);
}
static long long call_DDIDD_to_p(void *fn, double a0, double a1, long long a2, double a3, double a4) {
    void * (*f)(double, double, long long, double, double);
    memcpy(&f, &fn, sizeof f);
    return (long long)(size_t)f(a0, a1, a2, a3, a4);
}
static long long call_DDDII_to_p(void *fn, double a0, double a1, double a2, long long a3, long long a4) {
    void * (*f)(double, double, double, long long, long long);
    memcpy(&f, &fn, sizeof f);
    return (long long)(size_t)f(a0, a1, a2, a3, a4);
}
static long long call_DDDID_to_p(void *fn, double a0, double a1, double a2, long long a3, double a4) {
    void * (*f)(double, double, double, long long, double);
    memcpy(&f, &fn, sizeof f);
    return (long long)(size_t)f(a0, a1, a2, a3, a4);
}
static long long call_DDDDI_to_p(void *fn, double a0, double a1, double a2, double a3, long long a4) {
    void * (*f)(double, double, double, double, long long);
    memcpy(&f, &fn, sizeof f);
    return (long long)(size_t)f(a0, a1, a2, a3, a4);
}
static long long call_DDDDD_to_p(void *fn, double a0, double a1, double a2, double a3, double a4) {
    void * (*f)(double, double, double, double, double);
    memcpy(&f, &fn, sizeof f);
    return (long long)(size_t)f(a0, a1, a2, a3, a4);
}
static long long call_IIIIII_to_p(void *fn, long long a0, long long a1, long long a2, long long a3, long long a4, long long a5) {
    void * (*f)(long long, long long, long long, long long, long long, long long);
    memcpy(&f, &fn, sizeof f);
    return (long long)(size_t)f(a0, a1, a2, a3, a4, a5);
}
static long long call_IIIIID_to_p(void *fn, long long a0, long long a1, long long a2, long long a3, long long a4, double a5) {
    void * (*f)(long long, long long, long long, long long, long long, double);
    memcpy(&f, &fn, sizeof f);
    return (long long)(size_t)f(a0, a1, a2, a3, a4, a5);
}
static long long call_IIIIDI_to_p(void *fn, long long a0, long long a1, long long a2, long long a3, double a4, long long a5) {
    void * (*f)(long long, long long, long long, long long, double, long long);
    memcpy(&f, &fn, sizeof f);
    return (long long)(size_t)f(a0, a1, a2, a3, a4, a5);
}
static long long call_IIIIDD_to_p(void *fn, long long a0, long long a1, long long a2, long long a3, double a4, double a5) {
    void * (*f)(long long, long long, long long, long long, double, double);
    memcpy(&f, &fn, sizeof f);
    return (long long)(size_t)f(a0, a1, a2, a3, a4, a5);
}
static long long call_IIIDII_to_p(void *fn, long long a0, long long a1, long long a2, double a3, long long a4, long long a5) {
    void * (*f)(long long, long long, long long, double, long long, long long);
    memcpy(&f, &fn, sizeof f);
    return (long long)(size_t)f(a0, a1, a2, a3, a4, a5);
}
static long long call_IIIDID_to_p(void *fn, long long a0, long long a1, long long a2, double a3, long long a4, double a5) {
    void * (*f)(long long, long long, long long, double, long long, double);
    memcpy(&f, &fn, sizeof f);
    return (long long)(size_t)f(a0, a1, a2, a3, a4, a5);
}
static long long call_IIIDDI_to_p(void *fn, long long a0, long long a1, long long a2, double a3, double a4, long long a5) {
    void * (*f)(long long, long long, long long, double, double, long long);
    memcpy(&f, &fn, sizeof f);
    return (long long)(size_t)f(a0, a1, a2, a3, a4, a5);
}
static long long call_IIIDDD_to_p(void *fn, long long a0, long long a1, long long a2, double a3, double a4, double a5) {
    void * (*f)(long long, long long, long long, double, double, double);
    memcpy(&f, &fn, sizeof f);
    return (long long)(size_t)f(a0, a1, a2, a3, a4, a5);
}
static long long call_IIDIII_to_p(void *fn, long long a0, long long a1, double a2, long long a3, long long a4, long long a5) {
    void * (*f)(long long, long long, double, long long, long long, long long);
    memcpy(&f, &fn, sizeof f);
    return (long long)(size_t)f(a0, a1, a2, a3, a4, a5);
}
static long long call_IIDIID_to_p(void *fn, long long a0, long long a1, double a2, long long a3, long long a4, double a5) {
    void * (*f)(long long, long long, double, long long, long long, double);
    memcpy(&f, &fn, sizeof f);
    return (long long)(size_t)f(a0, a1, a2, a3, a4, a5);
}
static long long call_IIDIDI_to_p(void *fn, long long a0, long long a1, double a2, long long a3, double a4, long long a5) {
    void * (*f)(long long, long long, double, long long, double, long long);
    memcpy(&f, &fn, sizeof f);
    return (long long)(size_t)f(a0, a1, a2, a3, a4, a5);
}
static long long call_IIDIDD_to_p(void *fn, long long a0, long long a1, double a2, long long a3, double a4, double a5) {
    void * (*f)(long long, long long, double, long long, double, double);
    memcpy(&f, &fn, sizeof f);
    return (long long)(size_t)f(a0, a1, a2, a3, a4, a5);
}
static long long call_IIDDII_to_p(void *fn, long long a0, long long a1, double a2, double a3, long long a4, long long a5) {
    void * (*f)(long long, long long, double, double, long long, long long);
    memcpy(&f, &fn, sizeof f);
    return (long long)(size_t)f(a0, a1, a2, a3, a4, a5);
}
static long long call_IIDDID_to_p(void *fn, long long a0, long long a1, double a2, double a3, long long a4, double a5) {
    void * (*f)(long long, long long, double, double, long long, double);
    memcpy(&f, &fn, sizeof f);
    return (long long)(size_t)f(a0, a1, a2, a3, a4, a5);
}
static long long call_IIDDDI_to_p(void *fn, long long a0, long long a1, double a2, double a3, double a4, long long a5) {
    void * (*f)(long long, long long, double, double, double, long long);
    memcpy(&f, &fn, sizeof f);
    return (long long)(size_t)f(a0, a1, a2, a3, a4, a5);
}
static long long call_IIDDDD_to_p(void *fn, long long a0, long long a1, double a2, double a3, double a4, double a5) {
    void * (*f)(long long, long long, double, double, double, double);
    memcpy(&f, &fn, sizeof f);
    return (long long)(size_t)f(a0, a1, a2, a3, a4, a5);
}
static long long call_IDIIII_to_p(void *fn, long long a0, double a1, long long a2, long long a3, long long a4, long long a5) {
    void * (*f)(long long, double, long long, long long, long long, long long);
    memcpy(&f, &fn, sizeof f);
    return (long long)(size_t)f(a0, a1, a2, a3, a4, a5);
}
static long long call_IDIIID_to_p(void *fn, long long a0, double a1, long long a2, long long a3, long long a4, double a5) {
    void * (*f)(long long, double, long long, long long, long long, double);
    memcpy(&f, &fn, sizeof f);
    return (long long)(size_t)f(a0, a1, a2, a3, a4, a5);
}
static long long call_IDIIDI_to_p(void *fn, long long a0, double a1, long long a2, long long a3, double a4, long long a5) {
    void * (*f)(long long, double, long long, long long, double, long long);
    memcpy(&f, &fn, sizeof f);
    return (long long)(size_t)f(a0, a1, a2, a3, a4, a5);
}
static long long call_IDIIDD_to_p(void *fn, long long a0, double a1, long long a2, long long a3, double a4, double a5) {
    void * (*f)(long long, double, long long, long long, double, double);
    memcpy(&f, &fn, sizeof f);
    return (long long)(size_t)f(a0, a1, a2, a3, a4, a5);
}
static long long call_IDIDII_to_p(void *fn, long long a0, double a1, long long a2, double a3, long long a4, long long a5) {
    void * (*f)(long long, double, long long, double, long long, long long);
    memcpy(&f, &fn, sizeof f);
    return (long long)(size_t)f(a0, a1, a2, a3, a4, a5);
}
static long long call_IDIDID_to_p(void *fn, long long a0, double a1, long long a2, double a3, long long a4, double a5) {
    void * (*f)(long long, double, long long, double, long long, double);
    memcpy(&f, &fn, sizeof f);
    return (long long)(size_t)f(a0, a1, a2, a3, a4, a5);
}
static long long call_IDIDDI_to_p(void *fn, long long a0, double a1, long long a2, double a3, double a4, long long a5) {
    void * (*f)(long long, double, long long, double, double, long long);
    memcpy(&f, &fn, sizeof f);
    return (long long)(size_t)f(a0, a1, a2, a3, a4, a5);
}
static long long call_IDIDDD_to_p(void *fn, long long a0, double a1, long long a2, double a3, double a4, double a5) {
    void * (*f)(long long, double, long long, double, double, double);
    memcpy(&f, &fn, sizeof f);
    return (long long)(size_t)f(a0, a1, a2, a3, a4, a5);
}
static long long call_IDDIII_to_p(void *fn, long long a0, double a1, double a2, long long a3, long long a4, long long a5) {
    void * (*f)(long long, double, double, long long, long long, long long);
    memcpy(&f, &fn, sizeof f);
    return (long long)(size_t)f(a0, a1, a2, a3, a4, a5);
}
static long long call_IDDIID_to_p(void *fn, long long a0, double a1, double a2, long long a3, long long a4, double a5) {
    void * (*f)(long long, double, double, long long, long long, double);
    memcpy(&f, &fn, sizeof f);
    return (long long)(size_t)f(a0, a1, a2, a3, a4, a5);
}
static long long call_IDDIDI_to_p(void *fn, long long a0, double a1, double a2, long long a3, double a4, long long a5) {
    void * (*f)(long long, double, double, long long, double, long long);
    memcpy(&f, &fn, sizeof f);
    return (long long)(size_t)f(a0, a1, a2, a3, a4, a5);
}
static long long call_IDDIDD_to_p(void *fn, long long a0, double a1, double a2, long long a3, double a4, double a5) {
    void * (*f)(long long, double, double, long long, double, double);
    memcpy(&f, &fn, sizeof f);
    return (long long)(size_t)f(a0, a1, a2, a3, a4, a5);
}
static long long call_IDDDII_to_p(void *fn, long long a0, double a1, double a2, double a3, long long a4, long long a5) {
    void * (*f)(long long, double, double, double, long long, long long);
    memcpy(&f, &fn, sizeof f);
    return (long long)(size_t)f(a0, a1, a2, a3, a4, a5);
}
static long long call_IDDDID_to_p(void *fn, long long a0, double a1, double a2, double a3, long long a4, double a5) {
    void * (*f)(long long, double, double, double, long long, double);
    memcpy(&f, &fn, sizeof f);
    return (long long)(size_t)f(a0, a1, a2, a3, a4, a5);
}
static long long call_IDDDDI_to_p(void *fn, long long a0, double a1, double a2, double a3, double a4, long long a5) {
    void * (*f)(long long, double, double, double, double, long long);
    memcpy(&f, &fn, sizeof f);
    return (long long)(size_t)f(a0, a1, a2, a3, a4, a5);
}
static long long call_IDDDDD_to_p(void *fn, long long a0, double a1, double a2, double a3, double a4, double a5) {
    void * (*f)(long long, double, double, double, double, double);
    memcpy(&f, &fn, sizeof f);
    return (long long)(size_t)f(a0, a1, a2, a3, a4, a5);
}
static long long call_DIIIII_to_p(void *fn, double a0, long long a1, long long a2, long long a3, long long a4, long long a5) {
    void * (*f)(double, long long, long long, long long, long long, long long);
    memcpy(&f, &fn, sizeof f);
    return (long long)(size_t)f(a0, a1, a2, a3, a4, a5);
}
static long long call_DIIIID_to_p(void *fn, double a0, long long a1, long long a2, long long a3, long long a4, double a5) {
    void * (*f)(double, long long, long long, long long, long long, double);
    memcpy(&f, &fn, sizeof f);
    return (long long)(size_t)f(a0, a1, a2, a3, a4, a5);
}
static long long call_DIIIDI_to_p(void *fn, double a0, long long a1, long long a2, long long a3, double a4, long long a5) {
    void * (*f)(double, long long, long long, long long, double, long long);
    memcpy(&f, &fn, sizeof f);
    return (long long)(size_t)f(a0, a1, a2, a3, a4, a5);
}
static long long call_DIIIDD_to_p(void *fn, double a0, long long a1, long long a2, long long a3, double a4, double a5) {
    void * (*f)(double, long long, long long, long long, double, double);
    memcpy(&f, &fn, sizeof f);
    return (long long)(size_t)f(a0, a1, a2, a3, a4, a5);
}
static long long call_DIIDII_to_p(void *fn, double a0, long long a1, long long a2, double a3, long long a4, long long a5) {
    void * (*f)(double, long long, long long, double, long long, long long);
    memcpy(&f, &fn, sizeof f);
    return (long long)(size_t)f(a0, a1, a2, a3, a4, a5);
}
static long long call_DIIDID_to_p(void *fn, double a0, long long a1, long long a2, double a3, long long a4, double a5) {
    void * (*f)(double, long long, long long, double, long long, double);
    memcpy(&f, &fn, sizeof f);
    return (long long)(size_t)f(a0, a1, a2, a3, a4, a5);
}
static long long call_DIIDDI_to_p(void *fn, double a0, long long a1, long long a2, double a3, double a4, long long a5) {
    void * (*f)(double, long long, long long, double, double, long long);
    memcpy(&f, &fn, sizeof f);
    return (long long)(size_t)f(a0, a1, a2, a3, a4, a5);
}
static long long call_DIIDDD_to_p(void *fn, double a0, long long a1, long long a2, double a3, double a4, double a5) {
    void * (*f)(double, long long, long long, double, double, double);
    memcpy(&f, &fn, sizeof f);
    return (long long)(size_t)f(a0, a1, a2, a3, a4, a5);
}
static long long call_DIDIII_to_p(void *fn, double a0, long long a1, double a2, long long a3, long long a4, long long a5) {
    void * (*f)(double, long long, double, long long, long long, long long);
    memcpy(&f, &fn, sizeof f);
    return (long long)(size_t)f(a0, a1, a2, a3, a4, a5);
}
static long long call_DIDIID_to_p(void *fn, double a0, long long a1, double a2, long long a3, long long a4, double a5) {
    void * (*f)(double, long long, double, long long, long long, double);
    memcpy(&f, &fn, sizeof f);
    return (long long)(size_t)f(a0, a1, a2, a3, a4, a5);
}
static long long call_DIDIDI_to_p(void *fn, double a0, long long a1, double a2, long long a3, double a4, long long a5) {
    void * (*f)(double, long long, double, long long, double, long long);
    memcpy(&f, &fn, sizeof f);
    return (long long)(size_t)f(a0, a1, a2, a3, a4, a5);
}
static long long call_DIDIDD_to_p(void *fn, double a0, long long a1, double a2, long long a3, double a4, double a5) {
    void * (*f)(double, long long, double, long long, double, double);
    memcpy(&f, &fn, sizeof f);
    return (long long)(size_t)f(a0, a1, a2, a3, a4, a5);
}
static long long call_DIDDII_to_p(void *fn, double a0, long long a1, double a2, double a3, long long a4, long long a5) {
    void * (*f)(double, long long, double, double, long long, long long);
    memcpy(&f, &fn, sizeof f);
    return (long long)(size_t)f(a0, a1, a2, a3, a4, a5);
}
static long long call_DIDDID_to_p(void *fn, double a0, long long a1, double a2, double a3, long long a4, double a5) {
    void * (*f)(double, long long, double, double, long long, double);
    memcpy(&f, &fn, sizeof f);
    return (long long)(size_t)f(a0, a1, a2, a3, a4, a5);
}
static long long call_DIDDDI_to_p(void *fn, double a0, long long a1, double a2, double a3, double a4, long long a5) {
    void * (*f)(double, long long, double, double, double, long long);
    memcpy(&f, &fn, sizeof f);
    return (long long)(size_t)f(a0, a1, a2, a3, a4, a5);
}
static long long call_DIDDDD_to_p(void *fn, double a0, long long a1, double a2, double a3, double a4, double a5) {
    void * (*f)(double, long long, double, double, double, double);
    memcpy(&f, &fn, sizeof f);
    return (long long)(size_t)f(a0, a1, a2, a3, a4, a5);
}
static long long call_DDIIII_to_p(void *fn, double a0, double a1, long long a2, long long a3, long long a4, long long a5) {
    void * (*f)(double, double, long long, long long, long long, long long);
    memcpy(&f, &fn, sizeof f);
    return (long long)(size_t)f(a0, a1, a2, a3, a4, a5);
}
static long long call_DDIIID_to_p(void *fn, double a0, double a1, long long a2, long long a3, long long a4, double a5) {
    void * (*f)(double, double, long long, long long, long long, double);
    memcpy(&f, &fn, sizeof f);
    return (long long)(size_t)f(a0, a1, a2, a3, a4, a5);
}
static long long call_DDIIDI_to_p(void *fn, double a0, double a1, long long a2, long long a3, double a4, long long a5) {
    void * (*f)(double, double, long long, long long, double, long long);
    memcpy(&f, &fn, sizeof f);
    return (long long)(size_t)f(a0, a1, a2, a3, a4, a5);
}
static long long call_DDIIDD_to_p(void *fn, double a0, double a1, long long a2, long long a3, double a4, double a5) {
    void * (*f)(double, double, long long, long long, double, double);
    memcpy(&f, &fn, sizeof f);
    return (long long)(size_t)f(a0, a1, a2, a3, a4, a5);
}
static long long call_DDIDII_to_p(void *fn, double a0, double a1, long long a2, double a3, long long a4, long long a5) {
    void * (*f)(double, double, long long, double, long long, long long);
    memcpy(&f, &fn, sizeof f);
    return (long long)(size_t)f(a0, a1, a2, a3, a4, a5);
}
static long long call_DDIDID_to_p(void *fn, double a0, double a1, long long a2, double a3, long long a4, double a5) {
    void * (*f)(double, double, long long, double, long long, double);
    memcpy(&f, &fn, sizeof f);
    return (long long)(size_t)f(a0, a1, a2, a3, a4, a5);
}
static long long call_DDIDDI_to_p(void *fn, double a0, double a1, long long a2, double a3, double a4, long long a5) {
    void * (*f)(double, double, long long, double, double, long long);
    memcpy(&f, &fn, sizeof f);
    return (long long)(size_t)f(a0, a1, a2, a3, a4, a5);
}
static long long call_DDIDDD_to_p(void *fn, double a0, double a1, long long a2, double a3, double a4, double a5) {
    void * (*f)(double, double, long long, double, double, double);
    memcpy(&f, &fn, sizeof f);
    return (long long)(size_t)f(a0, a1, a2, a3, a4, a5);
}
static long long call_DDDIII_to_p(void *fn, double a0, double a1, double a2, long long a3, long long a4, long long a5) {
    void * (*f)(double, double, double, long long, long long, long long);
    memcpy(&f, &fn, sizeof f);
    return (long long)(size_t)f(a0, a1, a2, a3, a4, a5);
}
static long long call_DDDIID_to_p(void *fn, double a0, double a1, double a2, long long a3, long long a4, double a5) {
    void * (*f)(double, double, double, long long, long long, double);
    memcpy(&f, &fn, sizeof f);
    return (long long)(size_t)f(a0, a1, a2, a3, a4, a5);
}
static long long call_DDDIDI_to_p(void *fn, double a0, double a1, double a2, long long a3, double a4, long long a5) {
    void * (*f)(double, double, double, long long, double, long long);
    memcpy(&f, &fn, sizeof f);
    return (long long)(size_t)f(a0, a1, a2, a3, a4, a5);
}
static long long call_DDDIDD_to_p(void *fn, double a0, double a1, double a2, long long a3, double a4, double a5) {
    void * (*f)(double, double, double, long long, double, double);
    memcpy(&f, &fn, sizeof f);
    return (long long)(size_t)f(a0, a1, a2, a3, a4, a5);
}
static long long call_DDDDII_to_p(void *fn, double a0, double a1, double a2, double a3, long long a4, long long a5) {
    void * (*f)(double, double, double, double, long long, long long);
    memcpy(&f, &fn, sizeof f);
    return (long long)(size_t)f(a0, a1, a2, a3, a4, a5);
}
static long long call_DDDDID_to_p(void *fn, double a0, double a1, double a2, double a3, long long a4, double a5) {
    void * (*f)(double, double, double, double, long long, double);
    memcpy(&f, &fn, sizeof f);
    return (long long)(size_t)f(a0, a1, a2, a3, a4, a5);
}
static long long call_DDDDDI_to_p(void *fn, double a0, double a1, double a2, double a3, double a4, long long a5) {
    void * (*f)(double, double, double, double, double, long long);
    memcpy(&f, &fn, sizeof f);
    return (long long)(size_t)f(a0, a1, a2, a3, a4, a5);
}
static long long call_DDDDDD_to_p(void *fn, double a0, double a1, double a2, double a3, double a4, double a5) {
    void * (*f)(double, double, double, double, double, double);
    memcpy(&f, &fn, sizeof f);
    return (long long)(size_t)f(a0, a1, a2, a3, a4, a5);
}

/* ---- return type: void ---- */
static void call_0_to_v(void *fn) {
    void (*f)(void);
    memcpy(&f, &fn, sizeof f);
    f();
}
static void call_I_to_v(void *fn, long long a0) {
    void (*f)(long long);
    memcpy(&f, &fn, sizeof f);
    f(a0);
}
static void call_D_to_v(void *fn, double a0) {
    void (*f)(double);
    memcpy(&f, &fn, sizeof f);
    f(a0);
}
static void call_II_to_v(void *fn, long long a0, long long a1) {
    void (*f)(long long, long long);
    memcpy(&f, &fn, sizeof f);
    f(a0, a1);
}
static void call_ID_to_v(void *fn, long long a0, double a1) {
    void (*f)(long long, double);
    memcpy(&f, &fn, sizeof f);
    f(a0, a1);
}
static void call_DI_to_v(void *fn, double a0, long long a1) {
    void (*f)(double, long long);
    memcpy(&f, &fn, sizeof f);
    f(a0, a1);
}
static void call_DD_to_v(void *fn, double a0, double a1) {
    void (*f)(double, double);
    memcpy(&f, &fn, sizeof f);
    f(a0, a1);
}
static void call_III_to_v(void *fn, long long a0, long long a1, long long a2) {
    void (*f)(long long, long long, long long);
    memcpy(&f, &fn, sizeof f);
    f(a0, a1, a2);
}
static void call_IID_to_v(void *fn, long long a0, long long a1, double a2) {
    void (*f)(long long, long long, double);
    memcpy(&f, &fn, sizeof f);
    f(a0, a1, a2);
}
static void call_IDI_to_v(void *fn, long long a0, double a1, long long a2) {
    void (*f)(long long, double, long long);
    memcpy(&f, &fn, sizeof f);
    f(a0, a1, a2);
}
static void call_IDD_to_v(void *fn, long long a0, double a1, double a2) {
    void (*f)(long long, double, double);
    memcpy(&f, &fn, sizeof f);
    f(a0, a1, a2);
}
static void call_DII_to_v(void *fn, double a0, long long a1, long long a2) {
    void (*f)(double, long long, long long);
    memcpy(&f, &fn, sizeof f);
    f(a0, a1, a2);
}
static void call_DID_to_v(void *fn, double a0, long long a1, double a2) {
    void (*f)(double, long long, double);
    memcpy(&f, &fn, sizeof f);
    f(a0, a1, a2);
}
static void call_DDI_to_v(void *fn, double a0, double a1, long long a2) {
    void (*f)(double, double, long long);
    memcpy(&f, &fn, sizeof f);
    f(a0, a1, a2);
}
static void call_DDD_to_v(void *fn, double a0, double a1, double a2) {
    void (*f)(double, double, double);
    memcpy(&f, &fn, sizeof f);
    f(a0, a1, a2);
}
static void call_IIII_to_v(void *fn, long long a0, long long a1, long long a2, long long a3) {
    void (*f)(long long, long long, long long, long long);
    memcpy(&f, &fn, sizeof f);
    f(a0, a1, a2, a3);
}
static void call_IIID_to_v(void *fn, long long a0, long long a1, long long a2, double a3) {
    void (*f)(long long, long long, long long, double);
    memcpy(&f, &fn, sizeof f);
    f(a0, a1, a2, a3);
}
static void call_IIDI_to_v(void *fn, long long a0, long long a1, double a2, long long a3) {
    void (*f)(long long, long long, double, long long);
    memcpy(&f, &fn, sizeof f);
    f(a0, a1, a2, a3);
}
static void call_IIDD_to_v(void *fn, long long a0, long long a1, double a2, double a3) {
    void (*f)(long long, long long, double, double);
    memcpy(&f, &fn, sizeof f);
    f(a0, a1, a2, a3);
}
static void call_IDII_to_v(void *fn, long long a0, double a1, long long a2, long long a3) {
    void (*f)(long long, double, long long, long long);
    memcpy(&f, &fn, sizeof f);
    f(a0, a1, a2, a3);
}
static void call_IDID_to_v(void *fn, long long a0, double a1, long long a2, double a3) {
    void (*f)(long long, double, long long, double);
    memcpy(&f, &fn, sizeof f);
    f(a0, a1, a2, a3);
}
static void call_IDDI_to_v(void *fn, long long a0, double a1, double a2, long long a3) {
    void (*f)(long long, double, double, long long);
    memcpy(&f, &fn, sizeof f);
    f(a0, a1, a2, a3);
}
static void call_IDDD_to_v(void *fn, long long a0, double a1, double a2, double a3) {
    void (*f)(long long, double, double, double);
    memcpy(&f, &fn, sizeof f);
    f(a0, a1, a2, a3);
}
static void call_DIII_to_v(void *fn, double a0, long long a1, long long a2, long long a3) {
    void (*f)(double, long long, long long, long long);
    memcpy(&f, &fn, sizeof f);
    f(a0, a1, a2, a3);
}
static void call_DIID_to_v(void *fn, double a0, long long a1, long long a2, double a3) {
    void (*f)(double, long long, long long, double);
    memcpy(&f, &fn, sizeof f);
    f(a0, a1, a2, a3);
}
static void call_DIDI_to_v(void *fn, double a0, long long a1, double a2, long long a3) {
    void (*f)(double, long long, double, long long);
    memcpy(&f, &fn, sizeof f);
    f(a0, a1, a2, a3);
}
static void call_DIDD_to_v(void *fn, double a0, long long a1, double a2, double a3) {
    void (*f)(double, long long, double, double);
    memcpy(&f, &fn, sizeof f);
    f(a0, a1, a2, a3);
}
static void call_DDII_to_v(void *fn, double a0, double a1, long long a2, long long a3) {
    void (*f)(double, double, long long, long long);
    memcpy(&f, &fn, sizeof f);
    f(a0, a1, a2, a3);
}
static void call_DDID_to_v(void *fn, double a0, double a1, long long a2, double a3) {
    void (*f)(double, double, long long, double);
    memcpy(&f, &fn, sizeof f);
    f(a0, a1, a2, a3);
}
static void call_DDDI_to_v(void *fn, double a0, double a1, double a2, long long a3) {
    void (*f)(double, double, double, long long);
    memcpy(&f, &fn, sizeof f);
    f(a0, a1, a2, a3);
}
static void call_DDDD_to_v(void *fn, double a0, double a1, double a2, double a3) {
    void (*f)(double, double, double, double);
    memcpy(&f, &fn, sizeof f);
    f(a0, a1, a2, a3);
}
static void call_IIIII_to_v(void *fn, long long a0, long long a1, long long a2, long long a3, long long a4) {
    void (*f)(long long, long long, long long, long long, long long);
    memcpy(&f, &fn, sizeof f);
    f(a0, a1, a2, a3, a4);
}
static void call_IIIID_to_v(void *fn, long long a0, long long a1, long long a2, long long a3, double a4) {
    void (*f)(long long, long long, long long, long long, double);
    memcpy(&f, &fn, sizeof f);
    f(a0, a1, a2, a3, a4);
}
static void call_IIIDI_to_v(void *fn, long long a0, long long a1, long long a2, double a3, long long a4) {
    void (*f)(long long, long long, long long, double, long long);
    memcpy(&f, &fn, sizeof f);
    f(a0, a1, a2, a3, a4);
}
static void call_IIIDD_to_v(void *fn, long long a0, long long a1, long long a2, double a3, double a4) {
    void (*f)(long long, long long, long long, double, double);
    memcpy(&f, &fn, sizeof f);
    f(a0, a1, a2, a3, a4);
}
static void call_IIDII_to_v(void *fn, long long a0, long long a1, double a2, long long a3, long long a4) {
    void (*f)(long long, long long, double, long long, long long);
    memcpy(&f, &fn, sizeof f);
    f(a0, a1, a2, a3, a4);
}
static void call_IIDID_to_v(void *fn, long long a0, long long a1, double a2, long long a3, double a4) {
    void (*f)(long long, long long, double, long long, double);
    memcpy(&f, &fn, sizeof f);
    f(a0, a1, a2, a3, a4);
}
static void call_IIDDI_to_v(void *fn, long long a0, long long a1, double a2, double a3, long long a4) {
    void (*f)(long long, long long, double, double, long long);
    memcpy(&f, &fn, sizeof f);
    f(a0, a1, a2, a3, a4);
}
static void call_IIDDD_to_v(void *fn, long long a0, long long a1, double a2, double a3, double a4) {
    void (*f)(long long, long long, double, double, double);
    memcpy(&f, &fn, sizeof f);
    f(a0, a1, a2, a3, a4);
}
static void call_IDIII_to_v(void *fn, long long a0, double a1, long long a2, long long a3, long long a4) {
    void (*f)(long long, double, long long, long long, long long);
    memcpy(&f, &fn, sizeof f);
    f(a0, a1, a2, a3, a4);
}
static void call_IDIID_to_v(void *fn, long long a0, double a1, long long a2, long long a3, double a4) {
    void (*f)(long long, double, long long, long long, double);
    memcpy(&f, &fn, sizeof f);
    f(a0, a1, a2, a3, a4);
}
static void call_IDIDI_to_v(void *fn, long long a0, double a1, long long a2, double a3, long long a4) {
    void (*f)(long long, double, long long, double, long long);
    memcpy(&f, &fn, sizeof f);
    f(a0, a1, a2, a3, a4);
}
static void call_IDIDD_to_v(void *fn, long long a0, double a1, long long a2, double a3, double a4) {
    void (*f)(long long, double, long long, double, double);
    memcpy(&f, &fn, sizeof f);
    f(a0, a1, a2, a3, a4);
}
static void call_IDDII_to_v(void *fn, long long a0, double a1, double a2, long long a3, long long a4) {
    void (*f)(long long, double, double, long long, long long);
    memcpy(&f, &fn, sizeof f);
    f(a0, a1, a2, a3, a4);
}
static void call_IDDID_to_v(void *fn, long long a0, double a1, double a2, long long a3, double a4) {
    void (*f)(long long, double, double, long long, double);
    memcpy(&f, &fn, sizeof f);
    f(a0, a1, a2, a3, a4);
}
static void call_IDDDI_to_v(void *fn, long long a0, double a1, double a2, double a3, long long a4) {
    void (*f)(long long, double, double, double, long long);
    memcpy(&f, &fn, sizeof f);
    f(a0, a1, a2, a3, a4);
}
static void call_IDDDD_to_v(void *fn, long long a0, double a1, double a2, double a3, double a4) {
    void (*f)(long long, double, double, double, double);
    memcpy(&f, &fn, sizeof f);
    f(a0, a1, a2, a3, a4);
}
static void call_DIIII_to_v(void *fn, double a0, long long a1, long long a2, long long a3, long long a4) {
    void (*f)(double, long long, long long, long long, long long);
    memcpy(&f, &fn, sizeof f);
    f(a0, a1, a2, a3, a4);
}
static void call_DIIID_to_v(void *fn, double a0, long long a1, long long a2, long long a3, double a4) {
    void (*f)(double, long long, long long, long long, double);
    memcpy(&f, &fn, sizeof f);
    f(a0, a1, a2, a3, a4);
}
static void call_DIIDI_to_v(void *fn, double a0, long long a1, long long a2, double a3, long long a4) {
    void (*f)(double, long long, long long, double, long long);
    memcpy(&f, &fn, sizeof f);
    f(a0, a1, a2, a3, a4);
}
static void call_DIIDD_to_v(void *fn, double a0, long long a1, long long a2, double a3, double a4) {
    void (*f)(double, long long, long long, double, double);
    memcpy(&f, &fn, sizeof f);
    f(a0, a1, a2, a3, a4);
}
static void call_DIDII_to_v(void *fn, double a0, long long a1, double a2, long long a3, long long a4) {
    void (*f)(double, long long, double, long long, long long);
    memcpy(&f, &fn, sizeof f);
    f(a0, a1, a2, a3, a4);
}
static void call_DIDID_to_v(void *fn, double a0, long long a1, double a2, long long a3, double a4) {
    void (*f)(double, long long, double, long long, double);
    memcpy(&f, &fn, sizeof f);
    f(a0, a1, a2, a3, a4);
}
static void call_DIDDI_to_v(void *fn, double a0, long long a1, double a2, double a3, long long a4) {
    void (*f)(double, long long, double, double, long long);
    memcpy(&f, &fn, sizeof f);
    f(a0, a1, a2, a3, a4);
}
static void call_DIDDD_to_v(void *fn, double a0, long long a1, double a2, double a3, double a4) {
    void (*f)(double, long long, double, double, double);
    memcpy(&f, &fn, sizeof f);
    f(a0, a1, a2, a3, a4);
}
static void call_DDIII_to_v(void *fn, double a0, double a1, long long a2, long long a3, long long a4) {
    void (*f)(double, double, long long, long long, long long);
    memcpy(&f, &fn, sizeof f);
    f(a0, a1, a2, a3, a4);
}
static void call_DDIID_to_v(void *fn, double a0, double a1, long long a2, long long a3, double a4) {
    void (*f)(double, double, long long, long long, double);
    memcpy(&f, &fn, sizeof f);
    f(a0, a1, a2, a3, a4);
}
static void call_DDIDI_to_v(void *fn, double a0, double a1, long long a2, double a3, long long a4) {
    void (*f)(double, double, long long, double, long long);
    memcpy(&f, &fn, sizeof f);
    f(a0, a1, a2, a3, a4);
}
static void call_DDIDD_to_v(void *fn, double a0, double a1, long long a2, double a3, double a4) {
    void (*f)(double, double, long long, double, double);
    memcpy(&f, &fn, sizeof f);
    f(a0, a1, a2, a3, a4);
}
static void call_DDDII_to_v(void *fn, double a0, double a1, double a2, long long a3, long long a4) {
    void (*f)(double, double, double, long long, long long);
    memcpy(&f, &fn, sizeof f);
    f(a0, a1, a2, a3, a4);
}
static void call_DDDID_to_v(void *fn, double a0, double a1, double a2, long long a3, double a4) {
    void (*f)(double, double, double, long long, double);
    memcpy(&f, &fn, sizeof f);
    f(a0, a1, a2, a3, a4);
}
static void call_DDDDI_to_v(void *fn, double a0, double a1, double a2, double a3, long long a4) {
    void (*f)(double, double, double, double, long long);
    memcpy(&f, &fn, sizeof f);
    f(a0, a1, a2, a3, a4);
}
static void call_DDDDD_to_v(void *fn, double a0, double a1, double a2, double a3, double a4) {
    void (*f)(double, double, double, double, double);
    memcpy(&f, &fn, sizeof f);
    f(a0, a1, a2, a3, a4);
}
static void call_IIIIII_to_v(void *fn, long long a0, long long a1, long long a2, long long a3, long long a4, long long a5) {
    void (*f)(long long, long long, long long, long long, long long, long long);
    memcpy(&f, &fn, sizeof f);
    f(a0, a1, a2, a3, a4, a5);
}
static void call_IIIIID_to_v(void *fn, long long a0, long long a1, long long a2, long long a3, long long a4, double a5) {
    void (*f)(long long, long long, long long, long long, long long, double);
    memcpy(&f, &fn, sizeof f);
    f(a0, a1, a2, a3, a4, a5);
}
static void call_IIIIDI_to_v(void *fn, long long a0, long long a1, long long a2, long long a3, double a4, long long a5) {
    void (*f)(long long, long long, long long, long long, double, long long);
    memcpy(&f, &fn, sizeof f);
    f(a0, a1, a2, a3, a4, a5);
}
static void call_IIIIDD_to_v(void *fn, long long a0, long long a1, long long a2, long long a3, double a4, double a5) {
    void (*f)(long long, long long, long long, long long, double, double);
    memcpy(&f, &fn, sizeof f);
    f(a0, a1, a2, a3, a4, a5);
}
static void call_IIIDII_to_v(void *fn, long long a0, long long a1, long long a2, double a3, long long a4, long long a5) {
    void (*f)(long long, long long, long long, double, long long, long long);
    memcpy(&f, &fn, sizeof f);
    f(a0, a1, a2, a3, a4, a5);
}
static void call_IIIDID_to_v(void *fn, long long a0, long long a1, long long a2, double a3, long long a4, double a5) {
    void (*f)(long long, long long, long long, double, long long, double);
    memcpy(&f, &fn, sizeof f);
    f(a0, a1, a2, a3, a4, a5);
}
static void call_IIIDDI_to_v(void *fn, long long a0, long long a1, long long a2, double a3, double a4, long long a5) {
    void (*f)(long long, long long, long long, double, double, long long);
    memcpy(&f, &fn, sizeof f);
    f(a0, a1, a2, a3, a4, a5);
}
static void call_IIIDDD_to_v(void *fn, long long a0, long long a1, long long a2, double a3, double a4, double a5) {
    void (*f)(long long, long long, long long, double, double, double);
    memcpy(&f, &fn, sizeof f);
    f(a0, a1, a2, a3, a4, a5);
}
static void call_IIDIII_to_v(void *fn, long long a0, long long a1, double a2, long long a3, long long a4, long long a5) {
    void (*f)(long long, long long, double, long long, long long, long long);
    memcpy(&f, &fn, sizeof f);
    f(a0, a1, a2, a3, a4, a5);
}
static void call_IIDIID_to_v(void *fn, long long a0, long long a1, double a2, long long a3, long long a4, double a5) {
    void (*f)(long long, long long, double, long long, long long, double);
    memcpy(&f, &fn, sizeof f);
    f(a0, a1, a2, a3, a4, a5);
}
static void call_IIDIDI_to_v(void *fn, long long a0, long long a1, double a2, long long a3, double a4, long long a5) {
    void (*f)(long long, long long, double, long long, double, long long);
    memcpy(&f, &fn, sizeof f);
    f(a0, a1, a2, a3, a4, a5);
}
static void call_IIDIDD_to_v(void *fn, long long a0, long long a1, double a2, long long a3, double a4, double a5) {
    void (*f)(long long, long long, double, long long, double, double);
    memcpy(&f, &fn, sizeof f);
    f(a0, a1, a2, a3, a4, a5);
}
static void call_IIDDII_to_v(void *fn, long long a0, long long a1, double a2, double a3, long long a4, long long a5) {
    void (*f)(long long, long long, double, double, long long, long long);
    memcpy(&f, &fn, sizeof f);
    f(a0, a1, a2, a3, a4, a5);
}
static void call_IIDDID_to_v(void *fn, long long a0, long long a1, double a2, double a3, long long a4, double a5) {
    void (*f)(long long, long long, double, double, long long, double);
    memcpy(&f, &fn, sizeof f);
    f(a0, a1, a2, a3, a4, a5);
}
static void call_IIDDDI_to_v(void *fn, long long a0, long long a1, double a2, double a3, double a4, long long a5) {
    void (*f)(long long, long long, double, double, double, long long);
    memcpy(&f, &fn, sizeof f);
    f(a0, a1, a2, a3, a4, a5);
}
static void call_IIDDDD_to_v(void *fn, long long a0, long long a1, double a2, double a3, double a4, double a5) {
    void (*f)(long long, long long, double, double, double, double);
    memcpy(&f, &fn, sizeof f);
    f(a0, a1, a2, a3, a4, a5);
}
static void call_IDIIII_to_v(void *fn, long long a0, double a1, long long a2, long long a3, long long a4, long long a5) {
    void (*f)(long long, double, long long, long long, long long, long long);
    memcpy(&f, &fn, sizeof f);
    f(a0, a1, a2, a3, a4, a5);
}
static void call_IDIIID_to_v(void *fn, long long a0, double a1, long long a2, long long a3, long long a4, double a5) {
    void (*f)(long long, double, long long, long long, long long, double);
    memcpy(&f, &fn, sizeof f);
    f(a0, a1, a2, a3, a4, a5);
}
static void call_IDIIDI_to_v(void *fn, long long a0, double a1, long long a2, long long a3, double a4, long long a5) {
    void (*f)(long long, double, long long, long long, double, long long);
    memcpy(&f, &fn, sizeof f);
    f(a0, a1, a2, a3, a4, a5);
}
static void call_IDIIDD_to_v(void *fn, long long a0, double a1, long long a2, long long a3, double a4, double a5) {
    void (*f)(long long, double, long long, long long, double, double);
    memcpy(&f, &fn, sizeof f);
    f(a0, a1, a2, a3, a4, a5);
}
static void call_IDIDII_to_v(void *fn, long long a0, double a1, long long a2, double a3, long long a4, long long a5) {
    void (*f)(long long, double, long long, double, long long, long long);
    memcpy(&f, &fn, sizeof f);
    f(a0, a1, a2, a3, a4, a5);
}
static void call_IDIDID_to_v(void *fn, long long a0, double a1, long long a2, double a3, long long a4, double a5) {
    void (*f)(long long, double, long long, double, long long, double);
    memcpy(&f, &fn, sizeof f);
    f(a0, a1, a2, a3, a4, a5);
}
static void call_IDIDDI_to_v(void *fn, long long a0, double a1, long long a2, double a3, double a4, long long a5) {
    void (*f)(long long, double, long long, double, double, long long);
    memcpy(&f, &fn, sizeof f);
    f(a0, a1, a2, a3, a4, a5);
}
static void call_IDIDDD_to_v(void *fn, long long a0, double a1, long long a2, double a3, double a4, double a5) {
    void (*f)(long long, double, long long, double, double, double);
    memcpy(&f, &fn, sizeof f);
    f(a0, a1, a2, a3, a4, a5);
}
static void call_IDDIII_to_v(void *fn, long long a0, double a1, double a2, long long a3, long long a4, long long a5) {
    void (*f)(long long, double, double, long long, long long, long long);
    memcpy(&f, &fn, sizeof f);
    f(a0, a1, a2, a3, a4, a5);
}
static void call_IDDIID_to_v(void *fn, long long a0, double a1, double a2, long long a3, long long a4, double a5) {
    void (*f)(long long, double, double, long long, long long, double);
    memcpy(&f, &fn, sizeof f);
    f(a0, a1, a2, a3, a4, a5);
}
static void call_IDDIDI_to_v(void *fn, long long a0, double a1, double a2, long long a3, double a4, long long a5) {
    void (*f)(long long, double, double, long long, double, long long);
    memcpy(&f, &fn, sizeof f);
    f(a0, a1, a2, a3, a4, a5);
}
static void call_IDDIDD_to_v(void *fn, long long a0, double a1, double a2, long long a3, double a4, double a5) {
    void (*f)(long long, double, double, long long, double, double);
    memcpy(&f, &fn, sizeof f);
    f(a0, a1, a2, a3, a4, a5);
}
static void call_IDDDII_to_v(void *fn, long long a0, double a1, double a2, double a3, long long a4, long long a5) {
    void (*f)(long long, double, double, double, long long, long long);
    memcpy(&f, &fn, sizeof f);
    f(a0, a1, a2, a3, a4, a5);
}
static void call_IDDDID_to_v(void *fn, long long a0, double a1, double a2, double a3, long long a4, double a5) {
    void (*f)(long long, double, double, double, long long, double);
    memcpy(&f, &fn, sizeof f);
    f(a0, a1, a2, a3, a4, a5);
}
static void call_IDDDDI_to_v(void *fn, long long a0, double a1, double a2, double a3, double a4, long long a5) {
    void (*f)(long long, double, double, double, double, long long);
    memcpy(&f, &fn, sizeof f);
    f(a0, a1, a2, a3, a4, a5);
}
static void call_IDDDDD_to_v(void *fn, long long a0, double a1, double a2, double a3, double a4, double a5) {
    void (*f)(long long, double, double, double, double, double);
    memcpy(&f, &fn, sizeof f);
    f(a0, a1, a2, a3, a4, a5);
}
static void call_DIIIII_to_v(void *fn, double a0, long long a1, long long a2, long long a3, long long a4, long long a5) {
    void (*f)(double, long long, long long, long long, long long, long long);
    memcpy(&f, &fn, sizeof f);
    f(a0, a1, a2, a3, a4, a5);
}
static void call_DIIIID_to_v(void *fn, double a0, long long a1, long long a2, long long a3, long long a4, double a5) {
    void (*f)(double, long long, long long, long long, long long, double);
    memcpy(&f, &fn, sizeof f);
    f(a0, a1, a2, a3, a4, a5);
}
static void call_DIIIDI_to_v(void *fn, double a0, long long a1, long long a2, long long a3, double a4, long long a5) {
    void (*f)(double, long long, long long, long long, double, long long);
    memcpy(&f, &fn, sizeof f);
    f(a0, a1, a2, a3, a4, a5);
}
static void call_DIIIDD_to_v(void *fn, double a0, long long a1, long long a2, long long a3, double a4, double a5) {
    void (*f)(double, long long, long long, long long, double, double);
    memcpy(&f, &fn, sizeof f);
    f(a0, a1, a2, a3, a4, a5);
}
static void call_DIIDII_to_v(void *fn, double a0, long long a1, long long a2, double a3, long long a4, long long a5) {
    void (*f)(double, long long, long long, double, long long, long long);
    memcpy(&f, &fn, sizeof f);
    f(a0, a1, a2, a3, a4, a5);
}
static void call_DIIDID_to_v(void *fn, double a0, long long a1, long long a2, double a3, long long a4, double a5) {
    void (*f)(double, long long, long long, double, long long, double);
    memcpy(&f, &fn, sizeof f);
    f(a0, a1, a2, a3, a4, a5);
}
static void call_DIIDDI_to_v(void *fn, double a0, long long a1, long long a2, double a3, double a4, long long a5) {
    void (*f)(double, long long, long long, double, double, long long);
    memcpy(&f, &fn, sizeof f);
    f(a0, a1, a2, a3, a4, a5);
}
static void call_DIIDDD_to_v(void *fn, double a0, long long a1, long long a2, double a3, double a4, double a5) {
    void (*f)(double, long long, long long, double, double, double);
    memcpy(&f, &fn, sizeof f);
    f(a0, a1, a2, a3, a4, a5);
}
static void call_DIDIII_to_v(void *fn, double a0, long long a1, double a2, long long a3, long long a4, long long a5) {
    void (*f)(double, long long, double, long long, long long, long long);
    memcpy(&f, &fn, sizeof f);
    f(a0, a1, a2, a3, a4, a5);
}
static void call_DIDIID_to_v(void *fn, double a0, long long a1, double a2, long long a3, long long a4, double a5) {
    void (*f)(double, long long, double, long long, long long, double);
    memcpy(&f, &fn, sizeof f);
    f(a0, a1, a2, a3, a4, a5);
}
static void call_DIDIDI_to_v(void *fn, double a0, long long a1, double a2, long long a3, double a4, long long a5) {
    void (*f)(double, long long, double, long long, double, long long);
    memcpy(&f, &fn, sizeof f);
    f(a0, a1, a2, a3, a4, a5);
}
static void call_DIDIDD_to_v(void *fn, double a0, long long a1, double a2, long long a3, double a4, double a5) {
    void (*f)(double, long long, double, long long, double, double);
    memcpy(&f, &fn, sizeof f);
    f(a0, a1, a2, a3, a4, a5);
}
static void call_DIDDII_to_v(void *fn, double a0, long long a1, double a2, double a3, long long a4, long long a5) {
    void (*f)(double, long long, double, double, long long, long long);
    memcpy(&f, &fn, sizeof f);
    f(a0, a1, a2, a3, a4, a5);
}
static void call_DIDDID_to_v(void *fn, double a0, long long a1, double a2, double a3, long long a4, double a5) {
    void (*f)(double, long long, double, double, long long, double);
    memcpy(&f, &fn, sizeof f);
    f(a0, a1, a2, a3, a4, a5);
}
static void call_DIDDDI_to_v(void *fn, double a0, long long a1, double a2, double a3, double a4, long long a5) {
    void (*f)(double, long long, double, double, double, long long);
    memcpy(&f, &fn, sizeof f);
    f(a0, a1, a2, a3, a4, a5);
}
static void call_DIDDDD_to_v(void *fn, double a0, long long a1, double a2, double a3, double a4, double a5) {
    void (*f)(double, long long, double, double, double, double);
    memcpy(&f, &fn, sizeof f);
    f(a0, a1, a2, a3, a4, a5);
}
static void call_DDIIII_to_v(void *fn, double a0, double a1, long long a2, long long a3, long long a4, long long a5) {
    void (*f)(double, double, long long, long long, long long, long long);
    memcpy(&f, &fn, sizeof f);
    f(a0, a1, a2, a3, a4, a5);
}
static void call_DDIIID_to_v(void *fn, double a0, double a1, long long a2, long long a3, long long a4, double a5) {
    void (*f)(double, double, long long, long long, long long, double);
    memcpy(&f, &fn, sizeof f);
    f(a0, a1, a2, a3, a4, a5);
}
static void call_DDIIDI_to_v(void *fn, double a0, double a1, long long a2, long long a3, double a4, long long a5) {
    void (*f)(double, double, long long, long long, double, long long);
    memcpy(&f, &fn, sizeof f);
    f(a0, a1, a2, a3, a4, a5);
}
static void call_DDIIDD_to_v(void *fn, double a0, double a1, long long a2, long long a3, double a4, double a5) {
    void (*f)(double, double, long long, long long, double, double);
    memcpy(&f, &fn, sizeof f);
    f(a0, a1, a2, a3, a4, a5);
}
static void call_DDIDII_to_v(void *fn, double a0, double a1, long long a2, double a3, long long a4, long long a5) {
    void (*f)(double, double, long long, double, long long, long long);
    memcpy(&f, &fn, sizeof f);
    f(a0, a1, a2, a3, a4, a5);
}
static void call_DDIDID_to_v(void *fn, double a0, double a1, long long a2, double a3, long long a4, double a5) {
    void (*f)(double, double, long long, double, long long, double);
    memcpy(&f, &fn, sizeof f);
    f(a0, a1, a2, a3, a4, a5);
}
static void call_DDIDDI_to_v(void *fn, double a0, double a1, long long a2, double a3, double a4, long long a5) {
    void (*f)(double, double, long long, double, double, long long);
    memcpy(&f, &fn, sizeof f);
    f(a0, a1, a2, a3, a4, a5);
}
static void call_DDIDDD_to_v(void *fn, double a0, double a1, long long a2, double a3, double a4, double a5) {
    void (*f)(double, double, long long, double, double, double);
    memcpy(&f, &fn, sizeof f);
    f(a0, a1, a2, a3, a4, a5);
}
static void call_DDDIII_to_v(void *fn, double a0, double a1, double a2, long long a3, long long a4, long long a5) {
    void (*f)(double, double, double, long long, long long, long long);
    memcpy(&f, &fn, sizeof f);
    f(a0, a1, a2, a3, a4, a5);
}
static void call_DDDIID_to_v(void *fn, double a0, double a1, double a2, long long a3, long long a4, double a5) {
    void (*f)(double, double, double, long long, long long, double);
    memcpy(&f, &fn, sizeof f);
    f(a0, a1, a2, a3, a4, a5);
}
static void call_DDDIDI_to_v(void *fn, double a0, double a1, double a2, long long a3, double a4, long long a5) {
    void (*f)(double, double, double, long long, double, long long);
    memcpy(&f, &fn, sizeof f);
    f(a0, a1, a2, a3, a4, a5);
}
static void call_DDDIDD_to_v(void *fn, double a0, double a1, double a2, long long a3, double a4, double a5) {
    void (*f)(double, double, double, long long, double, double);
    memcpy(&f, &fn, sizeof f);
    f(a0, a1, a2, a3, a4, a5);
}
static void call_DDDDII_to_v(void *fn, double a0, double a1, double a2, double a3, long long a4, long long a5) {
    void (*f)(double, double, double, double, long long, long long);
    memcpy(&f, &fn, sizeof f);
    f(a0, a1, a2, a3, a4, a5);
}
static void call_DDDDID_to_v(void *fn, double a0, double a1, double a2, double a3, long long a4, double a5) {
    void (*f)(double, double, double, double, long long, double);
    memcpy(&f, &fn, sizeof f);
    f(a0, a1, a2, a3, a4, a5);
}
static void call_DDDDDI_to_v(void *fn, double a0, double a1, double a2, double a3, double a4, long long a5) {
    void (*f)(double, double, double, double, double, long long);
    memcpy(&f, &fn, sizeof f);
    f(a0, a1, a2, a3, a4, a5);
}
static void call_DDDDDD_to_v(void *fn, double a0, double a1, double a2, double a3, double a4, double a5) {
    void (*f)(double, double, double, double, double, double);
    memcpy(&f, &fn, sizeof f);
    f(a0, a1, a2, a3, a4, a5);
}

int ffi_call_dispatch(void *fn,
                      const FFIArgValue *args,
                      const FFIArgKind *arg_kinds,
                      int arg_count,
                      FFIRetKind ret_kind,
                      FFIRetValue *out) {
    if (fn == NULL) return 0;
    if (arg_count < 0 || arg_count > 6) return 0;

    /* Build the register-class pattern string ('I'/'D') and a scalar view of
     * every argument (integer-class values collapse to long long, float-class
     * to double). */
    char pat[7];
    long long iv[6];
    double dv[6];
    for (int k = 0; k < arg_count; k++) {
        switch (arg_kinds[k]) {
            case FFI_ARG_F64:
                pat[k] = 'D';
                dv[k] = args[k].d;
                iv[k] = 0;
                break;
            case FFI_ARG_I64:
                pat[k] = 'I';
                iv[k] = args[k].i;
                dv[k] = 0.0;
                break;
            case FFI_ARG_PTR:
                pat[k] = 'I';
                iv[k] = (long long)(size_t)args[k].p;
                dv[k] = 0.0;
                break;
            case FFI_ARG_STR:
                pat[k] = 'I';
                iv[k] = (long long)(size_t)args[k].s;
                dv[k] = 0.0;
                break;
            default:
                return 0;
        }
    }
    pat[arg_count] = '\0';

    switch (ret_kind) {
    case FFI_RET_I64:
        switch (arg_count) {
        case 0:
            if (1) {
                out->i = call_0_to_i(fn);
                return 1;
            }
            return 0;
        case 1:
            if (pat[0] == 'I') {
                out->i = call_I_to_i(fn, iv[0]);
                return 1;
            }
            else if (pat[0] == 'D') {
                out->i = call_D_to_i(fn, dv[0]);
                return 1;
            }
            return 0;
        case 2:
            if (pat[0] == 'I' && pat[1] == 'I') {
                out->i = call_II_to_i(fn, iv[0], iv[1]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'D') {
                out->i = call_ID_to_i(fn, iv[0], dv[1]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'I') {
                out->i = call_DI_to_i(fn, dv[0], iv[1]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'D') {
                out->i = call_DD_to_i(fn, dv[0], dv[1]);
                return 1;
            }
            return 0;
        case 3:
            if (pat[0] == 'I' && pat[1] == 'I' && pat[2] == 'I') {
                out->i = call_III_to_i(fn, iv[0], iv[1], iv[2]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'I' && pat[2] == 'D') {
                out->i = call_IID_to_i(fn, iv[0], iv[1], dv[2]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'D' && pat[2] == 'I') {
                out->i = call_IDI_to_i(fn, iv[0], dv[1], iv[2]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'D' && pat[2] == 'D') {
                out->i = call_IDD_to_i(fn, iv[0], dv[1], dv[2]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'I' && pat[2] == 'I') {
                out->i = call_DII_to_i(fn, dv[0], iv[1], iv[2]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'I' && pat[2] == 'D') {
                out->i = call_DID_to_i(fn, dv[0], iv[1], dv[2]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'D' && pat[2] == 'I') {
                out->i = call_DDI_to_i(fn, dv[0], dv[1], iv[2]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'D' && pat[2] == 'D') {
                out->i = call_DDD_to_i(fn, dv[0], dv[1], dv[2]);
                return 1;
            }
            return 0;
        case 4:
            if (pat[0] == 'I' && pat[1] == 'I' && pat[2] == 'I' && pat[3] == 'I') {
                out->i = call_IIII_to_i(fn, iv[0], iv[1], iv[2], iv[3]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'I' && pat[2] == 'I' && pat[3] == 'D') {
                out->i = call_IIID_to_i(fn, iv[0], iv[1], iv[2], dv[3]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'I' && pat[2] == 'D' && pat[3] == 'I') {
                out->i = call_IIDI_to_i(fn, iv[0], iv[1], dv[2], iv[3]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'I' && pat[2] == 'D' && pat[3] == 'D') {
                out->i = call_IIDD_to_i(fn, iv[0], iv[1], dv[2], dv[3]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'D' && pat[2] == 'I' && pat[3] == 'I') {
                out->i = call_IDII_to_i(fn, iv[0], dv[1], iv[2], iv[3]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'D' && pat[2] == 'I' && pat[3] == 'D') {
                out->i = call_IDID_to_i(fn, iv[0], dv[1], iv[2], dv[3]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'D' && pat[2] == 'D' && pat[3] == 'I') {
                out->i = call_IDDI_to_i(fn, iv[0], dv[1], dv[2], iv[3]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'D' && pat[2] == 'D' && pat[3] == 'D') {
                out->i = call_IDDD_to_i(fn, iv[0], dv[1], dv[2], dv[3]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'I' && pat[2] == 'I' && pat[3] == 'I') {
                out->i = call_DIII_to_i(fn, dv[0], iv[1], iv[2], iv[3]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'I' && pat[2] == 'I' && pat[3] == 'D') {
                out->i = call_DIID_to_i(fn, dv[0], iv[1], iv[2], dv[3]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'I' && pat[2] == 'D' && pat[3] == 'I') {
                out->i = call_DIDI_to_i(fn, dv[0], iv[1], dv[2], iv[3]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'I' && pat[2] == 'D' && pat[3] == 'D') {
                out->i = call_DIDD_to_i(fn, dv[0], iv[1], dv[2], dv[3]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'D' && pat[2] == 'I' && pat[3] == 'I') {
                out->i = call_DDII_to_i(fn, dv[0], dv[1], iv[2], iv[3]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'D' && pat[2] == 'I' && pat[3] == 'D') {
                out->i = call_DDID_to_i(fn, dv[0], dv[1], iv[2], dv[3]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'D' && pat[2] == 'D' && pat[3] == 'I') {
                out->i = call_DDDI_to_i(fn, dv[0], dv[1], dv[2], iv[3]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'D' && pat[2] == 'D' && pat[3] == 'D') {
                out->i = call_DDDD_to_i(fn, dv[0], dv[1], dv[2], dv[3]);
                return 1;
            }
            return 0;
        case 5:
            if (pat[0] == 'I' && pat[1] == 'I' && pat[2] == 'I' && pat[3] == 'I' && pat[4] == 'I') {
                out->i = call_IIIII_to_i(fn, iv[0], iv[1], iv[2], iv[3], iv[4]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'I' && pat[2] == 'I' && pat[3] == 'I' && pat[4] == 'D') {
                out->i = call_IIIID_to_i(fn, iv[0], iv[1], iv[2], iv[3], dv[4]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'I' && pat[2] == 'I' && pat[3] == 'D' && pat[4] == 'I') {
                out->i = call_IIIDI_to_i(fn, iv[0], iv[1], iv[2], dv[3], iv[4]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'I' && pat[2] == 'I' && pat[3] == 'D' && pat[4] == 'D') {
                out->i = call_IIIDD_to_i(fn, iv[0], iv[1], iv[2], dv[3], dv[4]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'I' && pat[2] == 'D' && pat[3] == 'I' && pat[4] == 'I') {
                out->i = call_IIDII_to_i(fn, iv[0], iv[1], dv[2], iv[3], iv[4]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'I' && pat[2] == 'D' && pat[3] == 'I' && pat[4] == 'D') {
                out->i = call_IIDID_to_i(fn, iv[0], iv[1], dv[2], iv[3], dv[4]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'I' && pat[2] == 'D' && pat[3] == 'D' && pat[4] == 'I') {
                out->i = call_IIDDI_to_i(fn, iv[0], iv[1], dv[2], dv[3], iv[4]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'I' && pat[2] == 'D' && pat[3] == 'D' && pat[4] == 'D') {
                out->i = call_IIDDD_to_i(fn, iv[0], iv[1], dv[2], dv[3], dv[4]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'D' && pat[2] == 'I' && pat[3] == 'I' && pat[4] == 'I') {
                out->i = call_IDIII_to_i(fn, iv[0], dv[1], iv[2], iv[3], iv[4]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'D' && pat[2] == 'I' && pat[3] == 'I' && pat[4] == 'D') {
                out->i = call_IDIID_to_i(fn, iv[0], dv[1], iv[2], iv[3], dv[4]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'D' && pat[2] == 'I' && pat[3] == 'D' && pat[4] == 'I') {
                out->i = call_IDIDI_to_i(fn, iv[0], dv[1], iv[2], dv[3], iv[4]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'D' && pat[2] == 'I' && pat[3] == 'D' && pat[4] == 'D') {
                out->i = call_IDIDD_to_i(fn, iv[0], dv[1], iv[2], dv[3], dv[4]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'D' && pat[2] == 'D' && pat[3] == 'I' && pat[4] == 'I') {
                out->i = call_IDDII_to_i(fn, iv[0], dv[1], dv[2], iv[3], iv[4]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'D' && pat[2] == 'D' && pat[3] == 'I' && pat[4] == 'D') {
                out->i = call_IDDID_to_i(fn, iv[0], dv[1], dv[2], iv[3], dv[4]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'D' && pat[2] == 'D' && pat[3] == 'D' && pat[4] == 'I') {
                out->i = call_IDDDI_to_i(fn, iv[0], dv[1], dv[2], dv[3], iv[4]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'D' && pat[2] == 'D' && pat[3] == 'D' && pat[4] == 'D') {
                out->i = call_IDDDD_to_i(fn, iv[0], dv[1], dv[2], dv[3], dv[4]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'I' && pat[2] == 'I' && pat[3] == 'I' && pat[4] == 'I') {
                out->i = call_DIIII_to_i(fn, dv[0], iv[1], iv[2], iv[3], iv[4]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'I' && pat[2] == 'I' && pat[3] == 'I' && pat[4] == 'D') {
                out->i = call_DIIID_to_i(fn, dv[0], iv[1], iv[2], iv[3], dv[4]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'I' && pat[2] == 'I' && pat[3] == 'D' && pat[4] == 'I') {
                out->i = call_DIIDI_to_i(fn, dv[0], iv[1], iv[2], dv[3], iv[4]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'I' && pat[2] == 'I' && pat[3] == 'D' && pat[4] == 'D') {
                out->i = call_DIIDD_to_i(fn, dv[0], iv[1], iv[2], dv[3], dv[4]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'I' && pat[2] == 'D' && pat[3] == 'I' && pat[4] == 'I') {
                out->i = call_DIDII_to_i(fn, dv[0], iv[1], dv[2], iv[3], iv[4]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'I' && pat[2] == 'D' && pat[3] == 'I' && pat[4] == 'D') {
                out->i = call_DIDID_to_i(fn, dv[0], iv[1], dv[2], iv[3], dv[4]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'I' && pat[2] == 'D' && pat[3] == 'D' && pat[4] == 'I') {
                out->i = call_DIDDI_to_i(fn, dv[0], iv[1], dv[2], dv[3], iv[4]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'I' && pat[2] == 'D' && pat[3] == 'D' && pat[4] == 'D') {
                out->i = call_DIDDD_to_i(fn, dv[0], iv[1], dv[2], dv[3], dv[4]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'D' && pat[2] == 'I' && pat[3] == 'I' && pat[4] == 'I') {
                out->i = call_DDIII_to_i(fn, dv[0], dv[1], iv[2], iv[3], iv[4]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'D' && pat[2] == 'I' && pat[3] == 'I' && pat[4] == 'D') {
                out->i = call_DDIID_to_i(fn, dv[0], dv[1], iv[2], iv[3], dv[4]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'D' && pat[2] == 'I' && pat[3] == 'D' && pat[4] == 'I') {
                out->i = call_DDIDI_to_i(fn, dv[0], dv[1], iv[2], dv[3], iv[4]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'D' && pat[2] == 'I' && pat[3] == 'D' && pat[4] == 'D') {
                out->i = call_DDIDD_to_i(fn, dv[0], dv[1], iv[2], dv[3], dv[4]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'D' && pat[2] == 'D' && pat[3] == 'I' && pat[4] == 'I') {
                out->i = call_DDDII_to_i(fn, dv[0], dv[1], dv[2], iv[3], iv[4]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'D' && pat[2] == 'D' && pat[3] == 'I' && pat[4] == 'D') {
                out->i = call_DDDID_to_i(fn, dv[0], dv[1], dv[2], iv[3], dv[4]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'D' && pat[2] == 'D' && pat[3] == 'D' && pat[4] == 'I') {
                out->i = call_DDDDI_to_i(fn, dv[0], dv[1], dv[2], dv[3], iv[4]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'D' && pat[2] == 'D' && pat[3] == 'D' && pat[4] == 'D') {
                out->i = call_DDDDD_to_i(fn, dv[0], dv[1], dv[2], dv[3], dv[4]);
                return 1;
            }
            return 0;
        case 6:
            if (pat[0] == 'I' && pat[1] == 'I' && pat[2] == 'I' && pat[3] == 'I' && pat[4] == 'I' && pat[5] == 'I') {
                out->i = call_IIIIII_to_i(fn, iv[0], iv[1], iv[2], iv[3], iv[4], iv[5]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'I' && pat[2] == 'I' && pat[3] == 'I' && pat[4] == 'I' && pat[5] == 'D') {
                out->i = call_IIIIID_to_i(fn, iv[0], iv[1], iv[2], iv[3], iv[4], dv[5]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'I' && pat[2] == 'I' && pat[3] == 'I' && pat[4] == 'D' && pat[5] == 'I') {
                out->i = call_IIIIDI_to_i(fn, iv[0], iv[1], iv[2], iv[3], dv[4], iv[5]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'I' && pat[2] == 'I' && pat[3] == 'I' && pat[4] == 'D' && pat[5] == 'D') {
                out->i = call_IIIIDD_to_i(fn, iv[0], iv[1], iv[2], iv[3], dv[4], dv[5]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'I' && pat[2] == 'I' && pat[3] == 'D' && pat[4] == 'I' && pat[5] == 'I') {
                out->i = call_IIIDII_to_i(fn, iv[0], iv[1], iv[2], dv[3], iv[4], iv[5]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'I' && pat[2] == 'I' && pat[3] == 'D' && pat[4] == 'I' && pat[5] == 'D') {
                out->i = call_IIIDID_to_i(fn, iv[0], iv[1], iv[2], dv[3], iv[4], dv[5]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'I' && pat[2] == 'I' && pat[3] == 'D' && pat[4] == 'D' && pat[5] == 'I') {
                out->i = call_IIIDDI_to_i(fn, iv[0], iv[1], iv[2], dv[3], dv[4], iv[5]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'I' && pat[2] == 'I' && pat[3] == 'D' && pat[4] == 'D' && pat[5] == 'D') {
                out->i = call_IIIDDD_to_i(fn, iv[0], iv[1], iv[2], dv[3], dv[4], dv[5]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'I' && pat[2] == 'D' && pat[3] == 'I' && pat[4] == 'I' && pat[5] == 'I') {
                out->i = call_IIDIII_to_i(fn, iv[0], iv[1], dv[2], iv[3], iv[4], iv[5]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'I' && pat[2] == 'D' && pat[3] == 'I' && pat[4] == 'I' && pat[5] == 'D') {
                out->i = call_IIDIID_to_i(fn, iv[0], iv[1], dv[2], iv[3], iv[4], dv[5]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'I' && pat[2] == 'D' && pat[3] == 'I' && pat[4] == 'D' && pat[5] == 'I') {
                out->i = call_IIDIDI_to_i(fn, iv[0], iv[1], dv[2], iv[3], dv[4], iv[5]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'I' && pat[2] == 'D' && pat[3] == 'I' && pat[4] == 'D' && pat[5] == 'D') {
                out->i = call_IIDIDD_to_i(fn, iv[0], iv[1], dv[2], iv[3], dv[4], dv[5]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'I' && pat[2] == 'D' && pat[3] == 'D' && pat[4] == 'I' && pat[5] == 'I') {
                out->i = call_IIDDII_to_i(fn, iv[0], iv[1], dv[2], dv[3], iv[4], iv[5]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'I' && pat[2] == 'D' && pat[3] == 'D' && pat[4] == 'I' && pat[5] == 'D') {
                out->i = call_IIDDID_to_i(fn, iv[0], iv[1], dv[2], dv[3], iv[4], dv[5]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'I' && pat[2] == 'D' && pat[3] == 'D' && pat[4] == 'D' && pat[5] == 'I') {
                out->i = call_IIDDDI_to_i(fn, iv[0], iv[1], dv[2], dv[3], dv[4], iv[5]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'I' && pat[2] == 'D' && pat[3] == 'D' && pat[4] == 'D' && pat[5] == 'D') {
                out->i = call_IIDDDD_to_i(fn, iv[0], iv[1], dv[2], dv[3], dv[4], dv[5]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'D' && pat[2] == 'I' && pat[3] == 'I' && pat[4] == 'I' && pat[5] == 'I') {
                out->i = call_IDIIII_to_i(fn, iv[0], dv[1], iv[2], iv[3], iv[4], iv[5]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'D' && pat[2] == 'I' && pat[3] == 'I' && pat[4] == 'I' && pat[5] == 'D') {
                out->i = call_IDIIID_to_i(fn, iv[0], dv[1], iv[2], iv[3], iv[4], dv[5]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'D' && pat[2] == 'I' && pat[3] == 'I' && pat[4] == 'D' && pat[5] == 'I') {
                out->i = call_IDIIDI_to_i(fn, iv[0], dv[1], iv[2], iv[3], dv[4], iv[5]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'D' && pat[2] == 'I' && pat[3] == 'I' && pat[4] == 'D' && pat[5] == 'D') {
                out->i = call_IDIIDD_to_i(fn, iv[0], dv[1], iv[2], iv[3], dv[4], dv[5]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'D' && pat[2] == 'I' && pat[3] == 'D' && pat[4] == 'I' && pat[5] == 'I') {
                out->i = call_IDIDII_to_i(fn, iv[0], dv[1], iv[2], dv[3], iv[4], iv[5]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'D' && pat[2] == 'I' && pat[3] == 'D' && pat[4] == 'I' && pat[5] == 'D') {
                out->i = call_IDIDID_to_i(fn, iv[0], dv[1], iv[2], dv[3], iv[4], dv[5]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'D' && pat[2] == 'I' && pat[3] == 'D' && pat[4] == 'D' && pat[5] == 'I') {
                out->i = call_IDIDDI_to_i(fn, iv[0], dv[1], iv[2], dv[3], dv[4], iv[5]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'D' && pat[2] == 'I' && pat[3] == 'D' && pat[4] == 'D' && pat[5] == 'D') {
                out->i = call_IDIDDD_to_i(fn, iv[0], dv[1], iv[2], dv[3], dv[4], dv[5]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'D' && pat[2] == 'D' && pat[3] == 'I' && pat[4] == 'I' && pat[5] == 'I') {
                out->i = call_IDDIII_to_i(fn, iv[0], dv[1], dv[2], iv[3], iv[4], iv[5]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'D' && pat[2] == 'D' && pat[3] == 'I' && pat[4] == 'I' && pat[5] == 'D') {
                out->i = call_IDDIID_to_i(fn, iv[0], dv[1], dv[2], iv[3], iv[4], dv[5]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'D' && pat[2] == 'D' && pat[3] == 'I' && pat[4] == 'D' && pat[5] == 'I') {
                out->i = call_IDDIDI_to_i(fn, iv[0], dv[1], dv[2], iv[3], dv[4], iv[5]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'D' && pat[2] == 'D' && pat[3] == 'I' && pat[4] == 'D' && pat[5] == 'D') {
                out->i = call_IDDIDD_to_i(fn, iv[0], dv[1], dv[2], iv[3], dv[4], dv[5]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'D' && pat[2] == 'D' && pat[3] == 'D' && pat[4] == 'I' && pat[5] == 'I') {
                out->i = call_IDDDII_to_i(fn, iv[0], dv[1], dv[2], dv[3], iv[4], iv[5]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'D' && pat[2] == 'D' && pat[3] == 'D' && pat[4] == 'I' && pat[5] == 'D') {
                out->i = call_IDDDID_to_i(fn, iv[0], dv[1], dv[2], dv[3], iv[4], dv[5]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'D' && pat[2] == 'D' && pat[3] == 'D' && pat[4] == 'D' && pat[5] == 'I') {
                out->i = call_IDDDDI_to_i(fn, iv[0], dv[1], dv[2], dv[3], dv[4], iv[5]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'D' && pat[2] == 'D' && pat[3] == 'D' && pat[4] == 'D' && pat[5] == 'D') {
                out->i = call_IDDDDD_to_i(fn, iv[0], dv[1], dv[2], dv[3], dv[4], dv[5]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'I' && pat[2] == 'I' && pat[3] == 'I' && pat[4] == 'I' && pat[5] == 'I') {
                out->i = call_DIIIII_to_i(fn, dv[0], iv[1], iv[2], iv[3], iv[4], iv[5]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'I' && pat[2] == 'I' && pat[3] == 'I' && pat[4] == 'I' && pat[5] == 'D') {
                out->i = call_DIIIID_to_i(fn, dv[0], iv[1], iv[2], iv[3], iv[4], dv[5]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'I' && pat[2] == 'I' && pat[3] == 'I' && pat[4] == 'D' && pat[5] == 'I') {
                out->i = call_DIIIDI_to_i(fn, dv[0], iv[1], iv[2], iv[3], dv[4], iv[5]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'I' && pat[2] == 'I' && pat[3] == 'I' && pat[4] == 'D' && pat[5] == 'D') {
                out->i = call_DIIIDD_to_i(fn, dv[0], iv[1], iv[2], iv[3], dv[4], dv[5]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'I' && pat[2] == 'I' && pat[3] == 'D' && pat[4] == 'I' && pat[5] == 'I') {
                out->i = call_DIIDII_to_i(fn, dv[0], iv[1], iv[2], dv[3], iv[4], iv[5]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'I' && pat[2] == 'I' && pat[3] == 'D' && pat[4] == 'I' && pat[5] == 'D') {
                out->i = call_DIIDID_to_i(fn, dv[0], iv[1], iv[2], dv[3], iv[4], dv[5]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'I' && pat[2] == 'I' && pat[3] == 'D' && pat[4] == 'D' && pat[5] == 'I') {
                out->i = call_DIIDDI_to_i(fn, dv[0], iv[1], iv[2], dv[3], dv[4], iv[5]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'I' && pat[2] == 'I' && pat[3] == 'D' && pat[4] == 'D' && pat[5] == 'D') {
                out->i = call_DIIDDD_to_i(fn, dv[0], iv[1], iv[2], dv[3], dv[4], dv[5]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'I' && pat[2] == 'D' && pat[3] == 'I' && pat[4] == 'I' && pat[5] == 'I') {
                out->i = call_DIDIII_to_i(fn, dv[0], iv[1], dv[2], iv[3], iv[4], iv[5]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'I' && pat[2] == 'D' && pat[3] == 'I' && pat[4] == 'I' && pat[5] == 'D') {
                out->i = call_DIDIID_to_i(fn, dv[0], iv[1], dv[2], iv[3], iv[4], dv[5]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'I' && pat[2] == 'D' && pat[3] == 'I' && pat[4] == 'D' && pat[5] == 'I') {
                out->i = call_DIDIDI_to_i(fn, dv[0], iv[1], dv[2], iv[3], dv[4], iv[5]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'I' && pat[2] == 'D' && pat[3] == 'I' && pat[4] == 'D' && pat[5] == 'D') {
                out->i = call_DIDIDD_to_i(fn, dv[0], iv[1], dv[2], iv[3], dv[4], dv[5]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'I' && pat[2] == 'D' && pat[3] == 'D' && pat[4] == 'I' && pat[5] == 'I') {
                out->i = call_DIDDII_to_i(fn, dv[0], iv[1], dv[2], dv[3], iv[4], iv[5]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'I' && pat[2] == 'D' && pat[3] == 'D' && pat[4] == 'I' && pat[5] == 'D') {
                out->i = call_DIDDID_to_i(fn, dv[0], iv[1], dv[2], dv[3], iv[4], dv[5]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'I' && pat[2] == 'D' && pat[3] == 'D' && pat[4] == 'D' && pat[5] == 'I') {
                out->i = call_DIDDDI_to_i(fn, dv[0], iv[1], dv[2], dv[3], dv[4], iv[5]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'I' && pat[2] == 'D' && pat[3] == 'D' && pat[4] == 'D' && pat[5] == 'D') {
                out->i = call_DIDDDD_to_i(fn, dv[0], iv[1], dv[2], dv[3], dv[4], dv[5]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'D' && pat[2] == 'I' && pat[3] == 'I' && pat[4] == 'I' && pat[5] == 'I') {
                out->i = call_DDIIII_to_i(fn, dv[0], dv[1], iv[2], iv[3], iv[4], iv[5]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'D' && pat[2] == 'I' && pat[3] == 'I' && pat[4] == 'I' && pat[5] == 'D') {
                out->i = call_DDIIID_to_i(fn, dv[0], dv[1], iv[2], iv[3], iv[4], dv[5]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'D' && pat[2] == 'I' && pat[3] == 'I' && pat[4] == 'D' && pat[5] == 'I') {
                out->i = call_DDIIDI_to_i(fn, dv[0], dv[1], iv[2], iv[3], dv[4], iv[5]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'D' && pat[2] == 'I' && pat[3] == 'I' && pat[4] == 'D' && pat[5] == 'D') {
                out->i = call_DDIIDD_to_i(fn, dv[0], dv[1], iv[2], iv[3], dv[4], dv[5]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'D' && pat[2] == 'I' && pat[3] == 'D' && pat[4] == 'I' && pat[5] == 'I') {
                out->i = call_DDIDII_to_i(fn, dv[0], dv[1], iv[2], dv[3], iv[4], iv[5]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'D' && pat[2] == 'I' && pat[3] == 'D' && pat[4] == 'I' && pat[5] == 'D') {
                out->i = call_DDIDID_to_i(fn, dv[0], dv[1], iv[2], dv[3], iv[4], dv[5]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'D' && pat[2] == 'I' && pat[3] == 'D' && pat[4] == 'D' && pat[5] == 'I') {
                out->i = call_DDIDDI_to_i(fn, dv[0], dv[1], iv[2], dv[3], dv[4], iv[5]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'D' && pat[2] == 'I' && pat[3] == 'D' && pat[4] == 'D' && pat[5] == 'D') {
                out->i = call_DDIDDD_to_i(fn, dv[0], dv[1], iv[2], dv[3], dv[4], dv[5]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'D' && pat[2] == 'D' && pat[3] == 'I' && pat[4] == 'I' && pat[5] == 'I') {
                out->i = call_DDDIII_to_i(fn, dv[0], dv[1], dv[2], iv[3], iv[4], iv[5]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'D' && pat[2] == 'D' && pat[3] == 'I' && pat[4] == 'I' && pat[5] == 'D') {
                out->i = call_DDDIID_to_i(fn, dv[0], dv[1], dv[2], iv[3], iv[4], dv[5]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'D' && pat[2] == 'D' && pat[3] == 'I' && pat[4] == 'D' && pat[5] == 'I') {
                out->i = call_DDDIDI_to_i(fn, dv[0], dv[1], dv[2], iv[3], dv[4], iv[5]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'D' && pat[2] == 'D' && pat[3] == 'I' && pat[4] == 'D' && pat[5] == 'D') {
                out->i = call_DDDIDD_to_i(fn, dv[0], dv[1], dv[2], iv[3], dv[4], dv[5]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'D' && pat[2] == 'D' && pat[3] == 'D' && pat[4] == 'I' && pat[5] == 'I') {
                out->i = call_DDDDII_to_i(fn, dv[0], dv[1], dv[2], dv[3], iv[4], iv[5]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'D' && pat[2] == 'D' && pat[3] == 'D' && pat[4] == 'I' && pat[5] == 'D') {
                out->i = call_DDDDID_to_i(fn, dv[0], dv[1], dv[2], dv[3], iv[4], dv[5]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'D' && pat[2] == 'D' && pat[3] == 'D' && pat[4] == 'D' && pat[5] == 'I') {
                out->i = call_DDDDDI_to_i(fn, dv[0], dv[1], dv[2], dv[3], dv[4], iv[5]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'D' && pat[2] == 'D' && pat[3] == 'D' && pat[4] == 'D' && pat[5] == 'D') {
                out->i = call_DDDDDD_to_i(fn, dv[0], dv[1], dv[2], dv[3], dv[4], dv[5]);
                return 1;
            }
            return 0;
        default: return 0;
        }
    case FFI_RET_F64:
        switch (arg_count) {
        case 0:
            if (1) {
                out->d = call_0_to_d(fn);
                return 1;
            }
            return 0;
        case 1:
            if (pat[0] == 'I') {
                out->d = call_I_to_d(fn, iv[0]);
                return 1;
            }
            else if (pat[0] == 'D') {
                out->d = call_D_to_d(fn, dv[0]);
                return 1;
            }
            return 0;
        case 2:
            if (pat[0] == 'I' && pat[1] == 'I') {
                out->d = call_II_to_d(fn, iv[0], iv[1]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'D') {
                out->d = call_ID_to_d(fn, iv[0], dv[1]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'I') {
                out->d = call_DI_to_d(fn, dv[0], iv[1]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'D') {
                out->d = call_DD_to_d(fn, dv[0], dv[1]);
                return 1;
            }
            return 0;
        case 3:
            if (pat[0] == 'I' && pat[1] == 'I' && pat[2] == 'I') {
                out->d = call_III_to_d(fn, iv[0], iv[1], iv[2]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'I' && pat[2] == 'D') {
                out->d = call_IID_to_d(fn, iv[0], iv[1], dv[2]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'D' && pat[2] == 'I') {
                out->d = call_IDI_to_d(fn, iv[0], dv[1], iv[2]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'D' && pat[2] == 'D') {
                out->d = call_IDD_to_d(fn, iv[0], dv[1], dv[2]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'I' && pat[2] == 'I') {
                out->d = call_DII_to_d(fn, dv[0], iv[1], iv[2]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'I' && pat[2] == 'D') {
                out->d = call_DID_to_d(fn, dv[0], iv[1], dv[2]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'D' && pat[2] == 'I') {
                out->d = call_DDI_to_d(fn, dv[0], dv[1], iv[2]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'D' && pat[2] == 'D') {
                out->d = call_DDD_to_d(fn, dv[0], dv[1], dv[2]);
                return 1;
            }
            return 0;
        case 4:
            if (pat[0] == 'I' && pat[1] == 'I' && pat[2] == 'I' && pat[3] == 'I') {
                out->d = call_IIII_to_d(fn, iv[0], iv[1], iv[2], iv[3]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'I' && pat[2] == 'I' && pat[3] == 'D') {
                out->d = call_IIID_to_d(fn, iv[0], iv[1], iv[2], dv[3]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'I' && pat[2] == 'D' && pat[3] == 'I') {
                out->d = call_IIDI_to_d(fn, iv[0], iv[1], dv[2], iv[3]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'I' && pat[2] == 'D' && pat[3] == 'D') {
                out->d = call_IIDD_to_d(fn, iv[0], iv[1], dv[2], dv[3]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'D' && pat[2] == 'I' && pat[3] == 'I') {
                out->d = call_IDII_to_d(fn, iv[0], dv[1], iv[2], iv[3]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'D' && pat[2] == 'I' && pat[3] == 'D') {
                out->d = call_IDID_to_d(fn, iv[0], dv[1], iv[2], dv[3]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'D' && pat[2] == 'D' && pat[3] == 'I') {
                out->d = call_IDDI_to_d(fn, iv[0], dv[1], dv[2], iv[3]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'D' && pat[2] == 'D' && pat[3] == 'D') {
                out->d = call_IDDD_to_d(fn, iv[0], dv[1], dv[2], dv[3]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'I' && pat[2] == 'I' && pat[3] == 'I') {
                out->d = call_DIII_to_d(fn, dv[0], iv[1], iv[2], iv[3]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'I' && pat[2] == 'I' && pat[3] == 'D') {
                out->d = call_DIID_to_d(fn, dv[0], iv[1], iv[2], dv[3]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'I' && pat[2] == 'D' && pat[3] == 'I') {
                out->d = call_DIDI_to_d(fn, dv[0], iv[1], dv[2], iv[3]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'I' && pat[2] == 'D' && pat[3] == 'D') {
                out->d = call_DIDD_to_d(fn, dv[0], iv[1], dv[2], dv[3]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'D' && pat[2] == 'I' && pat[3] == 'I') {
                out->d = call_DDII_to_d(fn, dv[0], dv[1], iv[2], iv[3]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'D' && pat[2] == 'I' && pat[3] == 'D') {
                out->d = call_DDID_to_d(fn, dv[0], dv[1], iv[2], dv[3]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'D' && pat[2] == 'D' && pat[3] == 'I') {
                out->d = call_DDDI_to_d(fn, dv[0], dv[1], dv[2], iv[3]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'D' && pat[2] == 'D' && pat[3] == 'D') {
                out->d = call_DDDD_to_d(fn, dv[0], dv[1], dv[2], dv[3]);
                return 1;
            }
            return 0;
        case 5:
            if (pat[0] == 'I' && pat[1] == 'I' && pat[2] == 'I' && pat[3] == 'I' && pat[4] == 'I') {
                out->d = call_IIIII_to_d(fn, iv[0], iv[1], iv[2], iv[3], iv[4]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'I' && pat[2] == 'I' && pat[3] == 'I' && pat[4] == 'D') {
                out->d = call_IIIID_to_d(fn, iv[0], iv[1], iv[2], iv[3], dv[4]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'I' && pat[2] == 'I' && pat[3] == 'D' && pat[4] == 'I') {
                out->d = call_IIIDI_to_d(fn, iv[0], iv[1], iv[2], dv[3], iv[4]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'I' && pat[2] == 'I' && pat[3] == 'D' && pat[4] == 'D') {
                out->d = call_IIIDD_to_d(fn, iv[0], iv[1], iv[2], dv[3], dv[4]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'I' && pat[2] == 'D' && pat[3] == 'I' && pat[4] == 'I') {
                out->d = call_IIDII_to_d(fn, iv[0], iv[1], dv[2], iv[3], iv[4]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'I' && pat[2] == 'D' && pat[3] == 'I' && pat[4] == 'D') {
                out->d = call_IIDID_to_d(fn, iv[0], iv[1], dv[2], iv[3], dv[4]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'I' && pat[2] == 'D' && pat[3] == 'D' && pat[4] == 'I') {
                out->d = call_IIDDI_to_d(fn, iv[0], iv[1], dv[2], dv[3], iv[4]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'I' && pat[2] == 'D' && pat[3] == 'D' && pat[4] == 'D') {
                out->d = call_IIDDD_to_d(fn, iv[0], iv[1], dv[2], dv[3], dv[4]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'D' && pat[2] == 'I' && pat[3] == 'I' && pat[4] == 'I') {
                out->d = call_IDIII_to_d(fn, iv[0], dv[1], iv[2], iv[3], iv[4]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'D' && pat[2] == 'I' && pat[3] == 'I' && pat[4] == 'D') {
                out->d = call_IDIID_to_d(fn, iv[0], dv[1], iv[2], iv[3], dv[4]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'D' && pat[2] == 'I' && pat[3] == 'D' && pat[4] == 'I') {
                out->d = call_IDIDI_to_d(fn, iv[0], dv[1], iv[2], dv[3], iv[4]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'D' && pat[2] == 'I' && pat[3] == 'D' && pat[4] == 'D') {
                out->d = call_IDIDD_to_d(fn, iv[0], dv[1], iv[2], dv[3], dv[4]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'D' && pat[2] == 'D' && pat[3] == 'I' && pat[4] == 'I') {
                out->d = call_IDDII_to_d(fn, iv[0], dv[1], dv[2], iv[3], iv[4]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'D' && pat[2] == 'D' && pat[3] == 'I' && pat[4] == 'D') {
                out->d = call_IDDID_to_d(fn, iv[0], dv[1], dv[2], iv[3], dv[4]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'D' && pat[2] == 'D' && pat[3] == 'D' && pat[4] == 'I') {
                out->d = call_IDDDI_to_d(fn, iv[0], dv[1], dv[2], dv[3], iv[4]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'D' && pat[2] == 'D' && pat[3] == 'D' && pat[4] == 'D') {
                out->d = call_IDDDD_to_d(fn, iv[0], dv[1], dv[2], dv[3], dv[4]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'I' && pat[2] == 'I' && pat[3] == 'I' && pat[4] == 'I') {
                out->d = call_DIIII_to_d(fn, dv[0], iv[1], iv[2], iv[3], iv[4]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'I' && pat[2] == 'I' && pat[3] == 'I' && pat[4] == 'D') {
                out->d = call_DIIID_to_d(fn, dv[0], iv[1], iv[2], iv[3], dv[4]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'I' && pat[2] == 'I' && pat[3] == 'D' && pat[4] == 'I') {
                out->d = call_DIIDI_to_d(fn, dv[0], iv[1], iv[2], dv[3], iv[4]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'I' && pat[2] == 'I' && pat[3] == 'D' && pat[4] == 'D') {
                out->d = call_DIIDD_to_d(fn, dv[0], iv[1], iv[2], dv[3], dv[4]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'I' && pat[2] == 'D' && pat[3] == 'I' && pat[4] == 'I') {
                out->d = call_DIDII_to_d(fn, dv[0], iv[1], dv[2], iv[3], iv[4]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'I' && pat[2] == 'D' && pat[3] == 'I' && pat[4] == 'D') {
                out->d = call_DIDID_to_d(fn, dv[0], iv[1], dv[2], iv[3], dv[4]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'I' && pat[2] == 'D' && pat[3] == 'D' && pat[4] == 'I') {
                out->d = call_DIDDI_to_d(fn, dv[0], iv[1], dv[2], dv[3], iv[4]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'I' && pat[2] == 'D' && pat[3] == 'D' && pat[4] == 'D') {
                out->d = call_DIDDD_to_d(fn, dv[0], iv[1], dv[2], dv[3], dv[4]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'D' && pat[2] == 'I' && pat[3] == 'I' && pat[4] == 'I') {
                out->d = call_DDIII_to_d(fn, dv[0], dv[1], iv[2], iv[3], iv[4]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'D' && pat[2] == 'I' && pat[3] == 'I' && pat[4] == 'D') {
                out->d = call_DDIID_to_d(fn, dv[0], dv[1], iv[2], iv[3], dv[4]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'D' && pat[2] == 'I' && pat[3] == 'D' && pat[4] == 'I') {
                out->d = call_DDIDI_to_d(fn, dv[0], dv[1], iv[2], dv[3], iv[4]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'D' && pat[2] == 'I' && pat[3] == 'D' && pat[4] == 'D') {
                out->d = call_DDIDD_to_d(fn, dv[0], dv[1], iv[2], dv[3], dv[4]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'D' && pat[2] == 'D' && pat[3] == 'I' && pat[4] == 'I') {
                out->d = call_DDDII_to_d(fn, dv[0], dv[1], dv[2], iv[3], iv[4]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'D' && pat[2] == 'D' && pat[3] == 'I' && pat[4] == 'D') {
                out->d = call_DDDID_to_d(fn, dv[0], dv[1], dv[2], iv[3], dv[4]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'D' && pat[2] == 'D' && pat[3] == 'D' && pat[4] == 'I') {
                out->d = call_DDDDI_to_d(fn, dv[0], dv[1], dv[2], dv[3], iv[4]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'D' && pat[2] == 'D' && pat[3] == 'D' && pat[4] == 'D') {
                out->d = call_DDDDD_to_d(fn, dv[0], dv[1], dv[2], dv[3], dv[4]);
                return 1;
            }
            return 0;
        case 6:
            if (pat[0] == 'I' && pat[1] == 'I' && pat[2] == 'I' && pat[3] == 'I' && pat[4] == 'I' && pat[5] == 'I') {
                out->d = call_IIIIII_to_d(fn, iv[0], iv[1], iv[2], iv[3], iv[4], iv[5]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'I' && pat[2] == 'I' && pat[3] == 'I' && pat[4] == 'I' && pat[5] == 'D') {
                out->d = call_IIIIID_to_d(fn, iv[0], iv[1], iv[2], iv[3], iv[4], dv[5]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'I' && pat[2] == 'I' && pat[3] == 'I' && pat[4] == 'D' && pat[5] == 'I') {
                out->d = call_IIIIDI_to_d(fn, iv[0], iv[1], iv[2], iv[3], dv[4], iv[5]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'I' && pat[2] == 'I' && pat[3] == 'I' && pat[4] == 'D' && pat[5] == 'D') {
                out->d = call_IIIIDD_to_d(fn, iv[0], iv[1], iv[2], iv[3], dv[4], dv[5]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'I' && pat[2] == 'I' && pat[3] == 'D' && pat[4] == 'I' && pat[5] == 'I') {
                out->d = call_IIIDII_to_d(fn, iv[0], iv[1], iv[2], dv[3], iv[4], iv[5]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'I' && pat[2] == 'I' && pat[3] == 'D' && pat[4] == 'I' && pat[5] == 'D') {
                out->d = call_IIIDID_to_d(fn, iv[0], iv[1], iv[2], dv[3], iv[4], dv[5]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'I' && pat[2] == 'I' && pat[3] == 'D' && pat[4] == 'D' && pat[5] == 'I') {
                out->d = call_IIIDDI_to_d(fn, iv[0], iv[1], iv[2], dv[3], dv[4], iv[5]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'I' && pat[2] == 'I' && pat[3] == 'D' && pat[4] == 'D' && pat[5] == 'D') {
                out->d = call_IIIDDD_to_d(fn, iv[0], iv[1], iv[2], dv[3], dv[4], dv[5]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'I' && pat[2] == 'D' && pat[3] == 'I' && pat[4] == 'I' && pat[5] == 'I') {
                out->d = call_IIDIII_to_d(fn, iv[0], iv[1], dv[2], iv[3], iv[4], iv[5]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'I' && pat[2] == 'D' && pat[3] == 'I' && pat[4] == 'I' && pat[5] == 'D') {
                out->d = call_IIDIID_to_d(fn, iv[0], iv[1], dv[2], iv[3], iv[4], dv[5]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'I' && pat[2] == 'D' && pat[3] == 'I' && pat[4] == 'D' && pat[5] == 'I') {
                out->d = call_IIDIDI_to_d(fn, iv[0], iv[1], dv[2], iv[3], dv[4], iv[5]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'I' && pat[2] == 'D' && pat[3] == 'I' && pat[4] == 'D' && pat[5] == 'D') {
                out->d = call_IIDIDD_to_d(fn, iv[0], iv[1], dv[2], iv[3], dv[4], dv[5]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'I' && pat[2] == 'D' && pat[3] == 'D' && pat[4] == 'I' && pat[5] == 'I') {
                out->d = call_IIDDII_to_d(fn, iv[0], iv[1], dv[2], dv[3], iv[4], iv[5]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'I' && pat[2] == 'D' && pat[3] == 'D' && pat[4] == 'I' && pat[5] == 'D') {
                out->d = call_IIDDID_to_d(fn, iv[0], iv[1], dv[2], dv[3], iv[4], dv[5]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'I' && pat[2] == 'D' && pat[3] == 'D' && pat[4] == 'D' && pat[5] == 'I') {
                out->d = call_IIDDDI_to_d(fn, iv[0], iv[1], dv[2], dv[3], dv[4], iv[5]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'I' && pat[2] == 'D' && pat[3] == 'D' && pat[4] == 'D' && pat[5] == 'D') {
                out->d = call_IIDDDD_to_d(fn, iv[0], iv[1], dv[2], dv[3], dv[4], dv[5]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'D' && pat[2] == 'I' && pat[3] == 'I' && pat[4] == 'I' && pat[5] == 'I') {
                out->d = call_IDIIII_to_d(fn, iv[0], dv[1], iv[2], iv[3], iv[4], iv[5]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'D' && pat[2] == 'I' && pat[3] == 'I' && pat[4] == 'I' && pat[5] == 'D') {
                out->d = call_IDIIID_to_d(fn, iv[0], dv[1], iv[2], iv[3], iv[4], dv[5]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'D' && pat[2] == 'I' && pat[3] == 'I' && pat[4] == 'D' && pat[5] == 'I') {
                out->d = call_IDIIDI_to_d(fn, iv[0], dv[1], iv[2], iv[3], dv[4], iv[5]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'D' && pat[2] == 'I' && pat[3] == 'I' && pat[4] == 'D' && pat[5] == 'D') {
                out->d = call_IDIIDD_to_d(fn, iv[0], dv[1], iv[2], iv[3], dv[4], dv[5]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'D' && pat[2] == 'I' && pat[3] == 'D' && pat[4] == 'I' && pat[5] == 'I') {
                out->d = call_IDIDII_to_d(fn, iv[0], dv[1], iv[2], dv[3], iv[4], iv[5]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'D' && pat[2] == 'I' && pat[3] == 'D' && pat[4] == 'I' && pat[5] == 'D') {
                out->d = call_IDIDID_to_d(fn, iv[0], dv[1], iv[2], dv[3], iv[4], dv[5]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'D' && pat[2] == 'I' && pat[3] == 'D' && pat[4] == 'D' && pat[5] == 'I') {
                out->d = call_IDIDDI_to_d(fn, iv[0], dv[1], iv[2], dv[3], dv[4], iv[5]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'D' && pat[2] == 'I' && pat[3] == 'D' && pat[4] == 'D' && pat[5] == 'D') {
                out->d = call_IDIDDD_to_d(fn, iv[0], dv[1], iv[2], dv[3], dv[4], dv[5]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'D' && pat[2] == 'D' && pat[3] == 'I' && pat[4] == 'I' && pat[5] == 'I') {
                out->d = call_IDDIII_to_d(fn, iv[0], dv[1], dv[2], iv[3], iv[4], iv[5]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'D' && pat[2] == 'D' && pat[3] == 'I' && pat[4] == 'I' && pat[5] == 'D') {
                out->d = call_IDDIID_to_d(fn, iv[0], dv[1], dv[2], iv[3], iv[4], dv[5]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'D' && pat[2] == 'D' && pat[3] == 'I' && pat[4] == 'D' && pat[5] == 'I') {
                out->d = call_IDDIDI_to_d(fn, iv[0], dv[1], dv[2], iv[3], dv[4], iv[5]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'D' && pat[2] == 'D' && pat[3] == 'I' && pat[4] == 'D' && pat[5] == 'D') {
                out->d = call_IDDIDD_to_d(fn, iv[0], dv[1], dv[2], iv[3], dv[4], dv[5]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'D' && pat[2] == 'D' && pat[3] == 'D' && pat[4] == 'I' && pat[5] == 'I') {
                out->d = call_IDDDII_to_d(fn, iv[0], dv[1], dv[2], dv[3], iv[4], iv[5]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'D' && pat[2] == 'D' && pat[3] == 'D' && pat[4] == 'I' && pat[5] == 'D') {
                out->d = call_IDDDID_to_d(fn, iv[0], dv[1], dv[2], dv[3], iv[4], dv[5]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'D' && pat[2] == 'D' && pat[3] == 'D' && pat[4] == 'D' && pat[5] == 'I') {
                out->d = call_IDDDDI_to_d(fn, iv[0], dv[1], dv[2], dv[3], dv[4], iv[5]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'D' && pat[2] == 'D' && pat[3] == 'D' && pat[4] == 'D' && pat[5] == 'D') {
                out->d = call_IDDDDD_to_d(fn, iv[0], dv[1], dv[2], dv[3], dv[4], dv[5]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'I' && pat[2] == 'I' && pat[3] == 'I' && pat[4] == 'I' && pat[5] == 'I') {
                out->d = call_DIIIII_to_d(fn, dv[0], iv[1], iv[2], iv[3], iv[4], iv[5]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'I' && pat[2] == 'I' && pat[3] == 'I' && pat[4] == 'I' && pat[5] == 'D') {
                out->d = call_DIIIID_to_d(fn, dv[0], iv[1], iv[2], iv[3], iv[4], dv[5]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'I' && pat[2] == 'I' && pat[3] == 'I' && pat[4] == 'D' && pat[5] == 'I') {
                out->d = call_DIIIDI_to_d(fn, dv[0], iv[1], iv[2], iv[3], dv[4], iv[5]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'I' && pat[2] == 'I' && pat[3] == 'I' && pat[4] == 'D' && pat[5] == 'D') {
                out->d = call_DIIIDD_to_d(fn, dv[0], iv[1], iv[2], iv[3], dv[4], dv[5]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'I' && pat[2] == 'I' && pat[3] == 'D' && pat[4] == 'I' && pat[5] == 'I') {
                out->d = call_DIIDII_to_d(fn, dv[0], iv[1], iv[2], dv[3], iv[4], iv[5]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'I' && pat[2] == 'I' && pat[3] == 'D' && pat[4] == 'I' && pat[5] == 'D') {
                out->d = call_DIIDID_to_d(fn, dv[0], iv[1], iv[2], dv[3], iv[4], dv[5]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'I' && pat[2] == 'I' && pat[3] == 'D' && pat[4] == 'D' && pat[5] == 'I') {
                out->d = call_DIIDDI_to_d(fn, dv[0], iv[1], iv[2], dv[3], dv[4], iv[5]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'I' && pat[2] == 'I' && pat[3] == 'D' && pat[4] == 'D' && pat[5] == 'D') {
                out->d = call_DIIDDD_to_d(fn, dv[0], iv[1], iv[2], dv[3], dv[4], dv[5]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'I' && pat[2] == 'D' && pat[3] == 'I' && pat[4] == 'I' && pat[5] == 'I') {
                out->d = call_DIDIII_to_d(fn, dv[0], iv[1], dv[2], iv[3], iv[4], iv[5]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'I' && pat[2] == 'D' && pat[3] == 'I' && pat[4] == 'I' && pat[5] == 'D') {
                out->d = call_DIDIID_to_d(fn, dv[0], iv[1], dv[2], iv[3], iv[4], dv[5]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'I' && pat[2] == 'D' && pat[3] == 'I' && pat[4] == 'D' && pat[5] == 'I') {
                out->d = call_DIDIDI_to_d(fn, dv[0], iv[1], dv[2], iv[3], dv[4], iv[5]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'I' && pat[2] == 'D' && pat[3] == 'I' && pat[4] == 'D' && pat[5] == 'D') {
                out->d = call_DIDIDD_to_d(fn, dv[0], iv[1], dv[2], iv[3], dv[4], dv[5]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'I' && pat[2] == 'D' && pat[3] == 'D' && pat[4] == 'I' && pat[5] == 'I') {
                out->d = call_DIDDII_to_d(fn, dv[0], iv[1], dv[2], dv[3], iv[4], iv[5]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'I' && pat[2] == 'D' && pat[3] == 'D' && pat[4] == 'I' && pat[5] == 'D') {
                out->d = call_DIDDID_to_d(fn, dv[0], iv[1], dv[2], dv[3], iv[4], dv[5]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'I' && pat[2] == 'D' && pat[3] == 'D' && pat[4] == 'D' && pat[5] == 'I') {
                out->d = call_DIDDDI_to_d(fn, dv[0], iv[1], dv[2], dv[3], dv[4], iv[5]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'I' && pat[2] == 'D' && pat[3] == 'D' && pat[4] == 'D' && pat[5] == 'D') {
                out->d = call_DIDDDD_to_d(fn, dv[0], iv[1], dv[2], dv[3], dv[4], dv[5]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'D' && pat[2] == 'I' && pat[3] == 'I' && pat[4] == 'I' && pat[5] == 'I') {
                out->d = call_DDIIII_to_d(fn, dv[0], dv[1], iv[2], iv[3], iv[4], iv[5]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'D' && pat[2] == 'I' && pat[3] == 'I' && pat[4] == 'I' && pat[5] == 'D') {
                out->d = call_DDIIID_to_d(fn, dv[0], dv[1], iv[2], iv[3], iv[4], dv[5]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'D' && pat[2] == 'I' && pat[3] == 'I' && pat[4] == 'D' && pat[5] == 'I') {
                out->d = call_DDIIDI_to_d(fn, dv[0], dv[1], iv[2], iv[3], dv[4], iv[5]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'D' && pat[2] == 'I' && pat[3] == 'I' && pat[4] == 'D' && pat[5] == 'D') {
                out->d = call_DDIIDD_to_d(fn, dv[0], dv[1], iv[2], iv[3], dv[4], dv[5]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'D' && pat[2] == 'I' && pat[3] == 'D' && pat[4] == 'I' && pat[5] == 'I') {
                out->d = call_DDIDII_to_d(fn, dv[0], dv[1], iv[2], dv[3], iv[4], iv[5]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'D' && pat[2] == 'I' && pat[3] == 'D' && pat[4] == 'I' && pat[5] == 'D') {
                out->d = call_DDIDID_to_d(fn, dv[0], dv[1], iv[2], dv[3], iv[4], dv[5]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'D' && pat[2] == 'I' && pat[3] == 'D' && pat[4] == 'D' && pat[5] == 'I') {
                out->d = call_DDIDDI_to_d(fn, dv[0], dv[1], iv[2], dv[3], dv[4], iv[5]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'D' && pat[2] == 'I' && pat[3] == 'D' && pat[4] == 'D' && pat[5] == 'D') {
                out->d = call_DDIDDD_to_d(fn, dv[0], dv[1], iv[2], dv[3], dv[4], dv[5]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'D' && pat[2] == 'D' && pat[3] == 'I' && pat[4] == 'I' && pat[5] == 'I') {
                out->d = call_DDDIII_to_d(fn, dv[0], dv[1], dv[2], iv[3], iv[4], iv[5]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'D' && pat[2] == 'D' && pat[3] == 'I' && pat[4] == 'I' && pat[5] == 'D') {
                out->d = call_DDDIID_to_d(fn, dv[0], dv[1], dv[2], iv[3], iv[4], dv[5]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'D' && pat[2] == 'D' && pat[3] == 'I' && pat[4] == 'D' && pat[5] == 'I') {
                out->d = call_DDDIDI_to_d(fn, dv[0], dv[1], dv[2], iv[3], dv[4], iv[5]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'D' && pat[2] == 'D' && pat[3] == 'I' && pat[4] == 'D' && pat[5] == 'D') {
                out->d = call_DDDIDD_to_d(fn, dv[0], dv[1], dv[2], iv[3], dv[4], dv[5]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'D' && pat[2] == 'D' && pat[3] == 'D' && pat[4] == 'I' && pat[5] == 'I') {
                out->d = call_DDDDII_to_d(fn, dv[0], dv[1], dv[2], dv[3], iv[4], iv[5]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'D' && pat[2] == 'D' && pat[3] == 'D' && pat[4] == 'I' && pat[5] == 'D') {
                out->d = call_DDDDID_to_d(fn, dv[0], dv[1], dv[2], dv[3], iv[4], dv[5]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'D' && pat[2] == 'D' && pat[3] == 'D' && pat[4] == 'D' && pat[5] == 'I') {
                out->d = call_DDDDDI_to_d(fn, dv[0], dv[1], dv[2], dv[3], dv[4], iv[5]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'D' && pat[2] == 'D' && pat[3] == 'D' && pat[4] == 'D' && pat[5] == 'D') {
                out->d = call_DDDDDD_to_d(fn, dv[0], dv[1], dv[2], dv[3], dv[4], dv[5]);
                return 1;
            }
            return 0;
        default: return 0;
        }
    case FFI_RET_PTR:
        switch (arg_count) {
        case 0:
            if (1) {
                out->p = (void *)(size_t)call_0_to_p(fn);
                return 1;
            }
            return 0;
        case 1:
            if (pat[0] == 'I') {
                out->p = (void *)(size_t)call_I_to_p(fn, iv[0]);
                return 1;
            }
            else if (pat[0] == 'D') {
                out->p = (void *)(size_t)call_D_to_p(fn, dv[0]);
                return 1;
            }
            return 0;
        case 2:
            if (pat[0] == 'I' && pat[1] == 'I') {
                out->p = (void *)(size_t)call_II_to_p(fn, iv[0], iv[1]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'D') {
                out->p = (void *)(size_t)call_ID_to_p(fn, iv[0], dv[1]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'I') {
                out->p = (void *)(size_t)call_DI_to_p(fn, dv[0], iv[1]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'D') {
                out->p = (void *)(size_t)call_DD_to_p(fn, dv[0], dv[1]);
                return 1;
            }
            return 0;
        case 3:
            if (pat[0] == 'I' && pat[1] == 'I' && pat[2] == 'I') {
                out->p = (void *)(size_t)call_III_to_p(fn, iv[0], iv[1], iv[2]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'I' && pat[2] == 'D') {
                out->p = (void *)(size_t)call_IID_to_p(fn, iv[0], iv[1], dv[2]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'D' && pat[2] == 'I') {
                out->p = (void *)(size_t)call_IDI_to_p(fn, iv[0], dv[1], iv[2]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'D' && pat[2] == 'D') {
                out->p = (void *)(size_t)call_IDD_to_p(fn, iv[0], dv[1], dv[2]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'I' && pat[2] == 'I') {
                out->p = (void *)(size_t)call_DII_to_p(fn, dv[0], iv[1], iv[2]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'I' && pat[2] == 'D') {
                out->p = (void *)(size_t)call_DID_to_p(fn, dv[0], iv[1], dv[2]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'D' && pat[2] == 'I') {
                out->p = (void *)(size_t)call_DDI_to_p(fn, dv[0], dv[1], iv[2]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'D' && pat[2] == 'D') {
                out->p = (void *)(size_t)call_DDD_to_p(fn, dv[0], dv[1], dv[2]);
                return 1;
            }
            return 0;
        case 4:
            if (pat[0] == 'I' && pat[1] == 'I' && pat[2] == 'I' && pat[3] == 'I') {
                out->p = (void *)(size_t)call_IIII_to_p(fn, iv[0], iv[1], iv[2], iv[3]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'I' && pat[2] == 'I' && pat[3] == 'D') {
                out->p = (void *)(size_t)call_IIID_to_p(fn, iv[0], iv[1], iv[2], dv[3]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'I' && pat[2] == 'D' && pat[3] == 'I') {
                out->p = (void *)(size_t)call_IIDI_to_p(fn, iv[0], iv[1], dv[2], iv[3]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'I' && pat[2] == 'D' && pat[3] == 'D') {
                out->p = (void *)(size_t)call_IIDD_to_p(fn, iv[0], iv[1], dv[2], dv[3]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'D' && pat[2] == 'I' && pat[3] == 'I') {
                out->p = (void *)(size_t)call_IDII_to_p(fn, iv[0], dv[1], iv[2], iv[3]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'D' && pat[2] == 'I' && pat[3] == 'D') {
                out->p = (void *)(size_t)call_IDID_to_p(fn, iv[0], dv[1], iv[2], dv[3]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'D' && pat[2] == 'D' && pat[3] == 'I') {
                out->p = (void *)(size_t)call_IDDI_to_p(fn, iv[0], dv[1], dv[2], iv[3]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'D' && pat[2] == 'D' && pat[3] == 'D') {
                out->p = (void *)(size_t)call_IDDD_to_p(fn, iv[0], dv[1], dv[2], dv[3]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'I' && pat[2] == 'I' && pat[3] == 'I') {
                out->p = (void *)(size_t)call_DIII_to_p(fn, dv[0], iv[1], iv[2], iv[3]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'I' && pat[2] == 'I' && pat[3] == 'D') {
                out->p = (void *)(size_t)call_DIID_to_p(fn, dv[0], iv[1], iv[2], dv[3]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'I' && pat[2] == 'D' && pat[3] == 'I') {
                out->p = (void *)(size_t)call_DIDI_to_p(fn, dv[0], iv[1], dv[2], iv[3]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'I' && pat[2] == 'D' && pat[3] == 'D') {
                out->p = (void *)(size_t)call_DIDD_to_p(fn, dv[0], iv[1], dv[2], dv[3]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'D' && pat[2] == 'I' && pat[3] == 'I') {
                out->p = (void *)(size_t)call_DDII_to_p(fn, dv[0], dv[1], iv[2], iv[3]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'D' && pat[2] == 'I' && pat[3] == 'D') {
                out->p = (void *)(size_t)call_DDID_to_p(fn, dv[0], dv[1], iv[2], dv[3]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'D' && pat[2] == 'D' && pat[3] == 'I') {
                out->p = (void *)(size_t)call_DDDI_to_p(fn, dv[0], dv[1], dv[2], iv[3]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'D' && pat[2] == 'D' && pat[3] == 'D') {
                out->p = (void *)(size_t)call_DDDD_to_p(fn, dv[0], dv[1], dv[2], dv[3]);
                return 1;
            }
            return 0;
        case 5:
            if (pat[0] == 'I' && pat[1] == 'I' && pat[2] == 'I' && pat[3] == 'I' && pat[4] == 'I') {
                out->p = (void *)(size_t)call_IIIII_to_p(fn, iv[0], iv[1], iv[2], iv[3], iv[4]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'I' && pat[2] == 'I' && pat[3] == 'I' && pat[4] == 'D') {
                out->p = (void *)(size_t)call_IIIID_to_p(fn, iv[0], iv[1], iv[2], iv[3], dv[4]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'I' && pat[2] == 'I' && pat[3] == 'D' && pat[4] == 'I') {
                out->p = (void *)(size_t)call_IIIDI_to_p(fn, iv[0], iv[1], iv[2], dv[3], iv[4]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'I' && pat[2] == 'I' && pat[3] == 'D' && pat[4] == 'D') {
                out->p = (void *)(size_t)call_IIIDD_to_p(fn, iv[0], iv[1], iv[2], dv[3], dv[4]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'I' && pat[2] == 'D' && pat[3] == 'I' && pat[4] == 'I') {
                out->p = (void *)(size_t)call_IIDII_to_p(fn, iv[0], iv[1], dv[2], iv[3], iv[4]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'I' && pat[2] == 'D' && pat[3] == 'I' && pat[4] == 'D') {
                out->p = (void *)(size_t)call_IIDID_to_p(fn, iv[0], iv[1], dv[2], iv[3], dv[4]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'I' && pat[2] == 'D' && pat[3] == 'D' && pat[4] == 'I') {
                out->p = (void *)(size_t)call_IIDDI_to_p(fn, iv[0], iv[1], dv[2], dv[3], iv[4]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'I' && pat[2] == 'D' && pat[3] == 'D' && pat[4] == 'D') {
                out->p = (void *)(size_t)call_IIDDD_to_p(fn, iv[0], iv[1], dv[2], dv[3], dv[4]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'D' && pat[2] == 'I' && pat[3] == 'I' && pat[4] == 'I') {
                out->p = (void *)(size_t)call_IDIII_to_p(fn, iv[0], dv[1], iv[2], iv[3], iv[4]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'D' && pat[2] == 'I' && pat[3] == 'I' && pat[4] == 'D') {
                out->p = (void *)(size_t)call_IDIID_to_p(fn, iv[0], dv[1], iv[2], iv[3], dv[4]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'D' && pat[2] == 'I' && pat[3] == 'D' && pat[4] == 'I') {
                out->p = (void *)(size_t)call_IDIDI_to_p(fn, iv[0], dv[1], iv[2], dv[3], iv[4]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'D' && pat[2] == 'I' && pat[3] == 'D' && pat[4] == 'D') {
                out->p = (void *)(size_t)call_IDIDD_to_p(fn, iv[0], dv[1], iv[2], dv[3], dv[4]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'D' && pat[2] == 'D' && pat[3] == 'I' && pat[4] == 'I') {
                out->p = (void *)(size_t)call_IDDII_to_p(fn, iv[0], dv[1], dv[2], iv[3], iv[4]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'D' && pat[2] == 'D' && pat[3] == 'I' && pat[4] == 'D') {
                out->p = (void *)(size_t)call_IDDID_to_p(fn, iv[0], dv[1], dv[2], iv[3], dv[4]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'D' && pat[2] == 'D' && pat[3] == 'D' && pat[4] == 'I') {
                out->p = (void *)(size_t)call_IDDDI_to_p(fn, iv[0], dv[1], dv[2], dv[3], iv[4]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'D' && pat[2] == 'D' && pat[3] == 'D' && pat[4] == 'D') {
                out->p = (void *)(size_t)call_IDDDD_to_p(fn, iv[0], dv[1], dv[2], dv[3], dv[4]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'I' && pat[2] == 'I' && pat[3] == 'I' && pat[4] == 'I') {
                out->p = (void *)(size_t)call_DIIII_to_p(fn, dv[0], iv[1], iv[2], iv[3], iv[4]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'I' && pat[2] == 'I' && pat[3] == 'I' && pat[4] == 'D') {
                out->p = (void *)(size_t)call_DIIID_to_p(fn, dv[0], iv[1], iv[2], iv[3], dv[4]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'I' && pat[2] == 'I' && pat[3] == 'D' && pat[4] == 'I') {
                out->p = (void *)(size_t)call_DIIDI_to_p(fn, dv[0], iv[1], iv[2], dv[3], iv[4]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'I' && pat[2] == 'I' && pat[3] == 'D' && pat[4] == 'D') {
                out->p = (void *)(size_t)call_DIIDD_to_p(fn, dv[0], iv[1], iv[2], dv[3], dv[4]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'I' && pat[2] == 'D' && pat[3] == 'I' && pat[4] == 'I') {
                out->p = (void *)(size_t)call_DIDII_to_p(fn, dv[0], iv[1], dv[2], iv[3], iv[4]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'I' && pat[2] == 'D' && pat[3] == 'I' && pat[4] == 'D') {
                out->p = (void *)(size_t)call_DIDID_to_p(fn, dv[0], iv[1], dv[2], iv[3], dv[4]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'I' && pat[2] == 'D' && pat[3] == 'D' && pat[4] == 'I') {
                out->p = (void *)(size_t)call_DIDDI_to_p(fn, dv[0], iv[1], dv[2], dv[3], iv[4]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'I' && pat[2] == 'D' && pat[3] == 'D' && pat[4] == 'D') {
                out->p = (void *)(size_t)call_DIDDD_to_p(fn, dv[0], iv[1], dv[2], dv[3], dv[4]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'D' && pat[2] == 'I' && pat[3] == 'I' && pat[4] == 'I') {
                out->p = (void *)(size_t)call_DDIII_to_p(fn, dv[0], dv[1], iv[2], iv[3], iv[4]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'D' && pat[2] == 'I' && pat[3] == 'I' && pat[4] == 'D') {
                out->p = (void *)(size_t)call_DDIID_to_p(fn, dv[0], dv[1], iv[2], iv[3], dv[4]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'D' && pat[2] == 'I' && pat[3] == 'D' && pat[4] == 'I') {
                out->p = (void *)(size_t)call_DDIDI_to_p(fn, dv[0], dv[1], iv[2], dv[3], iv[4]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'D' && pat[2] == 'I' && pat[3] == 'D' && pat[4] == 'D') {
                out->p = (void *)(size_t)call_DDIDD_to_p(fn, dv[0], dv[1], iv[2], dv[3], dv[4]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'D' && pat[2] == 'D' && pat[3] == 'I' && pat[4] == 'I') {
                out->p = (void *)(size_t)call_DDDII_to_p(fn, dv[0], dv[1], dv[2], iv[3], iv[4]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'D' && pat[2] == 'D' && pat[3] == 'I' && pat[4] == 'D') {
                out->p = (void *)(size_t)call_DDDID_to_p(fn, dv[0], dv[1], dv[2], iv[3], dv[4]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'D' && pat[2] == 'D' && pat[3] == 'D' && pat[4] == 'I') {
                out->p = (void *)(size_t)call_DDDDI_to_p(fn, dv[0], dv[1], dv[2], dv[3], iv[4]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'D' && pat[2] == 'D' && pat[3] == 'D' && pat[4] == 'D') {
                out->p = (void *)(size_t)call_DDDDD_to_p(fn, dv[0], dv[1], dv[2], dv[3], dv[4]);
                return 1;
            }
            return 0;
        case 6:
            if (pat[0] == 'I' && pat[1] == 'I' && pat[2] == 'I' && pat[3] == 'I' && pat[4] == 'I' && pat[5] == 'I') {
                out->p = (void *)(size_t)call_IIIIII_to_p(fn, iv[0], iv[1], iv[2], iv[3], iv[4], iv[5]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'I' && pat[2] == 'I' && pat[3] == 'I' && pat[4] == 'I' && pat[5] == 'D') {
                out->p = (void *)(size_t)call_IIIIID_to_p(fn, iv[0], iv[1], iv[2], iv[3], iv[4], dv[5]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'I' && pat[2] == 'I' && pat[3] == 'I' && pat[4] == 'D' && pat[5] == 'I') {
                out->p = (void *)(size_t)call_IIIIDI_to_p(fn, iv[0], iv[1], iv[2], iv[3], dv[4], iv[5]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'I' && pat[2] == 'I' && pat[3] == 'I' && pat[4] == 'D' && pat[5] == 'D') {
                out->p = (void *)(size_t)call_IIIIDD_to_p(fn, iv[0], iv[1], iv[2], iv[3], dv[4], dv[5]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'I' && pat[2] == 'I' && pat[3] == 'D' && pat[4] == 'I' && pat[5] == 'I') {
                out->p = (void *)(size_t)call_IIIDII_to_p(fn, iv[0], iv[1], iv[2], dv[3], iv[4], iv[5]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'I' && pat[2] == 'I' && pat[3] == 'D' && pat[4] == 'I' && pat[5] == 'D') {
                out->p = (void *)(size_t)call_IIIDID_to_p(fn, iv[0], iv[1], iv[2], dv[3], iv[4], dv[5]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'I' && pat[2] == 'I' && pat[3] == 'D' && pat[4] == 'D' && pat[5] == 'I') {
                out->p = (void *)(size_t)call_IIIDDI_to_p(fn, iv[0], iv[1], iv[2], dv[3], dv[4], iv[5]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'I' && pat[2] == 'I' && pat[3] == 'D' && pat[4] == 'D' && pat[5] == 'D') {
                out->p = (void *)(size_t)call_IIIDDD_to_p(fn, iv[0], iv[1], iv[2], dv[3], dv[4], dv[5]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'I' && pat[2] == 'D' && pat[3] == 'I' && pat[4] == 'I' && pat[5] == 'I') {
                out->p = (void *)(size_t)call_IIDIII_to_p(fn, iv[0], iv[1], dv[2], iv[3], iv[4], iv[5]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'I' && pat[2] == 'D' && pat[3] == 'I' && pat[4] == 'I' && pat[5] == 'D') {
                out->p = (void *)(size_t)call_IIDIID_to_p(fn, iv[0], iv[1], dv[2], iv[3], iv[4], dv[5]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'I' && pat[2] == 'D' && pat[3] == 'I' && pat[4] == 'D' && pat[5] == 'I') {
                out->p = (void *)(size_t)call_IIDIDI_to_p(fn, iv[0], iv[1], dv[2], iv[3], dv[4], iv[5]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'I' && pat[2] == 'D' && pat[3] == 'I' && pat[4] == 'D' && pat[5] == 'D') {
                out->p = (void *)(size_t)call_IIDIDD_to_p(fn, iv[0], iv[1], dv[2], iv[3], dv[4], dv[5]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'I' && pat[2] == 'D' && pat[3] == 'D' && pat[4] == 'I' && pat[5] == 'I') {
                out->p = (void *)(size_t)call_IIDDII_to_p(fn, iv[0], iv[1], dv[2], dv[3], iv[4], iv[5]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'I' && pat[2] == 'D' && pat[3] == 'D' && pat[4] == 'I' && pat[5] == 'D') {
                out->p = (void *)(size_t)call_IIDDID_to_p(fn, iv[0], iv[1], dv[2], dv[3], iv[4], dv[5]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'I' && pat[2] == 'D' && pat[3] == 'D' && pat[4] == 'D' && pat[5] == 'I') {
                out->p = (void *)(size_t)call_IIDDDI_to_p(fn, iv[0], iv[1], dv[2], dv[3], dv[4], iv[5]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'I' && pat[2] == 'D' && pat[3] == 'D' && pat[4] == 'D' && pat[5] == 'D') {
                out->p = (void *)(size_t)call_IIDDDD_to_p(fn, iv[0], iv[1], dv[2], dv[3], dv[4], dv[5]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'D' && pat[2] == 'I' && pat[3] == 'I' && pat[4] == 'I' && pat[5] == 'I') {
                out->p = (void *)(size_t)call_IDIIII_to_p(fn, iv[0], dv[1], iv[2], iv[3], iv[4], iv[5]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'D' && pat[2] == 'I' && pat[3] == 'I' && pat[4] == 'I' && pat[5] == 'D') {
                out->p = (void *)(size_t)call_IDIIID_to_p(fn, iv[0], dv[1], iv[2], iv[3], iv[4], dv[5]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'D' && pat[2] == 'I' && pat[3] == 'I' && pat[4] == 'D' && pat[5] == 'I') {
                out->p = (void *)(size_t)call_IDIIDI_to_p(fn, iv[0], dv[1], iv[2], iv[3], dv[4], iv[5]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'D' && pat[2] == 'I' && pat[3] == 'I' && pat[4] == 'D' && pat[5] == 'D') {
                out->p = (void *)(size_t)call_IDIIDD_to_p(fn, iv[0], dv[1], iv[2], iv[3], dv[4], dv[5]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'D' && pat[2] == 'I' && pat[3] == 'D' && pat[4] == 'I' && pat[5] == 'I') {
                out->p = (void *)(size_t)call_IDIDII_to_p(fn, iv[0], dv[1], iv[2], dv[3], iv[4], iv[5]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'D' && pat[2] == 'I' && pat[3] == 'D' && pat[4] == 'I' && pat[5] == 'D') {
                out->p = (void *)(size_t)call_IDIDID_to_p(fn, iv[0], dv[1], iv[2], dv[3], iv[4], dv[5]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'D' && pat[2] == 'I' && pat[3] == 'D' && pat[4] == 'D' && pat[5] == 'I') {
                out->p = (void *)(size_t)call_IDIDDI_to_p(fn, iv[0], dv[1], iv[2], dv[3], dv[4], iv[5]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'D' && pat[2] == 'I' && pat[3] == 'D' && pat[4] == 'D' && pat[5] == 'D') {
                out->p = (void *)(size_t)call_IDIDDD_to_p(fn, iv[0], dv[1], iv[2], dv[3], dv[4], dv[5]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'D' && pat[2] == 'D' && pat[3] == 'I' && pat[4] == 'I' && pat[5] == 'I') {
                out->p = (void *)(size_t)call_IDDIII_to_p(fn, iv[0], dv[1], dv[2], iv[3], iv[4], iv[5]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'D' && pat[2] == 'D' && pat[3] == 'I' && pat[4] == 'I' && pat[5] == 'D') {
                out->p = (void *)(size_t)call_IDDIID_to_p(fn, iv[0], dv[1], dv[2], iv[3], iv[4], dv[5]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'D' && pat[2] == 'D' && pat[3] == 'I' && pat[4] == 'D' && pat[5] == 'I') {
                out->p = (void *)(size_t)call_IDDIDI_to_p(fn, iv[0], dv[1], dv[2], iv[3], dv[4], iv[5]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'D' && pat[2] == 'D' && pat[3] == 'I' && pat[4] == 'D' && pat[5] == 'D') {
                out->p = (void *)(size_t)call_IDDIDD_to_p(fn, iv[0], dv[1], dv[2], iv[3], dv[4], dv[5]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'D' && pat[2] == 'D' && pat[3] == 'D' && pat[4] == 'I' && pat[5] == 'I') {
                out->p = (void *)(size_t)call_IDDDII_to_p(fn, iv[0], dv[1], dv[2], dv[3], iv[4], iv[5]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'D' && pat[2] == 'D' && pat[3] == 'D' && pat[4] == 'I' && pat[5] == 'D') {
                out->p = (void *)(size_t)call_IDDDID_to_p(fn, iv[0], dv[1], dv[2], dv[3], iv[4], dv[5]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'D' && pat[2] == 'D' && pat[3] == 'D' && pat[4] == 'D' && pat[5] == 'I') {
                out->p = (void *)(size_t)call_IDDDDI_to_p(fn, iv[0], dv[1], dv[2], dv[3], dv[4], iv[5]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'D' && pat[2] == 'D' && pat[3] == 'D' && pat[4] == 'D' && pat[5] == 'D') {
                out->p = (void *)(size_t)call_IDDDDD_to_p(fn, iv[0], dv[1], dv[2], dv[3], dv[4], dv[5]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'I' && pat[2] == 'I' && pat[3] == 'I' && pat[4] == 'I' && pat[5] == 'I') {
                out->p = (void *)(size_t)call_DIIIII_to_p(fn, dv[0], iv[1], iv[2], iv[3], iv[4], iv[5]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'I' && pat[2] == 'I' && pat[3] == 'I' && pat[4] == 'I' && pat[5] == 'D') {
                out->p = (void *)(size_t)call_DIIIID_to_p(fn, dv[0], iv[1], iv[2], iv[3], iv[4], dv[5]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'I' && pat[2] == 'I' && pat[3] == 'I' && pat[4] == 'D' && pat[5] == 'I') {
                out->p = (void *)(size_t)call_DIIIDI_to_p(fn, dv[0], iv[1], iv[2], iv[3], dv[4], iv[5]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'I' && pat[2] == 'I' && pat[3] == 'I' && pat[4] == 'D' && pat[5] == 'D') {
                out->p = (void *)(size_t)call_DIIIDD_to_p(fn, dv[0], iv[1], iv[2], iv[3], dv[4], dv[5]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'I' && pat[2] == 'I' && pat[3] == 'D' && pat[4] == 'I' && pat[5] == 'I') {
                out->p = (void *)(size_t)call_DIIDII_to_p(fn, dv[0], iv[1], iv[2], dv[3], iv[4], iv[5]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'I' && pat[2] == 'I' && pat[3] == 'D' && pat[4] == 'I' && pat[5] == 'D') {
                out->p = (void *)(size_t)call_DIIDID_to_p(fn, dv[0], iv[1], iv[2], dv[3], iv[4], dv[5]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'I' && pat[2] == 'I' && pat[3] == 'D' && pat[4] == 'D' && pat[5] == 'I') {
                out->p = (void *)(size_t)call_DIIDDI_to_p(fn, dv[0], iv[1], iv[2], dv[3], dv[4], iv[5]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'I' && pat[2] == 'I' && pat[3] == 'D' && pat[4] == 'D' && pat[5] == 'D') {
                out->p = (void *)(size_t)call_DIIDDD_to_p(fn, dv[0], iv[1], iv[2], dv[3], dv[4], dv[5]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'I' && pat[2] == 'D' && pat[3] == 'I' && pat[4] == 'I' && pat[5] == 'I') {
                out->p = (void *)(size_t)call_DIDIII_to_p(fn, dv[0], iv[1], dv[2], iv[3], iv[4], iv[5]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'I' && pat[2] == 'D' && pat[3] == 'I' && pat[4] == 'I' && pat[5] == 'D') {
                out->p = (void *)(size_t)call_DIDIID_to_p(fn, dv[0], iv[1], dv[2], iv[3], iv[4], dv[5]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'I' && pat[2] == 'D' && pat[3] == 'I' && pat[4] == 'D' && pat[5] == 'I') {
                out->p = (void *)(size_t)call_DIDIDI_to_p(fn, dv[0], iv[1], dv[2], iv[3], dv[4], iv[5]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'I' && pat[2] == 'D' && pat[3] == 'I' && pat[4] == 'D' && pat[5] == 'D') {
                out->p = (void *)(size_t)call_DIDIDD_to_p(fn, dv[0], iv[1], dv[2], iv[3], dv[4], dv[5]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'I' && pat[2] == 'D' && pat[3] == 'D' && pat[4] == 'I' && pat[5] == 'I') {
                out->p = (void *)(size_t)call_DIDDII_to_p(fn, dv[0], iv[1], dv[2], dv[3], iv[4], iv[5]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'I' && pat[2] == 'D' && pat[3] == 'D' && pat[4] == 'I' && pat[5] == 'D') {
                out->p = (void *)(size_t)call_DIDDID_to_p(fn, dv[0], iv[1], dv[2], dv[3], iv[4], dv[5]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'I' && pat[2] == 'D' && pat[3] == 'D' && pat[4] == 'D' && pat[5] == 'I') {
                out->p = (void *)(size_t)call_DIDDDI_to_p(fn, dv[0], iv[1], dv[2], dv[3], dv[4], iv[5]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'I' && pat[2] == 'D' && pat[3] == 'D' && pat[4] == 'D' && pat[5] == 'D') {
                out->p = (void *)(size_t)call_DIDDDD_to_p(fn, dv[0], iv[1], dv[2], dv[3], dv[4], dv[5]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'D' && pat[2] == 'I' && pat[3] == 'I' && pat[4] == 'I' && pat[5] == 'I') {
                out->p = (void *)(size_t)call_DDIIII_to_p(fn, dv[0], dv[1], iv[2], iv[3], iv[4], iv[5]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'D' && pat[2] == 'I' && pat[3] == 'I' && pat[4] == 'I' && pat[5] == 'D') {
                out->p = (void *)(size_t)call_DDIIID_to_p(fn, dv[0], dv[1], iv[2], iv[3], iv[4], dv[5]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'D' && pat[2] == 'I' && pat[3] == 'I' && pat[4] == 'D' && pat[5] == 'I') {
                out->p = (void *)(size_t)call_DDIIDI_to_p(fn, dv[0], dv[1], iv[2], iv[3], dv[4], iv[5]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'D' && pat[2] == 'I' && pat[3] == 'I' && pat[4] == 'D' && pat[5] == 'D') {
                out->p = (void *)(size_t)call_DDIIDD_to_p(fn, dv[0], dv[1], iv[2], iv[3], dv[4], dv[5]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'D' && pat[2] == 'I' && pat[3] == 'D' && pat[4] == 'I' && pat[5] == 'I') {
                out->p = (void *)(size_t)call_DDIDII_to_p(fn, dv[0], dv[1], iv[2], dv[3], iv[4], iv[5]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'D' && pat[2] == 'I' && pat[3] == 'D' && pat[4] == 'I' && pat[5] == 'D') {
                out->p = (void *)(size_t)call_DDIDID_to_p(fn, dv[0], dv[1], iv[2], dv[3], iv[4], dv[5]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'D' && pat[2] == 'I' && pat[3] == 'D' && pat[4] == 'D' && pat[5] == 'I') {
                out->p = (void *)(size_t)call_DDIDDI_to_p(fn, dv[0], dv[1], iv[2], dv[3], dv[4], iv[5]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'D' && pat[2] == 'I' && pat[3] == 'D' && pat[4] == 'D' && pat[5] == 'D') {
                out->p = (void *)(size_t)call_DDIDDD_to_p(fn, dv[0], dv[1], iv[2], dv[3], dv[4], dv[5]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'D' && pat[2] == 'D' && pat[3] == 'I' && pat[4] == 'I' && pat[5] == 'I') {
                out->p = (void *)(size_t)call_DDDIII_to_p(fn, dv[0], dv[1], dv[2], iv[3], iv[4], iv[5]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'D' && pat[2] == 'D' && pat[3] == 'I' && pat[4] == 'I' && pat[5] == 'D') {
                out->p = (void *)(size_t)call_DDDIID_to_p(fn, dv[0], dv[1], dv[2], iv[3], iv[4], dv[5]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'D' && pat[2] == 'D' && pat[3] == 'I' && pat[4] == 'D' && pat[5] == 'I') {
                out->p = (void *)(size_t)call_DDDIDI_to_p(fn, dv[0], dv[1], dv[2], iv[3], dv[4], iv[5]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'D' && pat[2] == 'D' && pat[3] == 'I' && pat[4] == 'D' && pat[5] == 'D') {
                out->p = (void *)(size_t)call_DDDIDD_to_p(fn, dv[0], dv[1], dv[2], iv[3], dv[4], dv[5]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'D' && pat[2] == 'D' && pat[3] == 'D' && pat[4] == 'I' && pat[5] == 'I') {
                out->p = (void *)(size_t)call_DDDDII_to_p(fn, dv[0], dv[1], dv[2], dv[3], iv[4], iv[5]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'D' && pat[2] == 'D' && pat[3] == 'D' && pat[4] == 'I' && pat[5] == 'D') {
                out->p = (void *)(size_t)call_DDDDID_to_p(fn, dv[0], dv[1], dv[2], dv[3], iv[4], dv[5]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'D' && pat[2] == 'D' && pat[3] == 'D' && pat[4] == 'D' && pat[5] == 'I') {
                out->p = (void *)(size_t)call_DDDDDI_to_p(fn, dv[0], dv[1], dv[2], dv[3], dv[4], iv[5]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'D' && pat[2] == 'D' && pat[3] == 'D' && pat[4] == 'D' && pat[5] == 'D') {
                out->p = (void *)(size_t)call_DDDDDD_to_p(fn, dv[0], dv[1], dv[2], dv[3], dv[4], dv[5]);
                return 1;
            }
            return 0;
        default: return 0;
        }
    case FFI_RET_VOID:
        switch (arg_count) {
        case 0:
            if (1) {
                call_0_to_v(fn);
                return 1;
            }
            return 0;
        case 1:
            if (pat[0] == 'I') {
                call_I_to_v(fn, iv[0]);
                return 1;
            }
            else if (pat[0] == 'D') {
                call_D_to_v(fn, dv[0]);
                return 1;
            }
            return 0;
        case 2:
            if (pat[0] == 'I' && pat[1] == 'I') {
                call_II_to_v(fn, iv[0], iv[1]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'D') {
                call_ID_to_v(fn, iv[0], dv[1]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'I') {
                call_DI_to_v(fn, dv[0], iv[1]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'D') {
                call_DD_to_v(fn, dv[0], dv[1]);
                return 1;
            }
            return 0;
        case 3:
            if (pat[0] == 'I' && pat[1] == 'I' && pat[2] == 'I') {
                call_III_to_v(fn, iv[0], iv[1], iv[2]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'I' && pat[2] == 'D') {
                call_IID_to_v(fn, iv[0], iv[1], dv[2]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'D' && pat[2] == 'I') {
                call_IDI_to_v(fn, iv[0], dv[1], iv[2]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'D' && pat[2] == 'D') {
                call_IDD_to_v(fn, iv[0], dv[1], dv[2]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'I' && pat[2] == 'I') {
                call_DII_to_v(fn, dv[0], iv[1], iv[2]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'I' && pat[2] == 'D') {
                call_DID_to_v(fn, dv[0], iv[1], dv[2]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'D' && pat[2] == 'I') {
                call_DDI_to_v(fn, dv[0], dv[1], iv[2]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'D' && pat[2] == 'D') {
                call_DDD_to_v(fn, dv[0], dv[1], dv[2]);
                return 1;
            }
            return 0;
        case 4:
            if (pat[0] == 'I' && pat[1] == 'I' && pat[2] == 'I' && pat[3] == 'I') {
                call_IIII_to_v(fn, iv[0], iv[1], iv[2], iv[3]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'I' && pat[2] == 'I' && pat[3] == 'D') {
                call_IIID_to_v(fn, iv[0], iv[1], iv[2], dv[3]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'I' && pat[2] == 'D' && pat[3] == 'I') {
                call_IIDI_to_v(fn, iv[0], iv[1], dv[2], iv[3]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'I' && pat[2] == 'D' && pat[3] == 'D') {
                call_IIDD_to_v(fn, iv[0], iv[1], dv[2], dv[3]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'D' && pat[2] == 'I' && pat[3] == 'I') {
                call_IDII_to_v(fn, iv[0], dv[1], iv[2], iv[3]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'D' && pat[2] == 'I' && pat[3] == 'D') {
                call_IDID_to_v(fn, iv[0], dv[1], iv[2], dv[3]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'D' && pat[2] == 'D' && pat[3] == 'I') {
                call_IDDI_to_v(fn, iv[0], dv[1], dv[2], iv[3]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'D' && pat[2] == 'D' && pat[3] == 'D') {
                call_IDDD_to_v(fn, iv[0], dv[1], dv[2], dv[3]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'I' && pat[2] == 'I' && pat[3] == 'I') {
                call_DIII_to_v(fn, dv[0], iv[1], iv[2], iv[3]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'I' && pat[2] == 'I' && pat[3] == 'D') {
                call_DIID_to_v(fn, dv[0], iv[1], iv[2], dv[3]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'I' && pat[2] == 'D' && pat[3] == 'I') {
                call_DIDI_to_v(fn, dv[0], iv[1], dv[2], iv[3]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'I' && pat[2] == 'D' && pat[3] == 'D') {
                call_DIDD_to_v(fn, dv[0], iv[1], dv[2], dv[3]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'D' && pat[2] == 'I' && pat[3] == 'I') {
                call_DDII_to_v(fn, dv[0], dv[1], iv[2], iv[3]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'D' && pat[2] == 'I' && pat[3] == 'D') {
                call_DDID_to_v(fn, dv[0], dv[1], iv[2], dv[3]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'D' && pat[2] == 'D' && pat[3] == 'I') {
                call_DDDI_to_v(fn, dv[0], dv[1], dv[2], iv[3]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'D' && pat[2] == 'D' && pat[3] == 'D') {
                call_DDDD_to_v(fn, dv[0], dv[1], dv[2], dv[3]);
                return 1;
            }
            return 0;
        case 5:
            if (pat[0] == 'I' && pat[1] == 'I' && pat[2] == 'I' && pat[3] == 'I' && pat[4] == 'I') {
                call_IIIII_to_v(fn, iv[0], iv[1], iv[2], iv[3], iv[4]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'I' && pat[2] == 'I' && pat[3] == 'I' && pat[4] == 'D') {
                call_IIIID_to_v(fn, iv[0], iv[1], iv[2], iv[3], dv[4]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'I' && pat[2] == 'I' && pat[3] == 'D' && pat[4] == 'I') {
                call_IIIDI_to_v(fn, iv[0], iv[1], iv[2], dv[3], iv[4]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'I' && pat[2] == 'I' && pat[3] == 'D' && pat[4] == 'D') {
                call_IIIDD_to_v(fn, iv[0], iv[1], iv[2], dv[3], dv[4]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'I' && pat[2] == 'D' && pat[3] == 'I' && pat[4] == 'I') {
                call_IIDII_to_v(fn, iv[0], iv[1], dv[2], iv[3], iv[4]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'I' && pat[2] == 'D' && pat[3] == 'I' && pat[4] == 'D') {
                call_IIDID_to_v(fn, iv[0], iv[1], dv[2], iv[3], dv[4]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'I' && pat[2] == 'D' && pat[3] == 'D' && pat[4] == 'I') {
                call_IIDDI_to_v(fn, iv[0], iv[1], dv[2], dv[3], iv[4]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'I' && pat[2] == 'D' && pat[3] == 'D' && pat[4] == 'D') {
                call_IIDDD_to_v(fn, iv[0], iv[1], dv[2], dv[3], dv[4]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'D' && pat[2] == 'I' && pat[3] == 'I' && pat[4] == 'I') {
                call_IDIII_to_v(fn, iv[0], dv[1], iv[2], iv[3], iv[4]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'D' && pat[2] == 'I' && pat[3] == 'I' && pat[4] == 'D') {
                call_IDIID_to_v(fn, iv[0], dv[1], iv[2], iv[3], dv[4]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'D' && pat[2] == 'I' && pat[3] == 'D' && pat[4] == 'I') {
                call_IDIDI_to_v(fn, iv[0], dv[1], iv[2], dv[3], iv[4]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'D' && pat[2] == 'I' && pat[3] == 'D' && pat[4] == 'D') {
                call_IDIDD_to_v(fn, iv[0], dv[1], iv[2], dv[3], dv[4]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'D' && pat[2] == 'D' && pat[3] == 'I' && pat[4] == 'I') {
                call_IDDII_to_v(fn, iv[0], dv[1], dv[2], iv[3], iv[4]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'D' && pat[2] == 'D' && pat[3] == 'I' && pat[4] == 'D') {
                call_IDDID_to_v(fn, iv[0], dv[1], dv[2], iv[3], dv[4]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'D' && pat[2] == 'D' && pat[3] == 'D' && pat[4] == 'I') {
                call_IDDDI_to_v(fn, iv[0], dv[1], dv[2], dv[3], iv[4]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'D' && pat[2] == 'D' && pat[3] == 'D' && pat[4] == 'D') {
                call_IDDDD_to_v(fn, iv[0], dv[1], dv[2], dv[3], dv[4]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'I' && pat[2] == 'I' && pat[3] == 'I' && pat[4] == 'I') {
                call_DIIII_to_v(fn, dv[0], iv[1], iv[2], iv[3], iv[4]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'I' && pat[2] == 'I' && pat[3] == 'I' && pat[4] == 'D') {
                call_DIIID_to_v(fn, dv[0], iv[1], iv[2], iv[3], dv[4]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'I' && pat[2] == 'I' && pat[3] == 'D' && pat[4] == 'I') {
                call_DIIDI_to_v(fn, dv[0], iv[1], iv[2], dv[3], iv[4]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'I' && pat[2] == 'I' && pat[3] == 'D' && pat[4] == 'D') {
                call_DIIDD_to_v(fn, dv[0], iv[1], iv[2], dv[3], dv[4]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'I' && pat[2] == 'D' && pat[3] == 'I' && pat[4] == 'I') {
                call_DIDII_to_v(fn, dv[0], iv[1], dv[2], iv[3], iv[4]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'I' && pat[2] == 'D' && pat[3] == 'I' && pat[4] == 'D') {
                call_DIDID_to_v(fn, dv[0], iv[1], dv[2], iv[3], dv[4]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'I' && pat[2] == 'D' && pat[3] == 'D' && pat[4] == 'I') {
                call_DIDDI_to_v(fn, dv[0], iv[1], dv[2], dv[3], iv[4]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'I' && pat[2] == 'D' && pat[3] == 'D' && pat[4] == 'D') {
                call_DIDDD_to_v(fn, dv[0], iv[1], dv[2], dv[3], dv[4]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'D' && pat[2] == 'I' && pat[3] == 'I' && pat[4] == 'I') {
                call_DDIII_to_v(fn, dv[0], dv[1], iv[2], iv[3], iv[4]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'D' && pat[2] == 'I' && pat[3] == 'I' && pat[4] == 'D') {
                call_DDIID_to_v(fn, dv[0], dv[1], iv[2], iv[3], dv[4]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'D' && pat[2] == 'I' && pat[3] == 'D' && pat[4] == 'I') {
                call_DDIDI_to_v(fn, dv[0], dv[1], iv[2], dv[3], iv[4]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'D' && pat[2] == 'I' && pat[3] == 'D' && pat[4] == 'D') {
                call_DDIDD_to_v(fn, dv[0], dv[1], iv[2], dv[3], dv[4]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'D' && pat[2] == 'D' && pat[3] == 'I' && pat[4] == 'I') {
                call_DDDII_to_v(fn, dv[0], dv[1], dv[2], iv[3], iv[4]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'D' && pat[2] == 'D' && pat[3] == 'I' && pat[4] == 'D') {
                call_DDDID_to_v(fn, dv[0], dv[1], dv[2], iv[3], dv[4]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'D' && pat[2] == 'D' && pat[3] == 'D' && pat[4] == 'I') {
                call_DDDDI_to_v(fn, dv[0], dv[1], dv[2], dv[3], iv[4]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'D' && pat[2] == 'D' && pat[3] == 'D' && pat[4] == 'D') {
                call_DDDDD_to_v(fn, dv[0], dv[1], dv[2], dv[3], dv[4]);
                return 1;
            }
            return 0;
        case 6:
            if (pat[0] == 'I' && pat[1] == 'I' && pat[2] == 'I' && pat[3] == 'I' && pat[4] == 'I' && pat[5] == 'I') {
                call_IIIIII_to_v(fn, iv[0], iv[1], iv[2], iv[3], iv[4], iv[5]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'I' && pat[2] == 'I' && pat[3] == 'I' && pat[4] == 'I' && pat[5] == 'D') {
                call_IIIIID_to_v(fn, iv[0], iv[1], iv[2], iv[3], iv[4], dv[5]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'I' && pat[2] == 'I' && pat[3] == 'I' && pat[4] == 'D' && pat[5] == 'I') {
                call_IIIIDI_to_v(fn, iv[0], iv[1], iv[2], iv[3], dv[4], iv[5]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'I' && pat[2] == 'I' && pat[3] == 'I' && pat[4] == 'D' && pat[5] == 'D') {
                call_IIIIDD_to_v(fn, iv[0], iv[1], iv[2], iv[3], dv[4], dv[5]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'I' && pat[2] == 'I' && pat[3] == 'D' && pat[4] == 'I' && pat[5] == 'I') {
                call_IIIDII_to_v(fn, iv[0], iv[1], iv[2], dv[3], iv[4], iv[5]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'I' && pat[2] == 'I' && pat[3] == 'D' && pat[4] == 'I' && pat[5] == 'D') {
                call_IIIDID_to_v(fn, iv[0], iv[1], iv[2], dv[3], iv[4], dv[5]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'I' && pat[2] == 'I' && pat[3] == 'D' && pat[4] == 'D' && pat[5] == 'I') {
                call_IIIDDI_to_v(fn, iv[0], iv[1], iv[2], dv[3], dv[4], iv[5]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'I' && pat[2] == 'I' && pat[3] == 'D' && pat[4] == 'D' && pat[5] == 'D') {
                call_IIIDDD_to_v(fn, iv[0], iv[1], iv[2], dv[3], dv[4], dv[5]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'I' && pat[2] == 'D' && pat[3] == 'I' && pat[4] == 'I' && pat[5] == 'I') {
                call_IIDIII_to_v(fn, iv[0], iv[1], dv[2], iv[3], iv[4], iv[5]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'I' && pat[2] == 'D' && pat[3] == 'I' && pat[4] == 'I' && pat[5] == 'D') {
                call_IIDIID_to_v(fn, iv[0], iv[1], dv[2], iv[3], iv[4], dv[5]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'I' && pat[2] == 'D' && pat[3] == 'I' && pat[4] == 'D' && pat[5] == 'I') {
                call_IIDIDI_to_v(fn, iv[0], iv[1], dv[2], iv[3], dv[4], iv[5]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'I' && pat[2] == 'D' && pat[3] == 'I' && pat[4] == 'D' && pat[5] == 'D') {
                call_IIDIDD_to_v(fn, iv[0], iv[1], dv[2], iv[3], dv[4], dv[5]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'I' && pat[2] == 'D' && pat[3] == 'D' && pat[4] == 'I' && pat[5] == 'I') {
                call_IIDDII_to_v(fn, iv[0], iv[1], dv[2], dv[3], iv[4], iv[5]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'I' && pat[2] == 'D' && pat[3] == 'D' && pat[4] == 'I' && pat[5] == 'D') {
                call_IIDDID_to_v(fn, iv[0], iv[1], dv[2], dv[3], iv[4], dv[5]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'I' && pat[2] == 'D' && pat[3] == 'D' && pat[4] == 'D' && pat[5] == 'I') {
                call_IIDDDI_to_v(fn, iv[0], iv[1], dv[2], dv[3], dv[4], iv[5]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'I' && pat[2] == 'D' && pat[3] == 'D' && pat[4] == 'D' && pat[5] == 'D') {
                call_IIDDDD_to_v(fn, iv[0], iv[1], dv[2], dv[3], dv[4], dv[5]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'D' && pat[2] == 'I' && pat[3] == 'I' && pat[4] == 'I' && pat[5] == 'I') {
                call_IDIIII_to_v(fn, iv[0], dv[1], iv[2], iv[3], iv[4], iv[5]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'D' && pat[2] == 'I' && pat[3] == 'I' && pat[4] == 'I' && pat[5] == 'D') {
                call_IDIIID_to_v(fn, iv[0], dv[1], iv[2], iv[3], iv[4], dv[5]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'D' && pat[2] == 'I' && pat[3] == 'I' && pat[4] == 'D' && pat[5] == 'I') {
                call_IDIIDI_to_v(fn, iv[0], dv[1], iv[2], iv[3], dv[4], iv[5]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'D' && pat[2] == 'I' && pat[3] == 'I' && pat[4] == 'D' && pat[5] == 'D') {
                call_IDIIDD_to_v(fn, iv[0], dv[1], iv[2], iv[3], dv[4], dv[5]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'D' && pat[2] == 'I' && pat[3] == 'D' && pat[4] == 'I' && pat[5] == 'I') {
                call_IDIDII_to_v(fn, iv[0], dv[1], iv[2], dv[3], iv[4], iv[5]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'D' && pat[2] == 'I' && pat[3] == 'D' && pat[4] == 'I' && pat[5] == 'D') {
                call_IDIDID_to_v(fn, iv[0], dv[1], iv[2], dv[3], iv[4], dv[5]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'D' && pat[2] == 'I' && pat[3] == 'D' && pat[4] == 'D' && pat[5] == 'I') {
                call_IDIDDI_to_v(fn, iv[0], dv[1], iv[2], dv[3], dv[4], iv[5]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'D' && pat[2] == 'I' && pat[3] == 'D' && pat[4] == 'D' && pat[5] == 'D') {
                call_IDIDDD_to_v(fn, iv[0], dv[1], iv[2], dv[3], dv[4], dv[5]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'D' && pat[2] == 'D' && pat[3] == 'I' && pat[4] == 'I' && pat[5] == 'I') {
                call_IDDIII_to_v(fn, iv[0], dv[1], dv[2], iv[3], iv[4], iv[5]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'D' && pat[2] == 'D' && pat[3] == 'I' && pat[4] == 'I' && pat[5] == 'D') {
                call_IDDIID_to_v(fn, iv[0], dv[1], dv[2], iv[3], iv[4], dv[5]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'D' && pat[2] == 'D' && pat[3] == 'I' && pat[4] == 'D' && pat[5] == 'I') {
                call_IDDIDI_to_v(fn, iv[0], dv[1], dv[2], iv[3], dv[4], iv[5]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'D' && pat[2] == 'D' && pat[3] == 'I' && pat[4] == 'D' && pat[5] == 'D') {
                call_IDDIDD_to_v(fn, iv[0], dv[1], dv[2], iv[3], dv[4], dv[5]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'D' && pat[2] == 'D' && pat[3] == 'D' && pat[4] == 'I' && pat[5] == 'I') {
                call_IDDDII_to_v(fn, iv[0], dv[1], dv[2], dv[3], iv[4], iv[5]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'D' && pat[2] == 'D' && pat[3] == 'D' && pat[4] == 'I' && pat[5] == 'D') {
                call_IDDDID_to_v(fn, iv[0], dv[1], dv[2], dv[3], iv[4], dv[5]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'D' && pat[2] == 'D' && pat[3] == 'D' && pat[4] == 'D' && pat[5] == 'I') {
                call_IDDDDI_to_v(fn, iv[0], dv[1], dv[2], dv[3], dv[4], iv[5]);
                return 1;
            }
            else if (pat[0] == 'I' && pat[1] == 'D' && pat[2] == 'D' && pat[3] == 'D' && pat[4] == 'D' && pat[5] == 'D') {
                call_IDDDDD_to_v(fn, iv[0], dv[1], dv[2], dv[3], dv[4], dv[5]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'I' && pat[2] == 'I' && pat[3] == 'I' && pat[4] == 'I' && pat[5] == 'I') {
                call_DIIIII_to_v(fn, dv[0], iv[1], iv[2], iv[3], iv[4], iv[5]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'I' && pat[2] == 'I' && pat[3] == 'I' && pat[4] == 'I' && pat[5] == 'D') {
                call_DIIIID_to_v(fn, dv[0], iv[1], iv[2], iv[3], iv[4], dv[5]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'I' && pat[2] == 'I' && pat[3] == 'I' && pat[4] == 'D' && pat[5] == 'I') {
                call_DIIIDI_to_v(fn, dv[0], iv[1], iv[2], iv[3], dv[4], iv[5]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'I' && pat[2] == 'I' && pat[3] == 'I' && pat[4] == 'D' && pat[5] == 'D') {
                call_DIIIDD_to_v(fn, dv[0], iv[1], iv[2], iv[3], dv[4], dv[5]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'I' && pat[2] == 'I' && pat[3] == 'D' && pat[4] == 'I' && pat[5] == 'I') {
                call_DIIDII_to_v(fn, dv[0], iv[1], iv[2], dv[3], iv[4], iv[5]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'I' && pat[2] == 'I' && pat[3] == 'D' && pat[4] == 'I' && pat[5] == 'D') {
                call_DIIDID_to_v(fn, dv[0], iv[1], iv[2], dv[3], iv[4], dv[5]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'I' && pat[2] == 'I' && pat[3] == 'D' && pat[4] == 'D' && pat[5] == 'I') {
                call_DIIDDI_to_v(fn, dv[0], iv[1], iv[2], dv[3], dv[4], iv[5]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'I' && pat[2] == 'I' && pat[3] == 'D' && pat[4] == 'D' && pat[5] == 'D') {
                call_DIIDDD_to_v(fn, dv[0], iv[1], iv[2], dv[3], dv[4], dv[5]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'I' && pat[2] == 'D' && pat[3] == 'I' && pat[4] == 'I' && pat[5] == 'I') {
                call_DIDIII_to_v(fn, dv[0], iv[1], dv[2], iv[3], iv[4], iv[5]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'I' && pat[2] == 'D' && pat[3] == 'I' && pat[4] == 'I' && pat[5] == 'D') {
                call_DIDIID_to_v(fn, dv[0], iv[1], dv[2], iv[3], iv[4], dv[5]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'I' && pat[2] == 'D' && pat[3] == 'I' && pat[4] == 'D' && pat[5] == 'I') {
                call_DIDIDI_to_v(fn, dv[0], iv[1], dv[2], iv[3], dv[4], iv[5]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'I' && pat[2] == 'D' && pat[3] == 'I' && pat[4] == 'D' && pat[5] == 'D') {
                call_DIDIDD_to_v(fn, dv[0], iv[1], dv[2], iv[3], dv[4], dv[5]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'I' && pat[2] == 'D' && pat[3] == 'D' && pat[4] == 'I' && pat[5] == 'I') {
                call_DIDDII_to_v(fn, dv[0], iv[1], dv[2], dv[3], iv[4], iv[5]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'I' && pat[2] == 'D' && pat[3] == 'D' && pat[4] == 'I' && pat[5] == 'D') {
                call_DIDDID_to_v(fn, dv[0], iv[1], dv[2], dv[3], iv[4], dv[5]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'I' && pat[2] == 'D' && pat[3] == 'D' && pat[4] == 'D' && pat[5] == 'I') {
                call_DIDDDI_to_v(fn, dv[0], iv[1], dv[2], dv[3], dv[4], iv[5]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'I' && pat[2] == 'D' && pat[3] == 'D' && pat[4] == 'D' && pat[5] == 'D') {
                call_DIDDDD_to_v(fn, dv[0], iv[1], dv[2], dv[3], dv[4], dv[5]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'D' && pat[2] == 'I' && pat[3] == 'I' && pat[4] == 'I' && pat[5] == 'I') {
                call_DDIIII_to_v(fn, dv[0], dv[1], iv[2], iv[3], iv[4], iv[5]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'D' && pat[2] == 'I' && pat[3] == 'I' && pat[4] == 'I' && pat[5] == 'D') {
                call_DDIIID_to_v(fn, dv[0], dv[1], iv[2], iv[3], iv[4], dv[5]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'D' && pat[2] == 'I' && pat[3] == 'I' && pat[4] == 'D' && pat[5] == 'I') {
                call_DDIIDI_to_v(fn, dv[0], dv[1], iv[2], iv[3], dv[4], iv[5]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'D' && pat[2] == 'I' && pat[3] == 'I' && pat[4] == 'D' && pat[5] == 'D') {
                call_DDIIDD_to_v(fn, dv[0], dv[1], iv[2], iv[3], dv[4], dv[5]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'D' && pat[2] == 'I' && pat[3] == 'D' && pat[4] == 'I' && pat[5] == 'I') {
                call_DDIDII_to_v(fn, dv[0], dv[1], iv[2], dv[3], iv[4], iv[5]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'D' && pat[2] == 'I' && pat[3] == 'D' && pat[4] == 'I' && pat[5] == 'D') {
                call_DDIDID_to_v(fn, dv[0], dv[1], iv[2], dv[3], iv[4], dv[5]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'D' && pat[2] == 'I' && pat[3] == 'D' && pat[4] == 'D' && pat[5] == 'I') {
                call_DDIDDI_to_v(fn, dv[0], dv[1], iv[2], dv[3], dv[4], iv[5]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'D' && pat[2] == 'I' && pat[3] == 'D' && pat[4] == 'D' && pat[5] == 'D') {
                call_DDIDDD_to_v(fn, dv[0], dv[1], iv[2], dv[3], dv[4], dv[5]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'D' && pat[2] == 'D' && pat[3] == 'I' && pat[4] == 'I' && pat[5] == 'I') {
                call_DDDIII_to_v(fn, dv[0], dv[1], dv[2], iv[3], iv[4], iv[5]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'D' && pat[2] == 'D' && pat[3] == 'I' && pat[4] == 'I' && pat[5] == 'D') {
                call_DDDIID_to_v(fn, dv[0], dv[1], dv[2], iv[3], iv[4], dv[5]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'D' && pat[2] == 'D' && pat[3] == 'I' && pat[4] == 'D' && pat[5] == 'I') {
                call_DDDIDI_to_v(fn, dv[0], dv[1], dv[2], iv[3], dv[4], iv[5]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'D' && pat[2] == 'D' && pat[3] == 'I' && pat[4] == 'D' && pat[5] == 'D') {
                call_DDDIDD_to_v(fn, dv[0], dv[1], dv[2], iv[3], dv[4], dv[5]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'D' && pat[2] == 'D' && pat[3] == 'D' && pat[4] == 'I' && pat[5] == 'I') {
                call_DDDDII_to_v(fn, dv[0], dv[1], dv[2], dv[3], iv[4], iv[5]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'D' && pat[2] == 'D' && pat[3] == 'D' && pat[4] == 'I' && pat[5] == 'D') {
                call_DDDDID_to_v(fn, dv[0], dv[1], dv[2], dv[3], iv[4], dv[5]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'D' && pat[2] == 'D' && pat[3] == 'D' && pat[4] == 'D' && pat[5] == 'I') {
                call_DDDDDI_to_v(fn, dv[0], dv[1], dv[2], dv[3], dv[4], iv[5]);
                return 1;
            }
            else if (pat[0] == 'D' && pat[1] == 'D' && pat[2] == 'D' && pat[3] == 'D' && pat[4] == 'D' && pat[5] == 'D') {
                call_DDDDDD_to_v(fn, dv[0], dv[1], dv[2], dv[3], dv[4], dv[5]);
                return 1;
            }
            return 0;
        default: return 0;
        }
    default: return 0;
    }
}
